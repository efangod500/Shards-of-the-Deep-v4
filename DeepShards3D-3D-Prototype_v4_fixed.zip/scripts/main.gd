extends Node3D

const MAP_W := 32
const MAP_D := 30
const TILE := 2.0
const SAVE_PATH := "user://shards_profile.cfg"
const RAY_LENGTH := 1000.0

const MISSION_NAMES := ["Rainy Plains", "Singer's Meadow", "Humbler Huskland", "Honeycomb Fields", "Lullaby Hills", "Frozen Highlands", "Howling Woods"]
const MISSION_SUBTITLES := ["Rain-soaked ruins · winding stone routes", "Green hills · branching garden paths", "Broken dunes · husk warrens", "Amber fields · honeycomb corridors", "Quiet hills · buried halls", "Frozen passes · icy galleries", "Wild woods · tangled passages"]
const BOSS_NAMES := ["Raincaller", "Meadow Warden", "Husk King", "Comb Matriarch", "Lullaby Shade", "Frostbound Ancient", "Howling Beast"]
const MISSION_COLORS := [
	[Color("#52645a"), Color("#293c37"), Color("#87936c")], [Color("#547247"), Color("#2d4937"), Color("#a0a95f")], [Color("#886b47"), Color("#4c3b2e"), Color("#bd8855")], [Color("#817443"), Color("#4d432d"), Color("#d2ad54")], [Color("#685b73"), Color("#383347"), Color("#a985bf")], [Color("#5b8292"), Color("#344b5b"), Color("#a0d7e5")], [Color("#476348"), Color("#293b30"), Color("#82995a")]
]
const WEAPON_NAMES := ["Wayfinder Blade", "Graveglass Saber", "Hollowfang", "Whisper Daggers", "Emberfang Longsword", "Stonebreaker Greatblade", "Stormsplitter Axe"]
const WEAPON_CLASSES := {"Graveglass Saber": "Light", "Whisper Daggers": "Light", "Wayfinder Blade": "Medium", "Emberfang Longsword": "Medium", "Stonebreaker Greatblade": "Heavy", "Hollowfang": "Axe", "Stormsplitter Axe": "Axe"}
const WEAPON_COMBAT := {"Light": [3, 0.28, 0.62, 10.0, 1.0], "Medium": [3, 0.43, 0.9, 18.0, 1.8], "Heavy": [2, 0.78, 1.45, 34.0, 3.4], "Axe": [3, 0.55, 1.0, 22.0, 2.2]}
const ARMOR_NAMES := ["Wayfarer Coat", "Briarbound Mantle", "Warden Shell"]
const TALISMAN_NAMES := ["Spark Totem", "Moonwell Charm", "Beacon Relic"]
const ARMOR_SLOTS := ["helmet", "armor", "leggings", "boots"]
const ARTIFACT_SLOTS := ["artifact1", "artifact2", "artifact3"]
const ARTIFACT_NAMES := ["Battle Banner", "Blaze Bangle", "Blight Bangle", "Blizzard Bangle", "Cinder Scepter", "Conductive Quiver", "Corrupted Beacon", "Corrupted Seeds", "Creeper Candle", "Death Cap Mushroom", "Echo Ocarina", "Electric Bangle", "Ender Fog", "Fighter's Flute", "Fighting Fungus", "Firework Arrow", "Flaming Quiver", "Freezing Quiver", "Grindstone", "Honey Dipper", "Humbling Horn", "Lightning Rod", "Picnic Basket", "Pouch of Ember", "Pouch of Frost", "Pouch of Poison", "Pouch of Thunder", "Powershaker", "Redstone Mine Launcher", "Soul Harvester", "Tempo Truffle", "Totem of Casting", "Totem of Regeneration", "Totem of Shielding", "Turtle Master's Mandolin", "Venomous Quiver", "Warding Chimes", "Warrior Drums", "Winter Staff", "Witch Brew"]
const ARTIFACT_DATA := {
	"Battle Banner": [45, 10, "Raises a war banner that boosts your strength and nearby allies.", ["Singer's Meadow", "Humbler Huskland"]], "Blaze Bangle": [35, 6, "Imbues attacks with blazing fire.", ["Rainy Plains"]], "Blight Bangle": [35, 6, "Imbues attacks with poison.", ["Honeycomb Fields", "Frozen Highlands"]], "Blizzard Bangle": [35, 6, "Imbues attacks with freezing power.", ["Singer's Meadow", "Humbler Huskland"]], "Cinder Scepter": [25, 5, "Channels a burst of soul-powered fire.", ["Rainy Plains", "Singer's Meadow"]], "Conductive Quiver": [20, 5, "Calls lightning down on enemies struck by arrows.", ["Rainy Plains", "Singer's Meadow"]], "Corrupted Beacon": [20, 6, "Fires raw soul energy in a damaging burst.", ["Honeycomb Fields", "Lullaby Hills"]], "Corrupted Seeds": [20, 5, "Sprouts poisonous vines that bind enemies.", ["Howling Woods"]], "Creeper Candle": [25, 5, "Lights a fuse and blasts nearby enemies.", ["Honeycomb Fields", "Lullaby Hills"]], "Death Cap Mushroom": [25, 5, "Boosts attack speed for a short time.", ["Howling Woods"]], "Echo Ocarina": [40, 10, "Reduces incoming ranged damage with protective music.", ["Frozen Highlands", "Humbler Huskland"]], "Electric Bangle": [35, 6, "Imbues attacks with crackling electricity.", ["Lullaby Hills"]], "Ender Fog": [20, 5, "Cloaks you in shadow and damages nearby enemies.", ["Howling Woods"]], "Fighter's Flute": [45, 5, "Boosts your striking power.", ["Honeycomb Fields", "Frozen Highlands"]], "Fighting Fungus": [20, 5, "Raises attack speed for a short time.", ["Frozen Highlands", "Humbler Huskland"]], "Firework Arrow": [20, 5, "Fires an explosive rocket at your target.", ["Honeycomb Fields", "Humbler Huskland"]], "Flaming Quiver": [20, 5, "Empowers ranged attacks with fire.", ["Humbler Huskland"]], "Freezing Quiver": [20, 5, "Empowers ranged attacks with ice.", ["Frozen Highlands", "Lullaby Hills"]], "Grindstone": [30, 4, "Sharpens your weapon for heavy damage.", ["Lullaby Hills"]], "Honey Dipper": [45, 15, "Traps foes in sticky honey as bees sting them.", ["Honeycomb Fields", "Lullaby Hills"]], "Humbling Horn": [25, 4, "Knocks back and stuns nearby enemies.", ["Honeycomb Fields", "Frozen Highlands"]], "Lightning Rod": [20, 6, "Calls repeated soul-powered lightning strikes.", ["Frozen Highlands", "Humbler Huskland"]], "Picnic Basket": [15, 15, "Restores health with a shared picnic.", ["Rainy Plains"]], "Pouch of Ember": [40, 5, "Scorches enemies in a ring of fire.", ["Singer's Meadow", "Humbler Huskland"]], "Pouch of Frost": [40, 5, "Freezes and damages enemies around you.", ["Honeycomb Fields", "Lullaby Hills"]], "Pouch of Poison": [40, 5, "Poisons enemies in a toxic cloud.", ["Rainy Plains"]], "Pouch of Thunder": [40, 5, "Deals electrical damage around you.", ["Howling Woods"]], "Powershaker": [35, 16, "Shakes the ground to damage and stagger enemies.", ["Singer's Meadow", "Humbler Huskland"]], "Redstone Mine Launcher": [40, 5, "Launches explosive mines at nearby enemies.", ["Lullaby Hills"]], "Soul Harvester": [15, 5, "Consumes souls in a concentrated burst of power.", ["Rainy Plains", "Singer's Meadow"]], "Tempo Truffle": [35, 16, "Boosts movement speed for a short time.", ["Rainy Plains", "Singer's Meadow"]], "Totem of Casting": [30, 15, "Temporarily speeds artifact recharge.", ["Rainy Plains", "Singer's Meadow"]], "Totem of Regeneration": [65, 27, "Restores health over time.", ["Rainy Plains"]], "Totem of Shielding": [30, 15, "Reduces damage taken for a short time.", ["Howling Woods"]], "Turtle Master's Mandolin": [20, 5, "Grants resistance to incoming damage.", ["Howling Woods"]], "Venomous Quiver": [20, 5, "Empowers ranged attacks with venom.", ["Howling Woods"]], "Warding Chimes": [40, 15, "Hardens your defenses for a short time.", ["Honeycomb Fields", "Frozen Highlands"]], "Warrior Drums": [45, 5, "Boosts damage dealt for a short time.", ["Lullaby Hills"]], "Winter Staff": [15, 5, "Blasts a soul-powered blizzard at enemies.", ["Howling Woods"]], "Witch Brew": [20, 5, "Weakens enemies caught in a vapor cloud.", ["Howling Woods"]]
}
const PASSIVE_TALISMAN_NAMES := ["Moonwell Charm", "Wayfarer Compass", "Anchor Charm"]
const EQUIPMENT_SLOTS := ["weapon", "helmet", "armor", "leggings", "boots", "artifact1", "artifact2", "artifact3", "talisman"]
const WEAPON_ENCHANTS := ["Critical Hit", "Committed", "Exploding", "Fire Aspect", "Freezing", "Gravity", "Leeching", "Prospector", "Radiance", "Sharpness", "Shockwave", "Swirling"]
const ARMOR_ENCHANTS := ["Chilling", "Deflect", "Protection", "Snowball", "Thorns"]
const ENCHANT_COST := {"Critical Hit": [2, 3], "Committed": [1, 2], "Exploding": [3, 4], "Fire Aspect": [1, 2], "Freezing": [1, 2], "Gravity": [3, 4], "Leeching": [1, 2], "Prospector": [1, 2], "Radiance": [3, 4], "Sharpness": [1, 2], "Shockwave": [3, 4], "Swirling": [3, 4], "Chilling": [3, 4], "Deflect": [1, 2], "Protection": [3, 4], "Snowball": [1, 2], "Thorns": [1, 2]}
const ENCHANT_DESCRIPTIONS := {
	"Critical Hit": "Chance to deal triple damage.", "Committed": "Deals more damage to enemies as their health gets low.",
	"Exploding": "Defeated enemies blast nearby enemies.", "Fire Aspect": "Hits ignite enemies for damage over time.",
	"Freezing": "Hits slow the enemy for a short time.", "Gravity": "Pulls nearby enemies into the strike.",
	"Leeching": "Defeating an enemy restores some of your health.", "Prospector": "Defeating an enemy can drop bonus shards.",
	"Radiance": "Attacks can release a healing pulse.", "Sharpness": "Increases your weapon damage.",
	"Shockwave": "Every third combo sends a damaging wave outward.", "Swirling": "Every third combo spins a damaging burst around you.",
	"Chilling": "Nearby enemies are periodically slowed.", "Deflect": "Chance to completely deflect an incoming hit.",
	"Protection": "Reduces damage you take.", "Snowball": "Periodically stuns a nearby enemy.",
	"Thorns": "Reflects damage to enemies that hit you.", "Moonwell Charm": "Passive: slowly restores your health.",
	"Wayfarer Compass": "Passive: improves the quality and amount of loot.", "Anchor Charm": "Passive: grants extra maximum health.",
	"Spark Totem": "Artifact: powerful burst of damage around you.", "Beacon Relic": "Artifact: damages nearby enemies and restores health.",
	"Frost Bomb": "Artifact: damages and freezes enemies in a wide area."
}

var player: CharacterBody3D
var boss_actor: CharacterBody3D
var camera: Camera3D
var enemies: Array[CharacterBody3D] = []
var loot_nodes: Array[Node3D] = []
var enemy_projectiles: Array[Node3D] = []
var player_projectiles: Array[Node3D] = []
var dungeon_interactables: Array[Node3D] = []
var target_actor: CharacterBody3D
var hover_actor: CharacterBody3D
var recently_attacked_actor: CharacterBody3D
var attacked_highlight_timer := 0.0
var outline_material: ShaderMaterial
var move_goal: Vector3
var has_move_goal := false
var game_active := false
var paused := true
var in_camp := true
var selected_mission := 0
var selected_tier := 0
var unlocked_tier := 2
var cleared_bosses: Dictionary = {}
var level := 1
var xp := 0
var xp_next := 100
var enchant_points := 0
var shards := 0
var souls := 0
const MAX_SOULS := 135
var artifact_regen_tick := 0.0
var active_artifact_effects: Dictionary = {}
var active_artifact_strength: Dictionary = {}
var souls_label: Label
var artifact_effect_label: Label
var dungeon_open_cells: Dictionary = {}
var coins := 0
var kills := 0
var caches_opened := 0
var shrines_used := 0
var stability := 0.0
var health := 100.0
var max_health := 100.0
var attack_timer := 0.0
var potion_cooldown := 0.0
var arrows := 30
var max_arrows := 30
var arrow_regen_timer := 0.0
var dash_timer := 0.0
var dash_cooldown := 0.0
var last_move_direction := Vector3(0.0, 0.0, -1.0)
var spawn_timer := 2.0
var boss_spawned := false
var pressure_timer := 0.0
var hurt_timer := 0.0
var player_slow_timer := 0.0
var chill_timer := 0.0
var snowball_timer := 0.0
var status_timer := 0.0
var status_message := ""
var combo_count := 0
var weapon_combo_step := 0
var weapon_combo_reset_timer := 0.0
var loot_luck := 1.0
var gear := {"weapon": {}, "helmet": {}, "armor": {}, "leggings": {}, "boots": {}, "artifact1": {}, "artifact2": {}, "artifact3": {}, "talisman": {}}
var inventory: Array[Dictionary] = []
var coin_nodes: Array[Node3D] = []
var artifact_cooldowns: Array[float] = [0.0, 0.0, 0.0]
var artifact_hud_buttons: Array[Button] = []
var keybinds: Dictionary = {"move_up": KEY_W, "move_down": KEY_S, "move_left": KEY_A, "move_right": KEY_D, "attack": KEY_SPACE, "ranged": KEY_F, "dodge": KEY_R, "interact": KEY_E, "potion": KEY_Q, "inventory": KEY_I, "artifact1": KEY_1, "artifact2": KEY_2, "artifact3": KEY_3}
var listening_action := ""
var master_volume := 1.0
var music_volume := 0.55
var sfx_volume := 0.8
var camera_zoom := 23.0
var high_quality_shadows := true
var show_damage_numbers := true
var fullscreen_mode := false
var window_resolution_index := 1
var vsync_enabled := true
var passive_regen_timer := 0.0
var selected_item_id := -1
var inventory_detail_box: VBoxContainer
var inventory_resource_box: HBoxContainer
var inventory_preview: CharacterBody3D
var rng := RandomNumberGenerator.new()
var pending_click := Vector2.ZERO
var click_pending := false
var sfx_player: AudioStreamPlayer
var camp_music: AudioStreamPlayer
var boss_name_label: Label
var boss_health_bar: ProgressBar
var boss_gate_wall: StaticBody3D
var procedural_material_cache: Dictionary = {}
var camp_merchant: Node3D
var camp_merchant_prompt: Label3D
var merchant_overlay: ColorRect
var merchant_item_list: VBoxContainer
var selected_enchant_index := 0
var return_camp_button: Button
var ui_layer: CanvasLayer
var hud: Control
var menu_overlay: ColorRect
var pause_overlay: ColorRect
var settings_overlay: ColorRect
var settings_buttons: Dictionary = {}
var settings_scroll: ScrollContainer
var settings_content: VBoxContainer
var salvage_confirmation_overlay: ColorRect
var salvage_confirmation_label: Label
var pending_salvage_item: Dictionary = {}
var mission_picker: OptionButton
var tier_picker: OptionButton
var health_bar: ProgressBar
var stability_bar: ProgressBar
var xp_bar: ProgressBar
var status_label: Label
var level_label: Label
var gear_box: VBoxContainer
var pack_box: VBoxContainer
var inventory_list: VBoxContainer
var inventory_overlay: ColorRect
var inventory_equipped_label: Label
var run_timer_label: Label
var objective_label: Label
var arrows_label: Label
var xp_text_label: Label
var potion_button: Button
var camp_table: Node3D
var camp_table_prompt: Label3D
var camp_table_ring: MeshInstance3D
var summary_label: Label
var hit_ring: MeshInstance3D
var arena_root: Node3D
var red_sword_cursor: Texture2D


func _ready() -> void:
	rng.randomize()
	_load_progress()
	_apply_window_preferences()
	_ensure_starter_gear()
	_create_lighting()
	_create_arena()
	_create_player()
	_create_camera()
	_create_ui()
	_setup_camp_music()
	_refresh_hud()
	_rebuild_gear_list()
	_rebuild_inventory()
	_show_menu()


func _physics_process(delta: float) -> void:
	if weapon_combo_reset_timer > 0.0:
		weapon_combo_reset_timer = maxf(0.0, weapon_combo_reset_timer - delta)
		if weapon_combo_reset_timer <= 0.0:
			weapon_combo_step = 0
	if in_camp:
		if not paused:
			status_timer = maxf(0.0, status_timer - delta)
			attack_timer = maxf(0.0, attack_timer - delta)
			for i in range(artifact_cooldowns.size()):
				artifact_cooldowns[i] = maxf(0.0, artifact_cooldowns[i] - delta)
			for effect_name in active_artifact_effects.keys():
				active_artifact_effects[effect_name] = maxf(0.0, float(active_artifact_effects[effect_name]) - delta)
				if float(active_artifact_effects[effect_name]) <= 0.0:
					active_artifact_effects.erase(effect_name)
					active_artifact_strength.erase(effect_name)
			if arrows < max_arrows:
				arrow_regen_timer -= delta
				if arrow_regen_timer <= 0.0:
					arrows += 1
					arrow_regen_timer = 0.8
			_process_player_motion(delta)
			_process_player_projectiles(delta)
			_update_camp_table_prompt()
			_update_camp_merchant_prompt()
			_follow_camera()
			_refresh_hud()
		return
	if not game_active or paused:
		return
	attack_timer = maxf(0.0, attack_timer - delta)
	for effect_name in active_artifact_effects.keys():
		active_artifact_effects[effect_name] = maxf(0.0, float(active_artifact_effects[effect_name]) - delta)
		if float(active_artifact_effects[effect_name]) <= 0.0:
			active_artifact_effects.erase(effect_name)
			active_artifact_strength.erase(effect_name)
	potion_cooldown = maxf(0.0, potion_cooldown - delta)
	arrow_regen_timer -= delta
	if arrow_regen_timer <= 0.0 and arrows < max_arrows:
		arrows += 1
		arrow_regen_timer = 0.8
	dash_timer = maxf(0.0, dash_timer - delta)
	dash_cooldown = maxf(0.0, dash_cooldown - delta)
	status_timer = maxf(0.0, status_timer - delta)
	attacked_highlight_timer = maxf(0.0, attacked_highlight_timer - delta)
	passive_regen_timer -= delta
	artifact_regen_tick -= delta
	if active_artifact_effects.has("Regeneration") and artifact_regen_tick <= 0.0:
		artifact_regen_tick = 1.0
		health = minf(max_health, health + max_health * 0.05 * float(active_artifact_strength.get("Regeneration", 1.0)))
	for artifact_index in range(artifact_cooldowns.size()):
		artifact_cooldowns[artifact_index] = maxf(0.0, artifact_cooldowns[artifact_index] - delta)
	hurt_timer = maxf(0.0, hurt_timer - delta)
	player_slow_timer = maxf(0.0, player_slow_timer - delta)
	if passive_regen_timer <= 0.0:
		passive_regen_timer = 1.0
		if String(gear.talisman.get("name", "")) == "Moonwell Charm" and health < max_health:
			health = minf(max_health, health + 1.0)
	if not boss_spawned and player.global_position.z <= -8.8 and absf(player.global_position.x - 4.0) < 2.5:
		boss_spawned = true
		boss_gate_wall = _add_static_box(arena_root, Vector3(2.35, 4.0, 0.7), Vector3(4.0, 2.0, -7.0), _material(Color("#e16f55"), 0.25, 1.2), "SealedBossGate")
		_spawn_enemy(true)
		_play_sfx("boss")
		if is_instance_valid(boss_actor):
			_spawn_ring_fx(boss_actor.global_position + Vector3(0.0, 0.08, 0.0), Color("#ff765c"), 7.0)
		_show_message("THE DEPTHS AWAKEN · %s" % BOSS_NAMES[selected_mission].to_upper())
	stability = minf(100.0, stability + delta * (0.19 + selected_tier * 0.018))
	spawn_timer -= delta
	chill_timer -= delta
	snowball_timer -= delta
	if chill_timer <= 0.0 and _has_armor_enchant("Chilling"):
		chill_timer = 2.0
		for foe in enemies:
			if is_instance_valid(foe) and _flat_distance(player.global_position, foe.global_position) < 6.0:
				foe.set_meta("slow_left", 1.0)
				_show_enchant_proc(foe, "Chilling", Color("#8de5ef"))
	if snowball_timer <= 0.0 and _has_armor_enchant("Snowball") and not enemies.is_empty():
		snowball_timer = 4.0
		var nearest := _nearest_enemy()
		if nearest != null:
			nearest.set_meta("stun_left", 1.15)
			_show_enchant_proc(nearest, "Snowball", Color("#9be9f5"))
	if spawn_timer <= 0.0 and enemies.size() < 6 + int(selected_tier * 0.2) and stability < 92.0:
		_spawn_enemy(false)
		spawn_timer = maxf(2.0, 6.0 - selected_tier * 0.11)
	_process_player_motion(delta)
	_process_enemies(delta)
	if not game_active:
		return
	_process_enemy_projectiles(delta)
	if not game_active:
		return
	_process_player_projectiles(delta)
	_process_loot(delta)
	_process_coin_drops(delta)
	_refresh_world_highlights()
	pressure_timer -= delta
	if stability > 72.0 and pressure_timer <= 0.0:
		pressure_timer = 1.6
		if _flat_distance(player.global_position, _nearest_fracture_position()) < 4.0:
			_damage_player(4.0 + selected_tier * 0.2)
	_follow_camera()
	_refresh_hud()


func _process(delta: float) -> void:
	if is_instance_valid(inventory_preview) and is_instance_valid(inventory_overlay) and inventory_overlay.visible:
		_animate_actor(inventory_preview, delta)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if listening_action != "":
			keybinds[listening_action] = event.keycode
			listening_action = ""
			_refresh_settings_buttons()
			_save_progress()
			_play_sfx("click")
			return
		if settings_overlay.visible and event.keycode == KEY_ESCAPE:
			settings_overlay.visible = false
			return
		if event.keycode == KEY_ESCAPE:
			if salvage_confirmation_overlay.visible:
				_cancel_salvage()
			elif is_instance_valid(merchant_overlay) and merchant_overlay.visible:
				_close_merchant()
			elif inventory_overlay.visible:
				_toggle_inventory()
			else:
				_toggle_pause()
		elif event.keycode == int(keybinds.artifact1):
			_use_artifact(0)
		elif event.keycode == int(keybinds.artifact2):
			_use_artifact(1)
		elif event.keycode == int(keybinds.artifact3):
			_use_artifact(2)
		elif event.keycode == int(keybinds.inventory) and (game_active or in_camp):
			_toggle_inventory()
		elif event.keycode == int(keybinds.interact) and (game_active or in_camp) and not paused:
			_interact_with_nearby()
		elif event.keycode == int(keybinds.dodge) and game_active and not paused:
			_start_dash()
		elif event.keycode == int(keybinds.potion) and game_active and not paused:
			_use_healing_potion()
		elif event.keycode == int(keybinds.attack) and (game_active or in_camp) and not paused:
			_attack()
		elif event.keycode == int(keybinds.ranged) and (game_active or in_camp) and not paused:
			_fire_player_ranged(get_viewport().get_mouse_position())
		elif event.keycode in [int(keybinds.move_up), int(keybinds.move_down), int(keybinds.move_left), int(keybinds.move_right), KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT]:
			has_move_goal = false
			target_actor = null
	elif event is InputEventMouseMotion:
		_update_sword_cursor(event.position)
		if (game_active or in_camp) and not paused and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
			pending_click = event.position
			click_pending = true
	elif event is InputEventMouseButton and event.pressed:
		if (game_active or in_camp) and not paused and event.button_index == MOUSE_BUTTON_RIGHT:
			_fire_player_ranged(event.position)
		elif (game_active or in_camp) and not paused and event.button_index == MOUSE_BUTTON_LEFT:
			pending_click = event.position
			click_pending = true
			_play_sfx("click")


func _create_lighting() -> void:
	var world := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color("#17242b")
	sky_material.sky_horizon_color = Color("#52645c")
	sky_material.ground_bottom_color = Color("#11191b")
	sky_material.ground_horizon_color = Color("#303b37")
	sky.sky_material = sky_material
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#a4b9a4")
	environment.ambient_light_energy = 0.62
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.glow_enabled = true
	environment.glow_intensity = 0.35
	environment.glow_strength = 0.55
	environment.ssao_enabled = true
	environment.ssao_radius = 1.15
	environment.ssao_intensity = 1.2
	environment.fog_enabled = true
	environment.fog_light_color = Color("#788681")
	environment.fog_density = 0.004
	world.environment = environment
	add_child(world)
	var sun := DirectionalLight3D.new()
	sun.name = "DungeonSun"
	sun.rotation_degrees = Vector3(-52.0, -34.0, 0.0)
	sun.light_color = Color("#ffe7c1")
	sun.light_energy = 1.25
	sun.shadow_enabled = high_quality_shadows
	add_child(sun)


func _create_arena() -> void:
	arena_root = Node3D.new()
	arena_root.name = "Dungeon"
	add_child(arena_root)


func _build_camp_scene() -> void:
	if not is_instance_valid(arena_root):
		return
	for child in arena_root.get_children():
		if child == hit_ring or child == player:
			continue
		child.queue_free()
	camp_table = null
	camp_table_prompt = null
	camp_table_ring = null
	var colors: Array = MISSION_COLORS[selected_mission]
	_add_static_box(arena_root, Vector3(38.0, 0.4, 30.0), Vector3(0.0, -0.22, 0.0), _make_textured_material(Color("#43534b"), Vector3(16.0, 14.0, 1.0), 1), "CampGround")
	_add_static_box(arena_root, Vector3(1.0, 2.4, 30.0), Vector3(-18.8, 1.0, 0.0), _material(Color("#554633")), "CampFence")
	_add_static_box(arena_root, Vector3(1.0, 2.4, 30.0), Vector3(18.8, 1.0, 0.0), _material(Color("#554633")), "CampFence")
	_add_static_box(arena_root, Vector3(38.0, 2.4, 1.0), Vector3(0.0, 1.0, -14.5), _material(Color("#554633")), "CampFence")
	_add_static_box(arena_root, Vector3(38.0, 2.4, 1.0), Vector3(0.0, 1.0, 14.5), _material(Color("#554633")), "CampFence")
	_add_static_box(arena_root, Vector3(3.0, 0.04, 18.0), Vector3(0.0, 0.02, 2.0), _material(Color("#766348")), "CampPath")
	for side in [-1.0, 1.0]:
		var tent := MeshInstance3D.new()
		var tent_mesh := PrismMesh.new()
		tent_mesh.size = Vector3(4.0, 2.4, 3.2)
		tent.mesh = tent_mesh
		tent.position = Vector3(side * 7.0, 1.15, -3.0)
		tent.material_override = _material(colors[0].lightened(0.12))
		arena_root.add_child(tent)
		_add_static_box(arena_root, Vector3(3.7, 0.18, 3.0), Vector3(side * 7.0, 0.1, -3.0), _material(Color("#3b3831")), "TentBase")
		_add_static_box(arena_root, Vector3(1.3, 0.9, 1.0), Vector3(side * 7.0, 0.55, 1.0), _material(Color("#896545")), "SupplyCrate")
	var fire := MeshInstance3D.new()
	var flame := SphereMesh.new()
	flame.radius = 0.42
	flame.height = 0.9
	flame.radial_segments = 8
	flame.rings = 4
	fire.mesh = flame
	fire.position = Vector3(0.0, 0.55, -2.5)
	fire.material_override = _material(Color("#ff914f"), 0.3, 1.4)
	arena_root.add_child(fire)
	for i in range(8):
		var angle := TAU * float(i) / 8.0
		_add_static_box(arena_root, Vector3(0.5, 0.3, 0.5), Vector3(cos(angle) * 0.85, 0.14, -2.5 + sin(angle) * 0.85), _material(Color("#73746c")), "FireStone")
	var camp_light := OmniLight3D.new()
	camp_light.position = Vector3(0.0, 2.0, -2.5)
	camp_light.light_color = Color("#ff9a5e")
	camp_light.light_energy = 2.0
	camp_light.omni_range = 9.0
	arena_root.add_child(camp_light)
	_create_expedition_table()
	_create_camp_merchant()
	_create_training_dummy(Vector3(-10.0, 0.0, 2.0), "PRACTICE · SOULS", Color("#d6ad67"))
	_create_training_dummy(Vector3(10.0, 0.0, 2.0), "PRACTICE · ABILITIES", Color("#83c9d5"))
	for side in [-1.0, 1.0]:
		_add_static_box(arena_root, Vector3(0.18, 3.2, 0.18), Vector3(side * 12.0, 1.6, -7.0), _material(Color("#554633")), "CampPost")
		var lantern := MeshInstance3D.new()
		var lantern_mesh := BoxMesh.new()
		lantern_mesh.size = Vector3(0.5, 0.65, 0.5)
		lantern.mesh = lantern_mesh
		lantern.position = Vector3(side * 12.0, 3.0, -7.0)
		lantern.material_override = _material(Color("#ffd78d"), 0.25, 0.8)
		arena_root.add_child(lantern)
	if is_instance_valid(player):
		player.global_position = Vector3(0.0, 0.0, 5.0)
		player.velocity = Vector3.ZERO
		_follow_camera()


func _create_training_dummy(at: Vector3, caption: String, accent: Color) -> void:
	var dummy := _create_actor("Training Dummy", false, Color("#92734f"), 420.0)
	dummy.name = "CampTrainingDummy"
	dummy.position = at
	dummy.set_meta("practice_dummy", true)
	dummy.set_meta("soul_award_timer", 0.0)
	enemies.append(dummy)
	_refresh_enemy_health_bar(dummy)
	var target_board := MeshInstance3D.new()
	var board_mesh := BoxMesh.new()
	board_mesh.size = Vector3(1.05, 1.15, 0.18)
	target_board.mesh = board_mesh
	target_board.position = Vector3(0.0, 1.0, 0.55)
	target_board.material_override = _material(accent, 0.85, 0.12)
	dummy.add_child(target_board)
	var center_ring := MeshInstance3D.new()
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 0.22
	ring_mesh.outer_radius = 0.29
	center_ring.mesh = ring_mesh
	center_ring.position = Vector3(0.0, 1.0, 0.44)
	center_ring.material_override = _material(Color("#eee2c6"), 0.35, 0.25)
	dummy.add_child(center_ring)
	var nameplate := Label3D.new()
	nameplate.text = caption
	nameplate.font_size = 23
	nameplate.outline_size = 6
	nameplate.outline_modulate = Color("#171b1a")
	nameplate.modulate = accent
	nameplate.position = Vector3(0.0, 3.25, 0.0)
	nameplate.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	nameplate.no_depth_test = true
	dummy.add_child(nameplate)


func _create_expedition_table() -> void:
	camp_table = Node3D.new()
	camp_table.name = "ExpeditionTable"
	camp_table.position = Vector3(0.0, 0.0, -8.0)
	var top := MeshInstance3D.new()
	var top_mesh := BoxMesh.new()
	top_mesh.size = Vector3(3.4, 0.28, 2.1)
	top.mesh = top_mesh
	top.position.y = 1.0
	top.material_override = _material(Color("#725238"), 0.68)
	top.visible = false
	camp_table.add_child(top)
	for x in [-1.35, 1.35]:
		for z in [-0.75, 0.75]:
			var leg := MeshInstance3D.new()
			var leg_mesh := BoxMesh.new()
			leg_mesh.size = Vector3(0.2, 1.0, 0.2)
			leg.mesh = leg_mesh
			leg.position = Vector3(x, 0.5, z)
			leg.material_override = _material(Color("#49382d"))
			camp_table.add_child(leg)
	var map := MeshInstance3D.new()
	var map_mesh := BoxMesh.new()
	map_mesh.size = Vector3(2.0, 0.06, 1.25)
	map.mesh = map_mesh
	map.position = Vector3(0.0, 1.19, 0.0)
	map.material_override = _material(Color("#96b878"), 0.46, 0.18)
	camp_table.add_child(map)
	var map_marker := MeshInstance3D.new()
	var marker_mesh := PrismMesh.new()
	marker_mesh.size = Vector3(0.35, 0.4, 0.35)
	map_marker.mesh = marker_mesh
	map_marker.position = Vector3(0.2, 1.43, -0.15)
	map_marker.material_override = _material(Color("#d87c58"), 0.3, 0.55)
	camp_table.add_child(map_marker)
	var title := Label3D.new()
	title.text = "EXPEDITION TABLE"
	title.font_size = 30
	title.outline_size = 7
	title.position = Vector3(0.0, 2.0, 0.0)
	title.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	title.no_depth_test = true
	camp_table.add_child(title)
	camp_table_prompt = Label3D.new()
	camp_table_prompt.text = "E"
	camp_table_prompt.font_size = 60
	camp_table_prompt.outline_size = 12
	camp_table_prompt.outline_modulate = Color.WHITE
	camp_table_prompt.position = Vector3(0.0, 2.8, 0.0)
	camp_table_prompt.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	camp_table_prompt.no_depth_test = true
	camp_table_prompt.visible = false
	camp_table.add_child(camp_table_prompt)
	camp_table_ring = MeshInstance3D.new()
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 1.75
	ring_mesh.outer_radius = 1.86
	camp_table_ring.mesh = ring_mesh
	camp_table_ring.rotation_degrees.x = 90.0
	camp_table_ring.position.y = 0.055
	camp_table_ring.material_override = _material(Color.WHITE, 0.3, 0.65)
	camp_table_ring.visible = false
	camp_table.add_child(camp_table_ring)
	_arena_add_collision_for_table()
	arena_root.add_child(camp_table)


func _arena_add_collision_for_table() -> void:
	_add_static_box(arena_root, Vector3(3.4, 0.28, 2.1), Vector3(0.0, 1.0, -8.0), _material(Color("#725238"), 0.68), "ExpeditionDeskCollision")


func _create_camp_merchant() -> void:
	camp_merchant = Node3D.new()
	camp_merchant.name = "CampEnchantmentMerchant"
	camp_merchant.position = Vector3(-13.0, 0.0, 7.0)
	var body := MeshInstance3D.new()
	var body_mesh := BoxMesh.new()
	body_mesh.size = Vector3(0.86, 1.0, 0.62)
	body.mesh = body_mesh
	body.position.y = 0.72
	body.material_override = _material(Color("#7667a1"), 0.75)
	camp_merchant.add_child(body)
	var hood := MeshInstance3D.new()
	var hood_mesh := PrismMesh.new()
	hood_mesh.size = Vector3(0.9, 0.82, 0.74)
	hood.mesh = hood_mesh
	hood.position.y = 1.55
	hood.material_override = _material(Color("#cfad68"), 0.72)
	camp_merchant.add_child(hood)
	var face := MeshInstance3D.new()
	var face_mesh := BoxMesh.new()
	face_mesh.size = Vector3(0.43, 0.36, 0.08)
	face.mesh = face_mesh
	face.position = Vector3(0.0, 1.45, -0.4)
	face.material_override = _material(Color("#d8c5a0"), 0.82)
	camp_merchant.add_child(face)
	var counter := MeshInstance3D.new()
	var counter_mesh := BoxMesh.new()
	counter_mesh.size = Vector3(2.1, 0.7, 1.0)
	counter.mesh = counter_mesh
	counter.position = Vector3(0.0, 0.45, -1.15)
	counter.material_override = _material(Color("#523e32"), 0.78)
	camp_merchant.add_child(counter)
	var sign := Label3D.new()
	sign.text = "ENCHANTER · REROLLS"
	sign.font_size = 25
	sign.outline_size = 6
	sign.position = Vector3(0.0, 2.4, 0.0)
	sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	sign.no_depth_test = true
	sign.modulate = Color("#e8ce91")
	camp_merchant.add_child(sign)
	camp_merchant_prompt = Label3D.new()
	camp_merchant_prompt.text = "E"
	camp_merchant_prompt.font_size = 60
	camp_merchant_prompt.outline_size = 12
	camp_merchant_prompt.outline_modulate = Color.WHITE
	camp_merchant_prompt.position = Vector3(0.0, 3.0, 0.0)
	camp_merchant_prompt.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	camp_merchant_prompt.no_depth_test = true
	camp_merchant_prompt.visible = false
	camp_merchant.add_child(camp_merchant_prompt)
	arena_root.add_child(camp_merchant)


func _update_camp_merchant_prompt() -> void:
	if not is_instance_valid(camp_merchant) or not is_instance_valid(player):
		return
	var close := _flat_distance(player.global_position, camp_merchant.global_position) <= 3.4
	if is_instance_valid(camp_merchant_prompt):
		camp_merchant_prompt.visible = close
	if close:
		status_message = "Press %s to reroll gear enchantments" % _key_name(int(keybinds.interact))
		status_timer = 0.12


func _update_camp_table_prompt() -> void:
	if not is_instance_valid(camp_table) or not is_instance_valid(player):
		return
	var close := _flat_distance(player.global_position, camp_table.global_position) <= 3.2
	if is_instance_valid(camp_table_prompt):
		camp_table_prompt.visible = close
	if is_instance_valid(camp_table_ring):
		camp_table_ring.visible = close
	if close:
		status_message = "Press %s to choose a dungeon" % _key_name(int(keybinds.interact))
		status_timer = 0.12


func _add_floor_details(colors: Array) -> void:
	for i in range(28):
		var pebble := MeshInstance3D.new()
		var mesh := BoxMesh.new()
		mesh.size = Vector3(rng.randf_range(0.05, 0.18), 0.035, rng.randf_range(0.05, 0.18))
		pebble.mesh = mesh
		pebble.position = Vector3(rng.randf_range(-14.0, 14.0), 0.015, rng.randf_range(-10.0, 10.0))
		pebble.material_override = _material(colors[2].darkened(rng.randf_range(0.0, 0.35)))
		arena_root.add_child(pebble)
	for i in range(5):
		var crystal := MeshInstance3D.new()
		var mesh := PrismMesh.new()
		mesh.size = Vector3(0.5, rng.randf_range(1.1, 2.0), 0.5)
		crystal.mesh = mesh
		crystal.position = Vector3(rng.randf_range(-13.0, 13.0), 0.7, rng.randf_range(-9.0, 9.0))
		crystal.material_override = _material(colors[2].lightened(0.18), 0.24, 0.45)
		arena_root.add_child(crystal)


func _add_wall(at: Vector3, color: Color, size: Vector3 = Vector3(2.0, 2.0, 2.0)) -> void:
	_add_static_box(arena_root, size, at, _make_textured_material(color, Vector3(1.0, 1.0, 1.0), 0), "DungeonBlock")


func _make_textured_material(base_color: Color, uv_scale: Vector3, tile_style: int) -> StandardMaterial3D:
	# Small seamless procedural color and normal maps add stone grain and grout
	# without downloading assets or requiring an editor import step.
	var cache_key := "%d:%d:%s" % [selected_mission, tile_style, str(base_color)]
	if procedural_material_cache.has(cache_key):
		return procedural_material_cache[cache_key]
	const texture_size := 128
	var noise := FastNoiseLite.new()
	noise.seed = 406 + selected_mission * 83 + tile_style * 17
	noise.frequency = 0.055 if tile_style == 0 else 0.035
	noise.fractal_octaves = 4
	noise.fractal_gain = 0.48
	var noise_image := noise.get_seamless_image(texture_size, texture_size, false, false, 0.2, true)
	var albedo_image := Image.create(texture_size, texture_size, false, Image.FORMAT_RGBA8)
	var heights := PackedFloat32Array()
	heights.resize(texture_size * texture_size)
	for y in range(texture_size):
		for x in range(texture_size):
			var n := noise_image.get_pixel(x, y).r
			var brightness: float = 0.72 + n * 0.32
			var groove := false
			if tile_style == 0:
				var row_offset := 32 if int(y / 32) % 2 == 1 else 0
				groove = y % 32 < 2 or (x + row_offset) % 64 < 2
			else:
				groove = x % 32 < 2 or y % 32 < 2
			if groove:
				brightness = 0.44 + n * 0.12
			var index := y * texture_size + x
			heights[index] = brightness
			albedo_image.set_pixel(x, y, Color(brightness, brightness, brightness, 1.0))
	var normal_image := Image.create(texture_size, texture_size, false, Image.FORMAT_RGBA8)
	for y in range(texture_size):
		for x in range(texture_size):
			var left := heights[y * texture_size + (x - 1 + texture_size) % texture_size]
			var right := heights[y * texture_size + (x + 1) % texture_size]
			var up := heights[((y - 1 + texture_size) % texture_size) * texture_size + x]
			var down := heights[((y + 1) % texture_size) * texture_size + x]
			var nx: float = clampf(0.5 - (right - left) * 1.4, 0.0, 1.0)
			var ny: float = clampf(0.5 - (down - up) * 1.4, 0.0, 1.0)
			normal_image.set_pixel(x, y, Color(nx, ny, 0.96, 1.0))
	albedo_image.generate_mipmaps()
	normal_image.generate_mipmaps()
	var mat := StandardMaterial3D.new()
	mat.albedo_color = base_color
	mat.albedo_texture = ImageTexture.create_from_image(albedo_image)
	mat.normal_enabled = true
	mat.normal_texture = ImageTexture.create_from_image(normal_image)
	mat.normal_scale = 0.42
	mat.roughness = 0.9
	mat.uv1_scale = uv_scale
	procedural_material_cache[cache_key] = mat
	return mat


func _add_static_box(parent: Node3D, size: Vector3, at: Vector3, mat: Material, node_name: String) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = at
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	var visual := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	visual.mesh = box
	visual.material_override = mat
	body.add_child(visual)
	parent.add_child(body)
	return body


func _create_player() -> void:
	player = _create_actor("Wayfinder", false, Color("#72c6a7"), 100.0)
	player.position = Vector3(0.0, 0.0, 0.0)
	_refresh_player_gear_visuals()


func _create_actor(actor_name: String, is_boss: bool, color: Color, hp: float) -> CharacterBody3D:
	var actor := CharacterBody3D.new()
	actor.name = actor_name
	actor.collision_layer = 2 if actor_name != "Wayfinder" else 1
	actor.collision_mask = 1
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.36 if not is_boss else 0.7
	capsule.height = 1.45 if not is_boss else 2.65
	collision.shape = capsule
	collision.position.y = capsule.height * 0.5
	actor.add_child(collision)
	var body_mesh := MeshInstance3D.new()
	body_mesh.name = "Torso"
	var body_box := BoxMesh.new()
	body_box.size = Vector3(0.78, 1.0, 0.62) if not is_boss else Vector3(1.55, 1.7, 1.1)
	body_mesh.mesh = body_box
	body_mesh.material_override = _material(color, 0.7)
	body_mesh.position.y = body_box.size.y * 0.5 + 0.08
	actor.add_child(body_mesh)
	var head := MeshInstance3D.new()
	var head_mesh := BoxMesh.new()
	head_mesh.size = Vector3(0.62, 0.62, 0.62) if not is_boss else Vector3(0.96, 0.9, 0.9)
	head_mesh.material = _material(Color("#d9cba9") if actor_name == "Wayfinder" else color.lightened(0.25))
	head.mesh = head_mesh
	head.position.y = (1.48 if not is_boss else 2.12)
	actor.add_child(head)
	if is_boss:
		for side in [-1.0, 1.0]:
			var crest := MeshInstance3D.new()
			var crest_mesh := PrismMesh.new()
			crest_mesh.size = Vector3(0.38, 0.82, 0.38)
			crest.mesh = crest_mesh
			crest.position = Vector3(side * 0.48, 2.55, 0.0)
			crest.rotation_degrees.z = side * -18.0
			crest.material_override = _material(color.lightened(0.35), 0.24, 0.9)
			actor.add_child(crest)
	for side in [-1.0, 1.0]:
		var eye := MeshInstance3D.new()
		var eye_mesh := BoxMesh.new()
		eye_mesh.size = Vector3(0.07, 0.08, 0.045) if not is_boss else Vector3(0.1, 0.12, 0.06)
		eye.mesh = eye_mesh
		eye.position = Vector3(side * (0.12 if not is_boss else 0.2), head.position.y, -0.245 if not is_boss else -0.42)
		eye.material_override = _material(Color("#f6e9c7") if is_boss else Color("#202a2a"), 0.4, 0.0)
		actor.add_child(eye)
		var arm := MeshInstance3D.new()
		arm.name = "ArmLeft" if side < 0.0 else "ArmRight"
		var arm_mesh := BoxMesh.new()
		arm_mesh.size = Vector3(0.28, 0.78, 0.4) if not is_boss else Vector3(0.52, 1.2, 0.58)
		arm.mesh = arm_mesh
		arm.position = Vector3(side * (0.52 if not is_boss else 1.03), 0.78 if not is_boss else 1.2, 0.0)
		arm.material_override = _material(color.darkened(0.12), 0.75)
		actor.add_child(arm)
		var leg := MeshInstance3D.new()
		leg.name = "LegLeft" if side < 0.0 else "LegRight"
		var leg_mesh := BoxMesh.new()
		leg_mesh.size = Vector3(0.3, 0.58, 0.42) if not is_boss else Vector3(0.56, 0.72, 0.62)
		leg.mesh = leg_mesh
		leg.position = Vector3(side * (0.21 if not is_boss else 0.38), 0.31 if not is_boss else 0.42, 0.0)
		leg.material_override = _material(color.darkened(0.28), 0.82)
		actor.add_child(leg)
	actor.set_meta("health", hp)
	actor.set_meta("max_health", hp)
	actor.set_meta("speed", 2.2 if not is_boss else 1.25)
	actor.set_meta("attack_cd", 0.8)
	actor.set_meta("boss", is_boss)
	actor.set_meta("walk_phase", rng.randf_range(0.0, TAU))
	actor.set_meta("attack_anim", 0.0)
	actor.set_meta("torso_base_y", body_mesh.position.y)
	if actor_name != "Wayfinder":
		actor.add_to_group("enemies")
	arena_root.add_child(actor)
	if actor_name != "Wayfinder":
		_add_enemy_health_bar(actor, is_boss)
	return actor


func _refresh_player_gear_visuals() -> void:
	if not is_instance_valid(player):
		return
	for child in player.get_children():
		if child.name.begins_with("EquippedArmor_"):
			child.queue_free()
	var right_arm := player.get_node_or_null("ArmRight") as MeshInstance3D
	if is_instance_valid(right_arm):
		for child in right_arm.get_children():
			if child.name.begins_with("EquippedWeapon"):
				child.queue_free()
		var weapon: Dictionary = gear.weapon
		if weapon.is_empty():
			weapon = {"name": "Wayfinder Blade", "rarity": "Common"}
		_build_weapon_visual(right_arm, weapon)
	_add_armor_visual("helmet", gear.helmet)
	_add_armor_visual("armor", gear.armor)
	_add_armor_visual("leggings", gear.leggings)
	_add_armor_visual("boots", gear.boots)


func _build_weapon_visual(hand: Node3D, item: Dictionary) -> void:
	var weapon_name := String(item.get("name", "Wayfinder Blade"))
	var weapon_class := String(WEAPON_CLASSES.get(weapon_name, "Medium"))
	var color := _weapon_visual_color(weapon_name)
	var pivot := Node3D.new()
	pivot.name = "EquippedWeaponPivot"
	pivot.position = Vector3(0.0, -0.27, -0.08)
	pivot.rotation_degrees.z = -12.0
	hand.add_child(pivot)
	var metal := _material(color, 0.24, 0.12)
	var handle_mat := _material(Color("#604433"), 0.78)
	_add_gear_box(pivot, "EquippedWeaponGrip", Vector3(0.12, 0.3, 0.13), Vector3(0.0, 0.06, 0.0), handle_mat)
	_add_gear_box(pivot, "EquippedWeaponPommel", Vector3(0.17, 0.12, 0.15), Vector3(0.0, 0.2, 0.0), metal)
	if weapon_class == "Axe":
		_add_gear_box(pivot, "EquippedWeaponHaft", Vector3(0.12, 0.78, 0.14), Vector3(0.0, -0.24, 0.0), handle_mat)
		_add_gear_box(pivot, "EquippedWeaponAxeHead", Vector3(0.68, 0.38, 0.2), Vector3(0.25, -0.28, 0.0), metal)
		_add_gear_box(pivot, "EquippedWeaponAxeEdge", Vector3(0.12, 0.46, 0.22), Vector3(0.54, -0.28, 0.0), _material(color.lightened(0.35), 0.2, 0.2))
	else:
		var blade_size := Vector3(0.13, 0.75, 0.12)
		var blade_at := Vector3(0.0, -0.5, 0.0)
		if weapon_class == "Light":
			blade_size = Vector3(0.1, 0.66, 0.1)
			_add_gear_box(pivot, "EquippedWeaponGuard", Vector3(0.3, 0.08, 0.15), Vector3(0.0, -0.1, 0.0), metal)
		elif weapon_class == "Heavy":
			blade_size = Vector3(0.31, 1.05, 0.2)
			blade_at.y = -0.67
			_add_gear_box(pivot, "EquippedWeaponGuard", Vector3(0.48, 0.14, 0.18), Vector3(0.0, -0.12, 0.0), metal)
		else:
			blade_size = Vector3(0.22, 0.94, 0.16)
			blade_at.y = -0.61
			_add_gear_box(pivot, "EquippedWeaponGuard", Vector3(0.4, 0.1, 0.16), Vector3(0.0, -0.12, 0.0), metal)
		_add_gear_box(pivot, "EquippedWeaponBlade", blade_size, blade_at, metal)
		_add_gear_box(pivot, "EquippedWeaponSpine", Vector3(0.045, blade_size.y * 0.78, 0.045), blade_at + Vector3(0.0, 0.0, -0.085), _material(color.lightened(0.4), 0.2, 0.25))


func _weapon_visual_color(weapon_name: String) -> Color:
	match weapon_name:
		"Graveglass Saber": return Color("#83dce7")
		"Whisper Daggers": return Color("#e0e5e8")
		"Emberfang Longsword": return Color("#ea9867")
		"Stonebreaker Greatblade": return Color("#aeb6c0")
		"Hollowfang": return Color("#c6aa7f")
		"Stormsplitter Axe": return Color("#f0cf76")
		_: return Color("#e4d6ab")


func _add_armor_visual(slot: String, item: Dictionary) -> void:
	if item.is_empty():
		return
	var tint := _rarity_color(String(item.get("rarity", "Common")))
	var dark := tint.darkened(0.28)
	var shine := tint.lightened(0.22)
	match slot:
		"helmet":
			_add_gear_box(player, "EquippedArmor_Helmet", Vector3(0.78, 0.36, 0.72), Vector3(0.0, 1.73, 0.0), _material(tint, 0.55))
			_add_gear_box(player, "EquippedArmor_Visor", Vector3(0.6, 0.12, 0.08), Vector3(0.0, 1.65, -0.38), _material(dark, 0.32, 0.1))
			for side in [-1.0, 1.0]:
				_add_gear_box(player, "EquippedArmor_HelmetTrim", Vector3(0.12, 0.23, 0.14), Vector3(side * 0.42, 1.47, 0.0), _material(shine, 0.3, 0.1))
		"armor":
			_add_gear_box(player, "EquippedArmor_Chestplate", Vector3(0.88, 0.78, 0.7), Vector3(0.0, 1.02, 0.0), _material(tint, 0.62))
			_add_gear_box(player, "EquippedArmor_ChestEmblem", Vector3(0.28, 0.44, 0.09), Vector3(0.0, 1.05, -0.39), _material(shine, 0.3, 0.12))
			for side in [-1.0, 1.0]:
				_add_gear_box(player, "EquippedArmor_Shoulder", Vector3(0.36, 0.25, 0.54), Vector3(side * 0.48, 1.42, 0.0), _material(dark, 0.6))
		"leggings":
			for side in [-1.0, 1.0]:
				_add_gear_box(player, "EquippedArmor_Legging", Vector3(0.35, 0.48, 0.48), Vector3(side * 0.21, 0.43, 0.0), _material(tint, 0.7))
		"boots":
			for side in [-1.0, 1.0]:
				_add_gear_box(player, "EquippedArmor_Boot", Vector3(0.38, 0.25, 0.58), Vector3(side * 0.21, 0.14, -0.04), _material(tint.darkened(0.12), 0.75))


func _add_gear_box(parent: Node3D, node_name: String, size: Vector3, at: Vector3, mat: Material) -> MeshInstance3D:
	var visual := MeshInstance3D.new()
	visual.name = node_name
	var box := BoxMesh.new()
	box.size = size
	visual.mesh = box
	visual.position = at
	visual.material_override = mat
	parent.add_child(visual)
	return visual


func _add_boss_distinction(actor: CharacterBody3D, boss_index: int, color: Color) -> void:
	var feature := MeshInstance3D.new()
	feature.name = "LocationBossSignature"
	feature.position.y = 3.05
	match boss_index:
		0:
			var halo := TorusMesh.new()
			halo.inner_radius = 0.58
			halo.outer_radius = 0.78
			feature.mesh = halo
			feature.rotation_degrees.x = 90.0
			feature.material_override = _material(Color("#83dff0"), 0.18, 1.5)
		1:
			var leaf_crown := PrismMesh.new()
			leaf_crown.size = Vector3(1.55, 1.45, 0.7)
			feature.mesh = leaf_crown
			feature.material_override = _material(Color("#b5d96d"), 0.32, 0.7)
		2:
			var tusk := BoxMesh.new()
			tusk.size = Vector3(1.5, 0.55, 0.8)
			feature.mesh = tusk
			feature.position.y = 2.55
			feature.rotation_degrees.z = -18.0
			feature.material_override = _material(Color("#e4d0a2"), 0.7)
		3:
			var hive := CylinderMesh.new()
			hive.top_radius = 0.76
			hive.bottom_radius = 0.55
			hive.height = 0.9
			hive.radial_segments = 6
			feature.mesh = hive
			feature.material_override = _material(Color("#f4c04d"), 0.35, 0.8)
		4:
			var ring := TorusMesh.new()
			ring.inner_radius = 0.35
			ring.outer_radius = 0.65
			feature.mesh = ring
			feature.rotation_degrees.x = 90.0
			feature.material_override = _material(Color("#bd8cf2"), 0.16, 1.8)
		5:
			var ice_peak := PrismMesh.new()
			ice_peak.size = Vector3(1.2, 1.8, 1.0)
			feature.mesh = ice_peak
			feature.material_override = _material(Color("#b2efff"), 0.2, 1.4)
		6:
			var horns := BoxMesh.new()
			horns.size = Vector3(1.8, 0.38, 0.42)
			feature.mesh = horns
			feature.rotation_degrees.z = 22.0
			feature.material_override = _material(Color("#d5a979"), 0.65)
	actor.add_child(feature)
	var aura := MeshInstance3D.new()
	var aura_mesh := TorusMesh.new()
	aura_mesh.inner_radius = 1.25
	aura_mesh.outer_radius = 1.38
	aura.mesh = aura_mesh
	aura.rotation_degrees.x = 90.0
	aura.position.y = 0.08
	aura.material_override = _material(color.lightened(0.3), 0.25, 0.85)
	actor.add_child(aura)


func _add_enemy_health_bar(actor: CharacterBody3D, is_boss: bool) -> void:
	var bar_root := Node3D.new()
	bar_root.name = "EnemyHealthBar"
	bar_root.position.y = 3.15 if is_boss else 2.0
	bar_root.set_meta("width", 1.6 if is_boss else 1.0)
	var width: float = float(bar_root.get_meta("width"))
	var background := MeshInstance3D.new()
	var back_mesh := BoxMesh.new()
	back_mesh.size = Vector3(width, 0.12, 0.055)
	background.mesh = back_mesh
	background.material_override = _material(Color("#18201f"), 0.9)
	bar_root.add_child(background)
	var fill := MeshInstance3D.new()
	var fill_mesh := BoxMesh.new()
	fill_mesh.size = Vector3(width - 0.04, 0.075, 0.065)
	fill.mesh = fill_mesh
	fill.position.z = -0.035
	fill.material_override = _material(Color("#e45d57") if is_boss else Color("#dc8063"), 0.45, 0.3)
	bar_root.add_child(fill)
	bar_root.set_meta("fill", fill)
	bar_root.set_meta("full_width", width - 0.04)
	actor.add_child(bar_root)
	actor.set_meta("health_bar_node", bar_root)


func _refresh_enemy_health_bar(actor: CharacterBody3D) -> void:
	var bar_root: Node3D = actor.get_meta("health_bar_node", null)
	if not is_instance_valid(bar_root):
		return
	var fill: MeshInstance3D = bar_root.get_meta("fill", null)
	if not is_instance_valid(fill):
		return
	var fraction := clampf(float(actor.get_meta("health", 0.0)) / maxf(1.0, float(actor.get_meta("max_health", 1.0))), 0.0, 1.0)
	var width := float(bar_root.get_meta("full_width", 1.0))
	fill.scale.x = maxf(0.001, fraction)
	fill.position.x = -(width * (1.0 - fraction) * 0.5)
	if is_instance_valid(camera):
		bar_root.look_at(camera.global_position, Vector3.UP)


func _handle_training_dummy_hit(actor: CharacterBody3D, damage: float) -> bool:
	if not bool(actor.get_meta("practice_dummy", false)):
		return false
	var max_hp := float(actor.get_meta("max_health", 420.0))
	var hp := float(actor.get_meta("health", max_hp))
	if hp <= 0.0:
		hp = max_hp
		actor.set_meta("health", hp)
		_spawn_ring_fx(actor.global_position + Vector3.UP * 0.08, Color("#ffe2a1"), 1.8)
	var souls_awarded := mini(MAX_SOULS - souls, maxi(2, roundi(damage / 7.0)))
	souls += souls_awarded
	if souls_awarded > 0:
		_show_message("TRAINING HIT · +%d souls · %d/%d" % [souls_awarded, souls, MAX_SOULS])
	_refresh_enemy_health_bar(actor)
	_refresh_hud()
	_save_progress()
	return true


func _ensure_outline_material() -> void:
	if is_instance_valid(outline_material):
		return
	var shader := Shader.new()
	shader.code = "shader_type spatial; render_mode unshaded, cull_front; void vertex() { VERTEX += NORMAL * 0.035; } void fragment() { ALBEDO = vec3(1.0); }"
	outline_material = ShaderMaterial.new()
	outline_material.shader = shader


func _set_node_outline(node: Node3D, enabled: bool) -> void:
	_ensure_outline_material()
	for child in node.get_children():
		if child is MeshInstance3D:
			child.material_overlay = outline_material if enabled else null
		elif child is Node3D:
			if child.name != "EnemyHealthBar":
				_set_node_outline(child, enabled)


func _refresh_world_highlights() -> void:
	for foe in enemies:
		if is_instance_valid(foe):
			var outlined := foe == target_actor or foe == hover_actor or (foe == recently_attacked_actor and attacked_highlight_timer > 0.0)
			_set_node_outline(foe, outlined)
			_refresh_enemy_health_bar(foe)
	var nearest: Node3D
	var nearest_distance := 2.4
	for object in dungeon_interactables:
		if not is_instance_valid(object) or bool(object.get_meta("used", false)):
			continue
		var distance := _flat_distance(player.global_position, object.global_position)
		var active := distance < 2.4
		_set_node_outline(object, active)
		var prompt: Label3D = object.get_meta("prompt_label", null)
		if is_instance_valid(prompt):
			prompt.visible = active
		if active and distance < nearest_distance:
			nearest = object
			nearest_distance = distance
	if is_instance_valid(nearest):
		status_message = "Press E to interact · %s" % ("Supply Cache" if nearest.get_meta("kind") == "cache" else "Stability Shrine")
		status_timer = 0.12


func _spawn_enemy(is_boss: bool) -> void:
	var scale := 1.0 + selected_tier * 0.16
	var archetypes := ["Deep Stalker", "Stone Brute", "Bone Archer"]
	var archetype: String = "Boss" if is_boss else String(archetypes[rng.randi_range(0, archetypes.size() - 1)])
	var enemy_name: String = BOSS_NAMES[selected_mission] if is_boss else archetype
	var enemy_color := Color("#765062") if is_boss else Color("#ab6255")
	if is_boss:
		enemy_color = [Color("#765062"), Color("#a24f32"), Color("#4e7c93"), Color("#c3833d"), Color("#7861a0"), Color("#4e7c93"), Color("#64864e")][selected_mission]
	var enemy_hp := 900.0 if is_boss else 34.0
	var boss_speeds := [1.15, 0.95, 1.35, 1.05, 1.4, 0.9, 1.5]
	var enemy_speed: float = float(boss_speeds[selected_mission]) if is_boss else 0.75
	var is_ranged := false
	if not is_boss:
		match archetype:
			"Stone Brute":
				enemy_color = Color("#88734d")
				enemy_hp = 62.0
				enemy_speed = 0.72
			"Bone Archer":
				enemy_color = Color("#70918d")
				enemy_hp = 27.0
				enemy_speed = 1.0
				is_ranged = true
			_:
				enemy_speed = 1.25
	var enemy := _create_actor(enemy_name, is_boss, enemy_color, enemy_hp * scale)
	if is_boss:
		_add_boss_distinction(enemy, selected_mission, enemy_color)
	if archetype == "Stone Brute":
		enemy.scale = Vector3.ONE * 1.18
	elif archetype == "Bone Archer":
		enemy.scale = Vector3(0.9, 1.0, 0.9)
	var at := _find_spawn_position()
	enemy.position = Vector3(at.x, 0.0, at.y)
	enemy.set_meta("speed", enemy_speed)
	enemy.set_meta("ranged", is_ranged)
	enemy.set_meta("archetype", archetype)
	enemy.set_meta("attack_cd", rng.randf_range(0.4, 1.2))
	if is_boss:
		enemy.scale = Vector3.ONE * 1.25
		enemy.position = Vector3(0.0, 0.0, -18.0)
		enemy.add_to_group("bosses")
		boss_actor = enemy
	enemies.append(enemy)


func _find_spawn_position() -> Vector2:
	var candidates: Array = []
	for cell in dungeon_open_cells.keys():
		if bool(boss_spawned) or cell.y > -4:
			candidates.append(cell)
	for attempt in range(60):
		var cell: Vector2i = candidates[rng.randi_range(0, candidates.size() - 1)] if not candidates.is_empty() else Vector2i(rng.randi_range(-6, 6), rng.randi_range(-5, 5))
		var point := Vector2(float(cell.x) * TILE, float(cell.y) * TILE)
		if _flat_distance(player.global_position, Vector3(point.x, 0.0, point.y)) > 7.0:
			return point
	return Vector2(-10.0, 4.0)


func _create_camera() -> void:
	camera = Camera3D.new()
	camera.name = "IsometricCamera"
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = camera_zoom
	camera.position = Vector3(14.0, 20.0, 14.0)
	camera.current = true
	add_child(camera)
	_follow_camera()


func _follow_camera() -> void:
	if not is_instance_valid(player) or not is_instance_valid(camera):
		return
	var offset := Vector3(14.0, 20.0, 14.0)
	camera.global_position = player.global_position + offset
	camera.look_at(player.global_position + Vector3(0.0, 0.7, 0.0), Vector3.UP)


func _process_player_motion(_delta: float) -> void:
	var input := Vector2.ZERO
	if Input.is_key_pressed(int(keybinds.move_right)) or Input.is_key_pressed(KEY_RIGHT):
		input.x += 1.0
	if Input.is_key_pressed(int(keybinds.move_left)) or Input.is_key_pressed(KEY_LEFT):
		input.x -= 1.0
	if Input.is_key_pressed(int(keybinds.move_down)) or Input.is_key_pressed(KEY_DOWN):
		input.y += 1.0
	if Input.is_key_pressed(int(keybinds.move_up)) or Input.is_key_pressed(KEY_UP):
		input.y -= 1.0
	var direction := Vector3.ZERO
	if input.length_squared() > 0.0:
		var forward := -camera.global_basis.z
		var right := camera.global_basis.x
		forward.y = 0.0
		right.y = 0.0
		direction = (right.normalized() * input.x + forward.normalized() * -input.y).normalized()
		has_move_goal = false
		target_actor = null
	elif is_instance_valid(target_actor):
		var to_target := target_actor.global_position - player.global_position
		to_target.y = 0.0
		if to_target.length() > 1.65:
			direction = to_target.normalized()
		elif attack_timer <= 0.0:
			_attack(target_actor)
	elif has_move_goal:
		var to_goal := move_goal - player.global_position
		to_goal.y = 0.0
		if to_goal.length() > 0.25:
			direction = to_goal.normalized()
		else:
			has_move_goal = false
	if dash_timer > 0.0:
		direction = last_move_direction
	if direction.length_squared() > 0.0:
		if dash_timer <= 0.0:
			direction = _steer_around_obstacles(direction)
		last_move_direction = direction.normalized()
		var move_speed := (16.0 if dash_timer > 0.0 else 5.2) + float(_armor_rank_total()) * 0.006
		if active_artifact_effects.has("Move speed +35%"): move_speed *= 1.0 + 0.35 * float(active_artifact_strength.get("Move speed +35%", 1.0))
		if player_slow_timer > 0.0 and dash_timer <= 0.0:
			move_speed *= 0.58
		player.velocity.x = direction.x * move_speed
		player.velocity.z = direction.z * move_speed
		player.rotation.y = atan2(direction.x, direction.z)
	else:
		player.velocity.x = move_toward(player.velocity.x, 0.0, 25.0 * get_physics_process_delta_time())
		player.velocity.z = move_toward(player.velocity.z, 0.0, 25.0 * get_physics_process_delta_time())
	player.velocity.y = 0.0
	player.move_and_slide()
	_animate_actor(player, get_physics_process_delta_time())
	if click_pending:
		click_pending = false
		_handle_world_click(pending_click)
	if is_instance_valid(hit_ring):
		hit_ring.visible = has_move_goal
		if has_move_goal:
			hit_ring.global_position = move_goal + Vector3(0.0, 0.035, 0.0)


func _steer_around_obstacles(direction: Vector3) -> Vector3:
	var ray_from: Vector3 = player.global_position + Vector3(0.0, 0.65, 0.0)
	for angle in [0.0, -0.55, 0.55, -1.0, 1.0]:
		var candidate: Vector3 = direction.rotated(Vector3.UP, angle).normalized()
		var query := PhysicsRayQueryParameters3D.create(ray_from, ray_from + candidate * 1.15)
		query.collision_mask = 1
		query.exclude = [player.get_rid()]
		if get_world_3d().direct_space_state.intersect_ray(query).is_empty():
			return candidate
	return direction


func _animate_actor(actor: CharacterBody3D, delta: float) -> void:
	var phase := float(actor.get_meta("walk_phase", 0.0))
	var moving := Vector2(actor.velocity.x, actor.velocity.z).length()
	phase += delta * (8.0 if moving > 0.25 else 1.8)
	actor.set_meta("walk_phase", phase)
	var gait := clampf(moving / 2.5, 0.0, 1.0)
	if bool(actor.get_meta("inventory_preview", false)):
		gait = maxf(gait, 0.12)
	var swing_left := float(actor.get_meta("attack_anim", 0.0))
	swing_left = maxf(0.0, swing_left - delta)
	actor.set_meta("attack_anim", swing_left)
	var anim_duration := maxf(0.01, float(actor.get_meta("attack_anim_duration", 0.28)))
	var attack_progress := clampf(1.0 - swing_left / anim_duration, 0.0, 1.0) if swing_left > 0.0 else 0.0
	var swing := sin(attack_progress * PI) if swing_left > 0.0 else 0.0
	var attack_style := String(actor.get_meta("attack_style", "Medium"))
	var attack_side := float(actor.get_meta("attack_side", 1.0))
	for child in actor.get_children():
		if child is MeshInstance3D:
			if child.name == "ArmLeft":
				child.rotation.x = sin(phase) * 0.52 * gait
			elif child.name == "ArmRight":
				child.rotation.x = -sin(phase) * 0.52 * gait
				child.rotation.y = 0.0
				child.rotation.z = 0.0
				if swing_left > 0.0:
					match attack_style:
						"Light":
							child.rotation.x -= swing * 0.7
							child.rotation.y = attack_side * swing * 1.65
							child.rotation.z = -attack_side * swing * 0.8
						"Medium":
							child.rotation.x -= swing * 2.0
							child.rotation.y = attack_side * swing * 0.28
						"Heavy":
							var windup := sin(clampf(attack_progress / 0.28, 0.0, 1.0) * PI * 0.5)
							child.rotation.x += -windup * 0.55 + swing * -2.15
							child.rotation.z = -attack_side * swing * 0.22
						"Axe":
							child.rotation.x -= swing * 1.2
							child.rotation.y = sin(attack_progress * TAU) * 1.45
							child.rotation.z = attack_side * swing * 0.68
			elif child.name == "LegLeft":
				child.rotation.x = -sin(phase) * 0.62 * gait
			elif child.name == "LegRight":
				child.rotation.x = sin(phase) * 0.62 * gait
			elif child.name == "Torso":
				child.position.y = float(actor.get_meta("torso_base_y", child.position.y)) + absf(sin(phase * 2.0)) * 0.045 * gait
				child.rotation.y = sin(attack_progress * PI) * attack_side * (0.22 if attack_style == "Heavy" else 0.42 if attack_style == "Axe" else 0.12) if swing_left > 0.0 else 0.0


func _process_enemies(delta: float) -> void:
	for foe in enemies.duplicate():
		if not is_instance_valid(foe):
			enemies.erase(foe)
			continue
		var stun_left := float(foe.get_meta("stun_left", 0.0))
		if stun_left > 0.0:
			foe.set_meta("stun_left", stun_left - delta)
			foe.velocity = Vector3.ZERO
			foe.move_and_slide()
			_animate_actor(foe, delta)
			continue
		var hp := float(foe.get_meta("health", 1.0))
		var burn := float(foe.get_meta("burn_left", 0.0))
		if burn > 0.0:
			foe.set_meta("burn_left", burn - delta)
			hp -= delta * 5.0
			foe.set_meta("health", hp)
			if hp <= 0.0:
				_kill_enemy(foe)
				continue
		var to_player: Vector3 = player.global_position - foe.global_position
		to_player.y = 0.0
		var distance := to_player.length()
		var is_boss: bool = foe.is_in_group("bosses")
		var is_ranged: bool = bool(foe.get_meta("ranged", false)) and not is_boss
		var speed_factor := 1.0
		if is_boss:
			var health_fraction: float = hp / maxf(1.0, float(foe.get_meta("max_health", 1.0)))
			var phase: int = 3 if health_fraction <= 0.3 else 2 if health_fraction <= 0.65 else 1
			if phase != int(foe.get_meta("phase", 1)):
				foe.set_meta("phase", phase)
				_show_message("%s · PHASE %d" % [BOSS_NAMES[selected_mission].to_upper(), phase])
				_spawn_ring_fx(foe.global_position + Vector3(0.0, 0.08, 0.0), Color("#ff795f"), 3.0 + phase)
				for summon_index in range(phase - 1):
					if enemies.size() < 9:
						_spawn_enemy(false)
			speed_factor = 1.0 + float(phase - 1) * 0.22
		var cd := float(foe.get_meta("attack_cd", 1.0)) - delta
		foe.set_meta("attack_cd", cd)
		var boss_ranges := [3.2, 4.8, 3.5, 4.2, 7.2, 3.8, 3.0]
		var attack_distance: float = float(boss_ranges[selected_mission]) if is_boss else 7.5 if is_ranged else 1.25
		if is_ranged and distance < 4.5:
			var retreat_speed: float = float(foe.get_meta("speed", 1.0)) * (0.65 if is_boss else 1.0)
			foe.velocity.x = -to_player.normalized().x * retreat_speed
			foe.velocity.z = -to_player.normalized().z * retreat_speed
			foe.rotation.y = atan2(to_player.x, to_player.z)
		elif distance > attack_distance:
			var slow := float(foe.get_meta("slow_left", 0.0))
			if slow > 0.0:
				foe.set_meta("slow_left", slow - delta)
			var factor := 0.65 if slow > 0.0 else 1.0
			factor *= 1.0 + stability / 260.0
			var speed := float(foe.get_meta("speed", 1.0)) * factor * speed_factor
			foe.velocity.x = to_player.normalized().x * speed
			foe.velocity.z = to_player.normalized().z * speed
			foe.rotation.y = atan2(to_player.x, to_player.z)
		else:
			foe.velocity.x = 0.0
			foe.velocity.z = 0.0
			if cd <= 0.0:
				foe.set_meta("attack_anim", 0.28)
				foe.set_meta("attack_cd", (1.25 if int(foe.get_meta("phase", 1)) >= 3 else 1.6) if is_boss else 1.4 if is_ranged else 1.0)
				_play_sfx("mob_attack")
				if is_boss:
					var boss_colors := [Color("#83dff0"), Color("#b5d96d"), Color("#e4d0a2"), Color("#f4c04d"), Color("#bd8cf2"), Color("#b2efff"), Color("#d5a979")]
					var boss_radii := [6.5, 5.2, 4.3, 5.8, 6.8, 5.5, 4.8]
					var boss_hit := [27.0, 30.0, 32.0, 28.0, 34.0, 36.0, 33.0]
					var boss_color: Color = boss_colors[selected_mission]
					var slam_radius: float = boss_radii[selected_mission]
					_spawn_ring_fx(foe.global_position + Vector3(0.0, 0.08, 0.0), boss_color, slam_radius)
					if distance < slam_radius:
						_damage_player(boss_hit[selected_mission] + selected_tier * 1.8)
					match selected_mission:
						0: # Raincaller: wide triple lightning barrage.
							_show_message("RAINCALLER · STORM VOLLEY")
							_fire_enemy_projectile(foe, -0.28)
							_fire_enemy_projectile(foe, 0.0)
							_fire_enemy_projectile(foe, 0.28)
						1: # Meadow Warden: root snare and add summons.
							_show_message("MEADOW WARDEN · ROOT SNARE")
							if distance < 6.0: player_slow_timer = 3.0
							if int(foe.get_meta("phase", 1)) >= 2 and enemies.size() < 10: _spawn_enemy(false)
						2: # Husk King: heavy knockback followed by a five-shot spread.
							_show_message("HUSK KING · DUNE BREAKER")
							var shove: Vector3 = player.global_position - foe.global_position
							shove.y = 0.0
							player.velocity += shove.normalized() * 12.0
							for spread in [-0.4, -0.2, 0.0, 0.2, 0.4]: _fire_enemy_projectile(foe, spread)
						3: # Comb Matriarch: sticky honey cloud and paired stingers.
							_show_message("COMB MATRIARCH · HONEY STING")
							if distance < 7.0: player_slow_timer = 3.5
							_fire_enemy_projectile(foe, -0.15)
							_fire_enemy_projectile(foe, 0.15)
						4: # Lullaby Shade: blinks before releasing a shadow pulse.
							_show_message("LULLABY SHADE · SHADOW BLINK")
							if int(foe.get_meta("phase", 1)) >= 2:
								var blink_side := -1.0 if rng.randf() < 0.5 else 1.0
								foe.global_position = player.global_position + Vector3(blink_side * 3.0, 0.0, 1.5)
							_fire_enemy_projectile(foe, -0.24)
							_fire_enemy_projectile(foe, 0.0)
							_fire_enemy_projectile(foe, 0.24)
						5: # Frostbound Ancient: heavy hit that freezes movement.
							_show_message("FROSTBOUND ANCIENT · GLACIAL WAVE")
							if distance < slam_radius: player_slow_timer = 4.0
						6: # Howling Beast: charging pounce with a hard launch.
							_show_message("HOWLING BEAST · POUNCING CHARGE")
							var launch: Vector3 = player.global_position - foe.global_position
							launch.y = 0.0
							player.velocity += launch.normalized() * 18.0
				elif is_ranged:
					_fire_enemy_projectile(foe, 0.0)
				else:
					_damage_player(8.0 + selected_tier * 0.7)
		foe.velocity.y = 0.0
		foe.move_and_slide()
		_animate_actor(foe, delta)
		if not game_active:
			return
	if is_instance_valid(target_actor) and not enemies.has(target_actor):
		target_actor = null


func _fire_enemy_projectile(foe: CharacterBody3D, spread: float) -> void:
	var direction: Vector3 = player.global_position - foe.global_position
	direction.y = 0.0
	direction = direction.normalized().rotated(Vector3.UP, spread)
	var projectile := Node3D.new()
	projectile.name = "EnemyBolt"
	projectile.global_position = foe.global_position + Vector3(0.0, 0.7, 0.0)
	projectile.set_meta("direction", direction)
	projectile.set_meta("life", 4.0)
	projectile.set_meta("damage", 7.0 + selected_tier * 0.5)
	var visual := MeshInstance3D.new()
	var orb := SphereMesh.new()
	orb.radius = 0.18
	orb.height = 0.36
	orb.radial_segments = 8
	orb.rings = 4
	visual.mesh = orb
	var bolt_colors := [Color("#76e6f1"), Color("#b4ed78"), Color("#ead6b1"), Color("#ffd457"), Color("#cf8eff"), Color("#b1f4ff"), Color("#e9a96b")]
	var bolt_color: Color = bolt_colors[selected_mission]
	visual.material_override = _material(bolt_color, 0.25, 1.5)
	projectile.add_child(visual)
	arena_root.add_child(projectile)
	enemy_projectiles.append(projectile)


func _process_enemy_projectiles(delta: float) -> void:
	if not game_active:
		return
	for projectile in enemy_projectiles.duplicate():
		if not is_instance_valid(projectile):
			enemy_projectiles.erase(projectile)
			continue
		var direction: Vector3 = projectile.get_meta("direction", Vector3.ZERO)
		projectile.global_position += direction * 8.0 * delta
		var life := float(projectile.get_meta("life", 0.0)) - delta
		projectile.set_meta("life", life)
		if _flat_distance(player.global_position, projectile.global_position) < 0.75:
			_damage_player(float(projectile.get_meta("damage", 8.0)))
			projectile.queue_free()
			enemy_projectiles.erase(projectile)
		elif life <= 0.0:
			projectile.queue_free()
			enemy_projectiles.erase(projectile)


func _fire_player_ranged(screen_position: Vector2) -> void:
	if attack_timer > 0.0 or not is_instance_valid(player):
		return
	if arrows <= 0:
		_show_message("No arrows · wait for your quiver to refill")
		return
	var ray_from := camera.project_ray_origin(screen_position)
	var ray_to := ray_from + camera.project_ray_normal(screen_position) * RAY_LENGTH
	var query := PhysicsRayQueryParameters3D.create(ray_from, ray_to)
	query.collision_mask = 2
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	var victim: CharacterBody3D
	if not hit.is_empty() and hit.collider is CharacterBody3D and hit.collider.is_in_group("enemies"):
		victim = hit.collider
	else:
		victim = _nearest_enemy()
	var aim_point: Vector3
	if is_instance_valid(victim):
		aim_point = victim.global_position + Vector3.UP * 0.65
	else:
		var direction := camera.project_ray_normal(screen_position)
		if absf(direction.y) < 0.001:
			return
		var distance := -ray_from.y / direction.y
		if distance <= 0.0:
			return
		aim_point = ray_from + direction * distance
	var bolt_direction := aim_point - (player.global_position + Vector3.UP * 0.72)
	bolt_direction.y = 0.0
	if bolt_direction.length_squared() < 0.01:
		return
	bolt_direction = bolt_direction.normalized()
	attack_timer = 0.58
	arrows -= 1
	arrow_regen_timer = 0.8
	player.set_meta("attack_anim", 0.24)
	_play_sfx("ranged")
	var projectile := Node3D.new()
	projectile.name = "PlayerBolt"
	projectile.global_position = player.global_position + Vector3.UP * 0.72 + bolt_direction * 0.65
	projectile.set_meta("direction", bolt_direction)
	projectile.set_meta("life", 2.4)
	projectile.set_meta("damage", (12.0 + float(gear.weapon.get("rank", 0)) * 2.0) * _player_damage_multiplier())
	var visual := MeshInstance3D.new()
	var bolt_mesh := SphereMesh.new()
	bolt_mesh.radius = 0.16
	bolt_mesh.height = 0.32
	bolt_mesh.radial_segments = 8
	bolt_mesh.rings = 4
	visual.mesh = bolt_mesh
	visual.material_override = _material(Color("#85e7ff"), 0.22, 2.2)
	projectile.add_child(visual)
	arena_root.add_child(projectile)
	player_projectiles.append(projectile)


func _process_player_projectiles(delta: float) -> void:
	for projectile in player_projectiles.duplicate():
		if not is_instance_valid(projectile):
			player_projectiles.erase(projectile)
			continue
		var direction: Vector3 = projectile.get_meta("direction", Vector3.FORWARD)
		projectile.global_position += direction * 20.0 * delta
		var life := float(projectile.get_meta("life", 0.0)) - delta
		projectile.set_meta("life", life)
		var struck := false
		for foe in enemies.duplicate():
			if is_instance_valid(foe) and _flat_distance(foe.global_position, projectile.global_position) < (1.2 if foe.is_in_group("bosses") else 0.85):
				var damage: float = float(projectile.get_meta("damage", 12.0))
				var hp := float(foe.get_meta("health", 1.0)) - damage
				foe.set_meta("health", hp)
				_show_damage_number(foe, damage)
				if _handle_training_dummy_hit(foe, damage):
					hp = float(foe.get_meta("health", hp))
				_refresh_enemy_health_bar(foe)
				_spawn_ring_fx(foe.global_position + Vector3.UP * 0.08, Color("#85e7ff"), 1.05)
				_play_sfx("hit")
				if hp <= 0.0:
					_kill_enemy(foe)
				elif foe.is_in_group("bosses"):
					_refresh_boss_bar(foe)
				struck = true
				break
		if struck or life <= 0.0:
			projectile.queue_free()
			player_projectiles.erase(projectile)


func _process_loot(delta: float) -> void:
	for drop in loot_nodes.duplicate():
		if not is_instance_valid(drop):
			loot_nodes.erase(drop)
			continue
		drop.rotate_y(delta * 1.6)
		drop.position.y = 0.7 + sin(Time.get_ticks_msec() * 0.003 + float(drop.get_instance_id())) * 0.12
		var close := _flat_distance(player.global_position, drop.global_position) < 2.2
		var prompt: Label3D = drop.get_meta("prompt_label", null)
		if is_instance_valid(prompt): prompt.visible = close
		var ring: MeshInstance3D = drop.get_meta("pickup_ring", null)
		if is_instance_valid(ring): ring.visible = close
		if close:
			var item: Dictionary = drop.get_meta("item")
			status_message = "Press E to pick up · %s %s" % [item.rarity, item.name]
			status_timer = 0.12


func _process_coin_drops(delta: float) -> void:
	for coin in coin_nodes.duplicate():
		if not is_instance_valid(coin):
			coin_nodes.erase(coin)
			continue
		coin.rotate_y(delta * 2.2)
		coin.position.y = 0.2 + sin(Time.get_ticks_msec() * 0.004 + float(coin.get_instance_id())) * 0.07
		if _flat_distance(player.global_position, coin.global_position) < 1.25:
			var value := int(coin.get_meta("value", 1))
			coins += value
			coin_nodes.erase(coin)
			coin.queue_free()
			_play_sfx("loot")
			_show_message("COINS · +%d" % value)
			_refresh_hud()
			_rebuild_inventory()
			_save_progress()


func _drop_coin(at: Vector3, value: int) -> void:
	var drop := Node3D.new()
	drop.name = "CoinDrop"
	drop.position = Vector3(at.x, 0.2, at.z)
	drop.set_meta("value", value)
	var coin_mesh := MeshInstance3D.new()
	var coin := CylinderMesh.new()
	coin.top_radius = 0.22
	coin.bottom_radius = 0.22
	coin.height = 0.1
	coin.radial_segments = 12
	coin_mesh.mesh = coin
	coin_mesh.material_override = _material(Color("#f5cf57"), 0.2, 1.0)
	drop.add_child(coin_mesh)
	var glint := MeshInstance3D.new()
	var glint_mesh := SphereMesh.new()
	glint_mesh.radius = 0.08
	glint_mesh.height = 0.1
	glint.mesh = glint_mesh
	glint.position = Vector3(-0.07, 0.1, -0.04)
	glint.material_override = _material(Color("#fff0a3"), 0.15, 1.2)
	drop.add_child(glint)
	arena_root.add_child(drop)
	coin_nodes.append(drop)


func _handle_world_click(screen_position: Vector2) -> void:
	var ray_from := camera.project_ray_origin(screen_position)
	var ray_to := ray_from + camera.project_ray_normal(screen_position) * RAY_LENGTH
	var query := PhysicsRayQueryParameters3D.create(ray_from, ray_to)
	query.collision_mask = 2
	query.collide_with_areas = false
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty():
		var collider: Object = hit.collider
		if collider is CharacterBody3D and collider.is_in_group("enemies"):
			target_actor = collider
			hover_actor = collider
			has_move_goal = false
			return
	var direction := camera.project_ray_normal(screen_position)
	if absf(direction.y) < 0.001:
		return
	var distance := -ray_from.y / direction.y
	if distance > 0.0:
		move_goal = ray_from + direction * distance
		move_goal.x = clampf(move_goal.x, -14.0, 14.0)
		move_goal.z = clampf(move_goal.z, -10.0, 10.0)
		target_actor = null
		has_move_goal = true


func _attack(target: CharacterBody3D = null) -> void:
	if attack_timer > 0.0:
		return
	var victim := target
	if not is_instance_valid(victim):
		victim = _nearest_enemy()
	if not is_instance_valid(victim):
		return
	if _flat_distance(player.global_position, victim.global_position) > (2.5 if victim.is_in_group("bosses") else 2.0):
		return
	var weapon_name := String(gear.weapon.get("name", "Wayfinder Blade"))
	var weapon_class := String(WEAPON_CLASSES.get(weapon_name, "Medium"))
	var weapon_profile: Array = WEAPON_COMBAT[weapon_class]
	var combo_length := int(weapon_profile[0])
	if weapon_combo_reset_timer <= 0.0:
		weapon_combo_step = 0
	weapon_combo_step += 1
	var attack_step := weapon_combo_step
	var finisher := attack_step >= combo_length
	if finisher:
		weapon_combo_step = 0
	weapon_combo_reset_timer = 1.3
	var attack_speed := float(weapon_profile[1])
	attack_timer = float(weapon_profile[2]) if finisher else attack_speed
	if active_artifact_effects.has("Attack speed +35%"):
		attack_timer /= 1.0 + 0.35 * float(active_artifact_strength.get("Attack speed +35%", 1.0))
	var animation_duration := minf(0.48, attack_speed * (0.82 if finisher else 0.7))
	player.set_meta("attack_style", weapon_class)
	player.set_meta("attack_side", -1.0 if attack_step % 2 == 0 else 1.0)
	player.set_meta("attack_anim_duration", animation_duration)
	player.set_meta("attack_anim", animation_duration)
	_play_sfx("player_attack")
	recently_attacked_actor = victim
	attacked_highlight_timer = 0.75
	combo_count += 1
	var damage := (float(weapon_profile[3]) + float(gear.weapon.get("rank", 0)) * float(weapon_profile[4])) * _player_damage_multiplier()
	if finisher:
		damage *= 1.5
		_show_message("%s FINISHER · 1.5× DAMAGE" % weapon_class.to_upper())
	if active_artifact_effects.has("Damage dealt +40%"): damage *= 1.0 + 0.4 * float(active_artifact_strength.get("Damage dealt +40%", 1.0))
	for affinity in ["Fire attacks", "Poison attacks", "Frost attacks", "Lightning attacks"]:
		if active_artifact_effects.has(affinity): damage *= 1.0 + 0.12 * float(active_artifact_strength.get(affinity, 1.0)); break
	var active_enchants := _ensure_item_enchantments(gear.weapon)
	for enchant_slot in active_enchants:
		var enchant_name := String(enchant_slot.get("name", ""))
		var enchant_rank := clampi(int(enchant_slot.get("rank", 1)), 1, 3)
		if enchant_name == "Sharpness": damage *= [1.10, 1.21, 1.33][enchant_rank - 1]
		if enchant_name == "Committed": damage *= 1.0 + maxf(0.0, 1.0 - float(victim.get_meta("health")) / float(victim.get_meta("max_health"))) * [0.5, 0.75, 1.0][enchant_rank - 1]
		if enchant_name == "Critical Hit" and rng.randf() < [0.1, 0.15, 0.2][enchant_rank - 1]:
			damage *= 3.0
			_show_message("CRITICAL HIT!")
			_show_enchant_proc(victim, enchant_name, Color("#fff0a1"))
	var hp := float(victim.get_meta("health")) - damage
	victim.set_meta("health", hp)
	_show_damage_number(victim, damage)
	_refresh_enemy_health_bar(victim)
	_play_sfx("hit")
	_spawn_ring_fx(victim.global_position + Vector3(0.0, 0.08, 0.0), Color("#f1d37d"), 1.35)
	if _handle_training_dummy_hit(victim, damage):
		hp = float(victim.get_meta("health", hp))
	for enchant_slot in active_enchants:
		var enchant := String(enchant_slot.get("name", ""))
		var rank := clampi(int(enchant_slot.get("rank", 1)), 1, 3)
		var strike_color := Color("#f1d37d")
		match enchant:
			"Fire Aspect":
				strike_color = Color("#ff784b")
				victim.set_meta("burn_left", 3.0)
				_show_enchant_proc(victim, enchant, strike_color)
			"Freezing":
				strike_color = Color("#7ee8f3")
				victim.set_meta("slow_left", 2.0)
				_show_enchant_proc(victim, enchant, strike_color)
			"Gravity":
				strike_color = Color("#c19bff")
				for other in enemies:
					if is_instance_valid(other) and other != victim and _flat_distance(victim.global_position, other.global_position) < 4.5:
						var pull: Vector3 = victim.global_position - other.global_position
						pull.y = 0.0
						other.global_position += pull.normalized() * 0.75
				_show_enchant_proc(victim, enchant, strike_color)
			"Leeching":
				if hp <= 0.0:
					health = minf(max_health, health + float(victim.get_meta("max_health")) * [0.05, 0.07, 0.09][rank - 1])
					_show_enchant_proc(player, enchant, Color("#8be39a"))
			"Radiance":
				if rng.randf() < 0.2:
					health = minf(max_health, health + max_health * 0.2 * rank)
					_show_enchant_proc(player, enchant, Color("#9bffbd"))
			"Prospector":
				if hp <= 0.0 and rng.randf() < 0.25 * rank:
					shards += 2
					_show_enchant_proc(player, enchant, Color("#f7dc73"))
			"Shockwave", "Swirling":
				if combo_count % 3 == 0:
					_show_enchant_proc(victim, enchant, Color("#c5a9ff"))
					for other in enemies:
						if is_instance_valid(other) and other != victim and _flat_distance(victim.global_position, other.global_position) < 3.0:
							var splash_damage := damage * (0.45 if enchant == "Shockwave" else 0.35)
							var splash := float(other.get_meta("health")) - splash_damage
							other.set_meta("health", splash)
							_show_damage_number(other, splash_damage, Color("#c5a9ff"))
							_refresh_enemy_health_bar(other)
							if _handle_training_dummy_hit(other, splash_damage): splash = float(other.get_meta("health", splash))
							if splash <= 0.0: _kill_enemy(other)
	if hp <= 0.0:
		_kill_enemy(victim)
	elif victim.is_in_group("bosses"):
		_refresh_boss_bar(victim)
	_refresh_hud()


func _kill_enemy(foe: CharacterBody3D) -> void:
	var at: Vector3 = foe.global_position
	var is_boss := foe.is_in_group("bosses")
	if _has_enchant("weapon", "Exploding"):
		_show_enchant_proc(foe, "Exploding", Color("#ff945a"))
	enemies.erase(foe)
	if is_instance_valid(target_actor) and target_actor == foe:
		target_actor = null
	foe.queue_free()
	kills += 1
	var foe_power := float(foe.get_meta("max_health", 34.0)) * (2.0 if is_boss else 1.0)
	var hero_power := maxf(20.0, float(_power_level()) * 5.0 + float(level) * 3.0)
	var soul_reward := clampi(roundi(28.0 * foe_power / hero_power), 34, MAX_SOULS)
	souls = mini(MAX_SOULS, souls + soul_reward)
	_show_message("+%d souls · %d/%d" % [soul_reward, souls, MAX_SOULS])
	_save_progress()
	if is_boss:
		coins += 100 + selected_tier * 5
	var reward_summary := ""
	if is_boss:
		if inventory.size() < 8:
			var reward_item := _make_gear_item(_roll_rarity())
			inventory.append(reward_item)
			reward_summary = "Random reward: %s %s (PWR %d)." % [reward_item.rarity, reward_item.name, reward_item.rank]
		else:
			match rng.randi_range(0, 2):
				0:
					var bonus_coins := rng.randi_range(180, 320)
					coins += bonus_coins
					reward_summary = "Random reward: %d bonus coins." % bonus_coins
				1:
					var bonus_shards := rng.randi_range(20, 45)
					shards += bonus_shards
					reward_summary = "Random reward: %d shards." % bonus_shards
				2:
					var bonus_points := rng.randi_range(2, 4)
					enchant_points += bonus_points
					reward_summary = "Random reward: %d enchantment points." % bonus_points
	else:
		_drop_coin(at, rng.randi_range(1, 4))
	_xp_gain(160 + selected_tier * 35 if is_boss else 22)
	if not is_boss and rng.randf() < 0.32 * loot_luck:
		_drop_loot(at)
	if _has_enchant("weapon", "Exploding"):
		for other in enemies:
			if is_instance_valid(other) and _flat_distance(at, other.global_position) < 3.0:
				other.set_meta("health", float(other.get_meta("health")) - 18.0 * _player_damage_multiplier())
	if is_boss:
		boss_actor = null
		shards += 30 + selected_tier * 3
		cleared_bosses["%d:%d" % [selected_tier, selected_mission]] = true
		var tier_cleared := _all_bosses_cleared(selected_tier)
		if selected_tier >= 2 and tier_cleared:
			unlocked_tier = maxi(unlocked_tier, mini(27, selected_tier + 1))
		game_active = false
		paused = true
		_save_progress()
		var boss_result := "%s defeated · %d/%d bosses cleared on %s." % [BOSS_NAMES[selected_mission], _cleared_boss_count(selected_tier), MISSION_NAMES.size(), _tier_name(selected_tier)]
		if selected_tier >= 2 and tier_cleared and selected_tier < 27:
			boss_result += " %s unlocked!" % _tier_name(selected_tier + 1)
		elif selected_tier >= 2 and not tier_cleared:
			boss_result += " Defeat every mission boss here to unlock the next tier."
		boss_result += " You earned %d shards and %d coins." % [30 + selected_tier * 3, 100 + selected_tier * 5]
		if not reward_summary.is_empty(): boss_result += " " + reward_summary
		_show_menu(boss_result)
	else:
		_refresh_hud()


func _drop_loot(at: Vector3) -> void:
	var rarity := _roll_rarity()
	var item := _make_gear_item(rarity)
	var drop := Node3D.new()
	drop.name = "LootDrop"
	drop.position = Vector3(at.x, 0.7, at.z)
	drop.set_meta("item", item)
	_add_interaction_prompt(drop, 1.45)
	var gem := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.32
	mesh.height = 0.64
	mesh.radial_segments = 8
	mesh.rings = 4
	gem.mesh = mesh
	gem.material_override = _material(_rarity_color(rarity), 0.24, 0.65)
	drop.add_child(gem)
	var icon_sprite := Sprite3D.new()
	icon_sprite.texture = load(_item_icon_path(item))
	icon_sprite.pixel_size = 0.012
	icon_sprite.position = Vector3(0.0, 0.9, 0.0)
	icon_sprite.no_depth_test = true
	drop.add_child(icon_sprite)
	var pickup_ring := MeshInstance3D.new()
	var pickup_ring_mesh := TorusMesh.new()
	pickup_ring_mesh.inner_radius = 0.42
	pickup_ring_mesh.outer_radius = 0.5
	pickup_ring.mesh = pickup_ring_mesh
	pickup_ring.rotation_degrees.x = 90.0
	pickup_ring.position.y = 0.08
	pickup_ring.material_override = _material(Color.WHITE, 0.35, 0.5)
	pickup_ring.visible = false
	drop.add_child(pickup_ring)
	drop.set_meta("pickup_ring", pickup_ring)
	arena_root.add_child(drop)
	loot_nodes.append(drop)
	_show_message("%s drop · loot chance ×%.2f" % [rarity, loot_luck])


func _make_gear_item(rarity: String) -> Dictionary:
	var kind: String = ["weapon", "armor", "artifact", "talisman"][rng.randi_range(0, 3)]
	var slot := kind
	var item_name := ""
	var enchant := ""
	if kind == "weapon":
		item_name = WEAPON_NAMES.pick_random()
		enchant = WEAPON_ENCHANTS.pick_random()
	elif kind == "armor":
		slot = ARMOR_SLOTS.pick_random()
		item_name = ARMOR_NAMES.pick_random()
		enchant = ARMOR_ENCHANTS.pick_random()
	elif kind == "artifact":
		slot = ARTIFACT_SLOTS.pick_random()
		var available_artifacts: Array[String] = []
		for artifact_name in ARTIFACT_NAMES:
			if MISSION_NAMES[selected_mission] in ARTIFACT_DATA[artifact_name][3]:
				available_artifacts.append(artifact_name)
		item_name = available_artifacts.pick_random() if not available_artifacts.is_empty() else ARTIFACT_NAMES.pick_random()
		enchant = item_name
	else:
		item_name = PASSIVE_TALISMAN_NAMES.pick_random()
		enchant = item_name
	if kind == "artifact":
		rarity = _roll_artifact_rarity()
	var rank := _average_equipped_power() + 9 + selected_tier * 9 + (4 if rarity == "Gilded" else 2 if rarity == "Epic" else 1 if rarity == "Rare" else 0)
	var result := {"id": rng.randi(), "type": kind, "slot": slot, "name": item_name, "rarity": rarity, "rank": rank, "enchant": enchant, "enchant_rank": mini(3, 1 + int(selected_tier / 9)), "enchant_points_spent": 0, "luck": 0.035 if rarity == "Gilded" else 0.025 if rarity == "Epic" else 0.015 if rarity == "Rare" else 0.0}
	if kind == "weapon":
		result["weapon_class"] = String(WEAPON_CLASSES.get(item_name, "Medium"))
	if kind in ["weapon", "armor"]:
		var pool: Array = WEAPON_ENCHANTS if kind == "weapon" else ARMOR_ENCHANTS
		var initial_slots: Array[Dictionary] = []
		var available := pool.duplicate()
		for index in range(_enchant_slot_count(rarity)):
			if available.is_empty(): break
			var enchant_name := enchant if index == 0 else String(available.pick_random())
			available.erase(enchant_name)
			initial_slots.append({"name": enchant_name, "rank": mini(3, 1 + int(selected_tier / 9)), "points_spent": 0})
		result["enchantments"] = initial_slots
	return result


func _roll_rarity() -> String:
	var luck := 1.0 + selected_tier * 0.055
	if rng.randf() < minf(0.08 * luck, 0.4):
		return "Gilded"
	if rng.randf() < minf(0.26 * luck, 0.65):
		return "Epic"
	if rng.randf() < minf(0.55 * luck, 0.83):
		return "Rare"
	return "Common"


func _roll_artifact_rarity() -> String:
	var luck := 1.0 + selected_tier * 0.045
	if rng.randf() < minf(0.06 * luck, 0.32): return "Special"
	if rng.randf() < minf(0.3 * luck, 0.72): return "Rare"
	return "Common"


func _use_artifact(slot_index: int) -> void:
	if not (game_active or in_camp) or paused or slot_index < 0 or slot_index >= ARTIFACT_SLOTS.size() or artifact_cooldowns[slot_index] > 0.0:
		return
	var artifact_slot: String = ARTIFACT_SLOTS[slot_index]
	var item: Dictionary = gear[artifact_slot]
	if item.is_empty():
		_show_message("Equip an artifact in slot %d first." % (slot_index + 1))
		return
	var artifact := String(item.get("name", "Spark Totem"))
	var data: Array = ARTIFACT_DATA.get(artifact, [25, 12, "A magical artifact effect.", MISSION_NAMES])
	var cost := int(data[0])
	if souls < cost:
		_show_message("%s needs %d souls · you have %d/%d." % [artifact, cost, souls, MAX_SOULS])
		return
	souls -= cost
	artifact_cooldowns[slot_index] = float(data[1])
	var color := _artifact_color(artifact)
	var rarity := String(item.get("rarity", "Common"))
	var effect_scale: float = {"Common": 1.0, "Rare": 1.25, "Special": 1.5}.get(rarity, 1.0)
	var duration := 8.0
	var damage := (22.0 + float(item.get("rank", 1)) * 2.0) * _player_damage_multiplier() * effect_scale
	var radius := 5.0
	var heals := artifact in ["Picnic Basket", "Totem of Regeneration", "Beacon Relic"]
	if artifact == "Picnic Basket": health = minf(max_health, health + max_health * 0.35 * effect_scale)
	elif artifact == "Beacon Relic": health = minf(max_health, health + max_health * 0.25 * effect_scale)
	elif artifact == "Totem of Regeneration":
		active_artifact_effects["Regeneration"] = 10.0 * effect_scale
		active_artifact_strength["Regeneration"] = effect_scale
		health = minf(max_health, health + max_health * 0.15 * effect_scale)
	if artifact in ["Tempo Truffle", "Death Cap Mushroom", "Fighting Fungus", "Battle Banner", "Fighter's Flute", "Warrior Drums", "Grindstone", "Totem of Casting", "Echo Ocarina", "Totem of Shielding", "Turtle Master's Mandolin", "Warding Chimes"]:
		duration = 8.0
	else:
		duration = 2.5
	if artifact in ["Firework Arrow", "Redstone Mine Launcher", "Creeper Candle", "Winter Staff"]: radius = 7.0
	if artifact in ["Flaming Quiver", "Freezing Quiver", "Venomous Quiver", "Conductive Quiver"]: radius = 10.0
	duration *= effect_scale
	radius *= effect_scale
	_spawn_ring_fx(player.global_position + Vector3(0.0, 0.08, 0.0), color, radius)
	if artifact == "Totem of Casting":
		for i in range(artifact_cooldowns.size()): artifact_cooldowns[i] = maxf(0.0, artifact_cooldowns[i] - 4.0)
	if artifact == "Tempo Truffle": active_artifact_effects["Move speed +35%"] = duration
	elif artifact in ["Death Cap Mushroom", "Fighting Fungus"]: active_artifact_effects["Attack speed +35%"] = duration
	elif artifact in ["Totem of Shielding", "Echo Ocarina", "Turtle Master's Mandolin", "Warding Chimes"]: active_artifact_effects["Damage resistance +40%"] = duration
	elif artifact in ["Battle Banner", "Fighter's Flute", "Warrior Drums", "Grindstone"]: active_artifact_effects["Damage dealt +40%"] = duration
	elif artifact in ["Blaze Bangle", "Pouch of Ember", "Cinder Scepter", "Firework Arrow", "Creeper Candle", "Flaming Quiver"]: active_artifact_effects["Fire attacks"] = duration
	elif artifact in ["Blight Bangle", "Corrupted Seeds", "Pouch of Poison", "Venomous Quiver", "Witch Brew"]: active_artifact_effects["Poison attacks"] = duration
	elif artifact in ["Blizzard Bangle", "Pouch of Frost", "Winter Staff", "Freezing Quiver"]: active_artifact_effects["Frost attacks"] = duration
	elif artifact in ["Electric Bangle", "Conductive Quiver", "Pouch of Thunder", "Lightning Rod"]: active_artifact_effects["Lightning attacks"] = duration
	else: active_artifact_effects[artifact] = duration
	var effect_key := artifact
	if artifact == "Tempo Truffle": effect_key = "Move speed +35%"
	elif artifact in ["Death Cap Mushroom", "Fighting Fungus"]: effect_key = "Attack speed +35%"
	elif artifact in ["Totem of Shielding", "Echo Ocarina", "Turtle Master's Mandolin", "Warding Chimes"]: effect_key = "Damage resistance +40%"
	elif artifact in ["Battle Banner", "Fighter's Flute", "Warrior Drums", "Grindstone"]: effect_key = "Damage dealt +40%"
	elif artifact in ["Blaze Bangle", "Pouch of Ember", "Cinder Scepter", "Firework Arrow", "Creeper Candle", "Flaming Quiver"]: effect_key = "Fire attacks"
	elif artifact in ["Blight Bangle", "Corrupted Seeds", "Pouch of Poison", "Venomous Quiver", "Witch Brew"]: effect_key = "Poison attacks"
	elif artifact in ["Blizzard Bangle", "Pouch of Frost", "Winter Staff", "Freezing Quiver"]: effect_key = "Frost attacks"
	elif artifact in ["Electric Bangle", "Conductive Quiver", "Pouch of Thunder", "Lightning Rod"]: effect_key = "Lightning attacks"
	if active_artifact_effects.has(effect_key): active_artifact_strength[effect_key] = effect_scale
	if not heals and artifact != "Totem of Casting":
		for foe in enemies.duplicate():
			if not is_instance_valid(foe) or _flat_distance(player.global_position, foe.global_position) > radius: continue
			var dealt := damage * (1.8 if artifact in ["Firework Arrow", "Creeper Candle", "Redstone Mine Launcher", "Soul Harvester", "Winter Staff"] else 1.0)
			var hp := float(foe.get_meta("health", 1.0)) - dealt
			foe.set_meta("health", hp)
			_show_damage_number(foe, dealt, color)
			if _handle_training_dummy_hit(foe, dealt):
				hp = float(foe.get_meta("health", hp))
			if artifact in ["Blizzard Bangle", "Pouch of Frost", "Winter Staff", "Freezing Quiver", "Humbling Horn", "Honey Dipper", "Corrupted Seeds"]: foe.set_meta("slow_left", 3.0 * effect_scale)
			if artifact in ["Blight Bangle", "Pouch of Poison", "Corrupted Seeds", "Witch Brew"]: foe.set_meta("burn_left", 3.0 * effect_scale)
			if hp <= 0.0: _kill_enemy(foe)
			else: _refresh_enemy_health_bar(foe)
	_play_sfx("magic")
	_show_message("%s · −%d souls · cooldown %ds" % [artifact, cost, int(data[1])])
	_refresh_hud()


func _artifact_color(name: String) -> Color:
	if "Fire" in name or "Blaze" in name or "Ember" in name or "Cinder" in name: return Color("#ff8854")
	if "Poison" in name or "Blight" in name or "Venom" in name or "Seeds" in name: return Color("#9bd26a")
	if "Frost" in name or "Blizzard" in name or "Winter" in name or "Freez" in name: return Color("#88dafa")
	if "Lightning" in name or "Electric" in name or "Thunder" in name or "Conductive" in name: return Color("#ebdb6b")
	return Color("#c9a6ff")


func _artifact_slug(name: String) -> String:
	return name.to_lower().replace("'", "").replace(" ", "_").replace("-", "_")


func _show_damage_number(target: Node3D, amount: float, color: Color = Color("#fff0a1")) -> void:
	if not show_damage_numbers or not is_instance_valid(target): return
	var label := Label3D.new()
	label.text = str(maxi(1, roundi(amount)))
	label.font_size = 54
	label.outline_size = 12
	label.outline_modulate = Color("#1b1713")
	label.modulate = color
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	arena_root.add_child(label)
	label.global_position = target.global_position + Vector3(0.0, 2.6, 0.0)
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(label, "global_position:y", label.global_position.y + 1.5, 0.72)
	tween.tween_property(label, "modulate:a", 0.0, 0.72)
	tween.chain().tween_callback(label.queue_free)


func _start_dash() -> void:
	if dash_cooldown > 0.0:
		return
	var dash_direction: Vector3 = last_move_direction
	if dash_direction.length_squared() < 0.01:
		dash_direction = -camera.global_basis.z
	dash_direction.y = 0.0
	last_move_direction = dash_direction.normalized()
	dash_timer = 0.24
	dash_cooldown = 3.0
	_spawn_ring_fx(player.global_position + Vector3(0.0, 0.08, 0.0), Color("#f5d57b"), 2.0)
	_play_sfx("magic")
	_show_message("DODGE · INVULNERABLE")


func _spawn_ring_fx(at: Vector3, color: Color, radius: float) -> void:
	if not is_instance_valid(arena_root):
		return
	var fx := MeshInstance3D.new()
	var ring := TorusMesh.new()
	ring.inner_radius = 0.35
	ring.outer_radius = 0.48
	fx.mesh = ring
	fx.position = at
	fx.scale = Vector3(0.16, 1.0, 0.16)
	var glow := StandardMaterial3D.new()
	glow.albedo_color = Color(color.r, color.g, color.b, 0.95)
	glow.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	glow.emission_enabled = true
	glow.emission = color
	glow.emission_energy_multiplier = 1.6
	fx.material_override = glow
	arena_root.add_child(fx)
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(fx, "scale", Vector3(radius * 2.1, 1.0, radius * 2.1), 0.72)
	tween.tween_property(glow, "albedo_color:a", 0.0, 0.72)
	tween.set_parallel(false)
	tween.tween_callback(fx.queue_free)


func _show_enchant_proc(victim: CharacterBody3D, enchant: String, color: Color) -> void:
	if not is_instance_valid(victim):
		return
	_spawn_ring_fx(victim.global_position + Vector3(0.0, 0.12, 0.0), color, 2.1)
	var callout := Label3D.new()
	callout.text = enchant.to_upper()
	callout.font_size = 32
	callout.outline_size = 8
	callout.outline_modulate = Color("#171b19")
	callout.modulate = color
	callout.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	callout.no_depth_test = true
	callout.position = victim.global_position + Vector3(0.0, 2.55, 0.0)
	arena_root.add_child(callout)
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(callout, "position:y", callout.position.y + 0.8, 0.7)
	tween.tween_property(callout, "modulate:a", 0.0, 0.7)
	tween.set_parallel(false)
	tween.tween_callback(callout.queue_free)
	_play_sfx("magic")


func _use_healing_potion() -> void:
	if not game_active or paused:
		return
	if potion_cooldown > 0.0:
		_show_message("Healing potion ready in %.0f seconds" % potion_cooldown)
		return
	if health >= max_health:
		_show_message("Your health is already full")
		return
	var restored := max_health * 0.70
	health = minf(max_health, health + restored)
	potion_cooldown = 30.0
	_spawn_ring_fx(player.global_position + Vector3(0.0, 0.08, 0.0), Color("#86f0a2"), 3.2)
	_play_sfx("potion")
	_show_message("HEALING POTION · +%.0f health" % restored)
	_refresh_hud()


func _damage_player(amount: float) -> void:
	if not game_active:
		return
	if dash_timer > 0.0:
		return
	if hurt_timer > 0.0:
		return
	hurt_timer = 0.65
	var incoming := amount * _incoming_damage_multiplier()
	if active_artifact_effects.has("Damage resistance +40%"): incoming *= 1.0 - 0.4 * float(active_artifact_strength.get("Damage resistance +40%", 1.0))
	var deflect_item := _armor_enchant_item("Deflect")
	var deflect_rank := clampi(int(deflect_item.get("enchant_rank", 1)), 1, 3)
	if not deflect_item.is_empty() and rng.randf() < [0.25, 0.35, 0.45][deflect_rank - 1]:
		_show_message("DEFLECT")
		_show_enchant_proc(player, "Deflect", Color("#f5f7ff"))
		return
	var protection_item := _armor_enchant_item("Protection")
	if not protection_item.is_empty():
		var protection_rank := clampi(int(protection_item.get("enchant_rank", 1)), 1, 3)
		incoming *= [0.94, 0.89, 0.85][protection_rank - 1]
		_spawn_ring_fx(player.global_position + Vector3(0.0, 0.08, 0.0), Color("#70c9ff"), 1.8)
	incoming = maxf(1.0, incoming - float(_armor_rank_total()) * 0.5)
	health -= incoming
	_play_sfx("hurt")
	if _has_armor_enchant("Thorns"):
		var thorns := _armor_enchant_item("Thorns")
		var thorns_rank := clampi(int(thorns.get("enchant_rank", 1)), 1, 3)
		for foe in enemies.duplicate():
			if is_instance_valid(foe) and _flat_distance(player.global_position, foe.global_position) < 2.5:
				var thorns_health: float = float(foe.get_meta("health")) - amount * float([1.0, 1.5, 2.0][thorns_rank - 1])
				foe.set_meta("health", thorns_health)
				_show_enchant_proc(foe, "Thorns", Color("#9ae295"))
				if thorns_health <= 0.0:
					_kill_enemy(foe)
	if health <= 0.0:
		health = max_health
		game_active = false
		paused = true
		_save_progress()
		_show_menu("The dungeon overwhelmed you, but your gear and permanent progress are safe.")
	_refresh_hud()


func _xp_gain(amount: int) -> void:
	xp += amount
	while xp >= xp_next:
		xp -= xp_next
		level += 1
		xp_next = int(round(xp_next * 1.32))
		_recalculate_player_stats()
		health = max_health
		enchant_points += 1
		_show_message("Level %d · +1 enchantment point" % level)
	_save_progress()
	_rebuild_inventory()


func _equip(item: Dictionary) -> void:
	var slot := String(item.get("slot", item.type))
	if String(item.get("type", "")) == "artifact" and not gear[slot].is_empty():
		for artifact_slot in ARTIFACT_SLOTS:
			if gear[artifact_slot].is_empty():
				slot = artifact_slot
				item.slot = slot
				break
	if not gear.has(slot):
		return
	var item_id := int(item.get("id", -1))
	for index in range(inventory.size()):
		if int(inventory[index].get("id", -2)) == item_id:
			inventory.remove_at(index)
			break
	if not gear[slot].is_empty():
		inventory.append(gear[slot])
	gear[slot] = item.duplicate(true)
	if slot == "weapon" or slot in ARMOR_SLOTS:
		_refresh_player_gear_visuals()
	selected_item_id = item_id
	_recalculate_player_stats()
	loot_luck = _calculate_loot_luck()
	_save_progress()
	_refresh_hud()
	_rebuild_gear_list()
	_rebuild_inventory()
	_show_message("%s equipped" % item.name)


func _enchant_slot_count(rarity: String) -> int:
	if rarity == "Gilded": return 3
	if rarity == "Epic": return 2
	return 1


func _ensure_item_enchantments(item: Dictionary) -> Array:
	if String(item.get("type", "")) not in ["weapon", "armor"]:
		return []
	var raw: Variant = item.get("enchantments", [])
	var slots: Array = raw if raw is Array else []
	if slots.is_empty() and not String(item.get("enchant", "")).is_empty():
		slots.append({"name": String(item.get("enchant", "")), "rank": int(item.get("enchant_rank", 1)), "points_spent": int(item.get("enchant_points_spent", 0))})
	var pool: Array = WEAPON_ENCHANTS if String(item.type) == "weapon" else ARMOR_ENCHANTS
	var normalized: Array = []
	for entry in slots:
		if entry is Dictionary and not String(entry.get("name", "")).is_empty():
			normalized.append({"name": String(entry.get("name", "")), "rank": clampi(int(entry.get("rank", 1)), 1, 3), "points_spent": maxi(0, int(entry.get("points_spent", 0)))})
	var capacity := _enchant_slot_count(String(item.get("rarity", "Common")))
	while normalized.size() < capacity and normalized.size() < pool.size():
		var available := pool.duplicate()
		for existing in normalized: available.erase(String(existing.name))
		if available.is_empty(): break
		var name := String(available.pick_random())
		normalized.append({"name": name, "rank": 1, "points_spent": 0})
	item["enchantments"] = normalized
	_sync_primary_enchantment(item)
	return normalized


func _sync_primary_enchantment(item: Dictionary) -> void:
	var slots: Array = item.get("enchantments", [])
	if slots.is_empty(): return
	item["enchant"] = String(slots[0].get("name", ""))
	item["enchant_rank"] = int(slots[0].get("rank", 1))
	var total := 0
	for enchant_slot in slots: total += _enchant_slot_points_spent(item, enchant_slot)
	item["enchant_points_spent"] = total


func _enchant_slot_points_spent(item: Dictionary, enchant_slot: Dictionary) -> int:
	if enchant_slot.has("points_spent"):
		return maxi(0, int(enchant_slot.get("points_spent", 0)))
	var rank := clampi(int(enchant_slot.get("rank", 1)), 1, 3)
	var costs: Array = ENCHANT_COST.get(String(enchant_slot.get("name", "")), [1, 2])
	var total := 0
	for tier_index in range(rank - 1):
		if tier_index < costs.size(): total += int(costs[tier_index]) + (1 if String(item.get("rarity", "")) == "Gilded" else 0)
	return total


func _enchant_upgrade_cost(item: Dictionary, enchant_name: String, current_rank: int) -> int:
	var costs: Array = ENCHANT_COST.get(enchant_name, [1, 2])
	return int(costs[current_rank - 1]) + (1 if String(item.get("rarity", "")) == "Gilded" else 0)


func _upgrade_enchant(item: Dictionary, enchant_index: int) -> void:
	var slots := _ensure_item_enchantments(item)
	if enchant_index < 0 or enchant_index >= slots.size(): return
	var enchant_slot: Dictionary = slots[enchant_index]
	var rank := int(enchant_slot.get("rank", 1))
	if rank >= 3: return
	var enchant_name := String(enchant_slot.get("name", ""))
	var cost := _enchant_upgrade_cost(item, enchant_name, rank)
	if enchant_points < cost:
		_show_message("Need %d enchantment points" % cost)
		return
	enchant_points -= cost
	enchant_slot["rank"] = rank + 1
	enchant_slot["points_spent"] = _enchant_slot_points_spent(item, enchant_slot) + cost
	slots[enchant_index] = enchant_slot
	item["enchantments"] = slots
	_sync_primary_enchantment(item)
	_save_progress()
	_refresh_hud()
	_rebuild_inventory()
	_show_message("%s upgraded to tier %d" % [enchant_name, rank + 1])


func _has_enchant(slot: String, enchant: String) -> bool:
	for enchant_slot in _ensure_item_enchantments(gear[slot]):
		if String(enchant_slot.get("name", "")) == enchant: return true
	return false


func _armor_rank_total() -> int:
	var total := 0
	for slot in ARMOR_SLOTS:
		total += int(gear[slot].get("rank", 0))
	return total


func _armor_enchant_item(enchant: String) -> Dictionary:
	for slot in ARMOR_SLOTS:
		var item: Dictionary = gear[slot]
		for enchant_slot in _ensure_item_enchantments(item):
			if String(enchant_slot.get("name", "")) == enchant:
				var result := item.duplicate(false)
				result["enchant"] = String(enchant_slot.get("name", ""))
				result["enchant_rank"] = int(enchant_slot.get("rank", 1))
				result["enchant_points_spent"] = _enchant_slot_points_spent(item, enchant_slot)
				return result
	return {}


func _has_armor_enchant(enchant: String) -> bool:
	return not _armor_enchant_item(enchant).is_empty()


func _recalculate_player_stats() -> void:
	var anchor_bonus := 12.0 if String(gear.talisman.get("name", "")) == "Anchor Charm" else 0.0
	max_health = 100.0 + float(level - 1) * 8.0 + float(_armor_rank_total()) * 1.5 + anchor_bonus
	health = minf(health, max_health)


func _calculate_loot_luck() -> float:
	var luck := 1.0 + selected_tier * 0.055
	for slot in EQUIPMENT_SLOTS:
		luck += float(gear[slot].get("luck", 0.0))
	if String(gear.talisman.get("name", "")) == "Wayfarer Compass":
		luck += 0.2
	return luck


func _exact_passive_talisman(item_name: String) -> String:
	match item_name:
		"Moonwell Charm": return "Restores 1 health every second."
		"Wayfarer Compass": return "+0.20 loot luck."
		"Anchor Charm": return "+12 maximum health."
	return "No passive effect."


func _nearest_enemy() -> CharacterBody3D:
	var nearest: CharacterBody3D
	var best := INF
	for foe in enemies:
		if is_instance_valid(foe):
			var distance := _flat_distance(player.global_position, foe.global_position)
			if distance < best:
				best = distance
				nearest = foe
	return nearest


func _nearest_fracture_position() -> Vector3:
	return Vector3(13.0, 0.0, 8.0)


func _flat_distance(a: Vector3, b: Vector3) -> float:
	var delta := a - b
	delta.y = 0.0
	return delta.length()


func _material(color: Color, roughness: float = 0.82, emission: float = 0.0) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	if emission > 0.0:
		mat.emission_enabled = true
		mat.emission = color
		mat.emission_energy_multiplier = emission
	return mat


func _create_ui() -> void:
	red_sword_cursor = load("res://assets/cursor_sword.svg")
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)
	hud = Control.new()
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_PASS
	ui_layer.add_child(hud)
	_build_hud()
	_build_menu_overlay()
	_build_pause_overlay()
	_build_inventory_overlay()
	_build_settings_overlay()
	_build_salvage_confirmation()
	_build_merchant_overlay()
	_build_target_ring()


func _setup_camp_music() -> void:
	camp_music = AudioStreamPlayer.new()
	camp_music.name = "CampSoundtrack"
	var track := load("res://assets/Dalarna.mp3") as AudioStreamMP3
	if track != null:
		track.loop = true
		camp_music.stream = track
		camp_music.volume_db = linear_to_db(maxf(0.001, music_volume))
		add_child(camp_music)
		camp_music.play()


func _set_camp_music_active(active: bool) -> void:
	if not is_instance_valid(camp_music) or camp_music.stream == null:
		return
	if active:
		if not camp_music.playing: camp_music.play()
	else:
		camp_music.stop()


func _apply_audio_settings() -> void:
	var master_bus := AudioServer.get_bus_index("Master")
	if master_bus >= 0:
		AudioServer.set_bus_volume_linear(master_bus, clampf(master_volume, 0.0, 1.0))
	if is_instance_valid(camp_music):
		camp_music.volume_db = linear_to_db(maxf(0.001, music_volume))
	_save_progress()


func _build_hud() -> void:
	var identity := _panel(hud, Vector2(0.02, 0.025), Vector2(0.26, 0.11), Vector2.ZERO, Vector2.ZERO)
	var identity_stack := VBoxContainer.new()
	identity_stack.add_theme_constant_override("margin_left", 8)
	identity_stack.add_theme_constant_override("margin_top", 4)
	identity_stack.add_theme_constant_override("separation", 3)
	identity.add_child(identity_stack)
	level_label = _label(identity_stack, "LEVEL 1 · POWER 1", 14, Color("#e8d9b2"))
	_label(identity_stack, "I INVENTORY  ·  E INTERACT", 10, Color("#aebdb4"))
	var top := _panel(hud, Vector2(0.72, 0.025), Vector2(0.25, 0.075), Vector2.ZERO, Vector2.ZERO)
	arrows_label = _label(top, "➶  ARROWS  ·  30 / 30", 17, Color("#e5e7ea"))
	arrows_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	arrows_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	arrows_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	souls_label = _label(hud, "SOULS · 0/135", 12, Color("#c7acff"))
	souls_label.anchor_left = 0.72
	souls_label.anchor_right = 0.97
	souls_label.anchor_top = 0.105
	souls_label.anchor_bottom = 0.135
	souls_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var health_panel := _panel(hud, Vector2(0.025, 0.72), Vector2(0.205, 0.22), Vector2.ZERO, Vector2.ZERO)
	var health_stack := VBoxContainer.new()
	health_stack.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	health_stack.add_theme_constant_override("margin_left", 12)
	health_stack.add_theme_constant_override("margin_right", 12)
	health_stack.add_theme_constant_override("margin_top", 8)
	health_stack.add_theme_constant_override("margin_bottom", 8)
	health_stack.add_theme_constant_override("separation", 5)
	health_panel.add_child(health_stack)
	_label(health_stack, "HEALTH", 11, Color("#f0d89e"))
	health_bar = _bar(health_stack, Color("#e27467"))
	potion_button = _button("HEALING POTION · Q", Color("#a84f53"))
	potion_button.pressed.connect(_use_healing_potion)
	health_stack.add_child(potion_button)
	var stability_panel := _panel(hud, Vector2(0.39, 0.025), Vector2(0.25, 0.09), Vector2.ZERO, Vector2.ZERO)
	var stability_stack := VBoxContainer.new()
	stability_stack.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	stability_stack.add_theme_constant_override("margin_left", 12)
	stability_stack.add_theme_constant_override("margin_right", 12)
	stability_stack.add_theme_constant_override("margin_top", 5)
	stability_stack.add_theme_constant_override("separation", 2)
	stability_panel.add_child(stability_stack)
	_label(stability_stack, "STABILITY", 9, Color("#b7c6be"))
	stability_bar = _bar(stability_stack, Color("#d7b967"))
	var boss_panel := _panel(hud, Vector2(0.31, 0.105), Vector2(0.38, 0.085), Vector2.ZERO, Vector2.ZERO)
	boss_panel.name = "BossHudPanel"
	boss_panel.visible = false
	var boss_stack := VBoxContainer.new()
	boss_stack.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	boss_stack.add_theme_constant_override("margin_left", 12)
	boss_stack.add_theme_constant_override("margin_right", 12)
	boss_stack.add_theme_constant_override("margin_top", 3)
	boss_stack.add_theme_constant_override("separation", 2)
	boss_panel.add_child(boss_stack)
	boss_name_label = _label(boss_stack, "BOSS", 13, Color("#f0d89e"))
	boss_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	boss_health_bar = _bar(boss_stack, Color("#e65b54"))
	status_label = _label(hud, "Click to move · click a foe to attack", 12, Color("#f0d89e"))
	status_label.anchor_left = 0.29
	status_label.anchor_right = 0.71
	status_label.anchor_top = 0.14
	status_label.anchor_bottom = 0.18
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	artifact_effect_label = _label(hud, "", 11, Color("#d4c4ff"))
	artifact_effect_label.anchor_left = 0.32
	artifact_effect_label.anchor_right = 0.68
	artifact_effect_label.anchor_top = 0.285
	artifact_effect_label.anchor_bottom = 0.33
	artifact_effect_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	run_timer_label = _label(hud, "WAYFARER'S CAMP", 12, Color("#f0d89e"))
	run_timer_label.anchor_left = 0.32
	run_timer_label.anchor_right = 0.68
	run_timer_label.anchor_top = 0.20
	run_timer_label.anchor_bottom = 0.24
	run_timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	objective_label = _label(hud, "Walk to the expedition table · Press E", 11, Color("#b8c8be"))
	objective_label.anchor_left = 0.30
	objective_label.anchor_right = 0.70
	objective_label.anchor_top = 0.24
	objective_label.anchor_bottom = 0.28
	objective_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var artifact_panel := _panel(hud, Vector2(0.365, 0.76), Vector2(0.27, 0.16), Vector2.ZERO, Vector2.ZERO)
	var artifact_row := HBoxContainer.new()
	artifact_row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	artifact_row.add_theme_constant_override("separation", 7)
	artifact_panel.add_child(artifact_row)
	artifact_hud_buttons.clear()
	for artifact_index in range(3):
		var artifact_button := _button("%d · EMPTY" % (artifact_index + 1), Color("#497080"))
		artifact_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		artifact_button.custom_minimum_size.y = 68
		artifact_button.pressed.connect(_use_artifact.bind(artifact_index))
		artifact_row.add_child(artifact_button)
		artifact_hud_buttons.append(artifact_button)
	var xp_panel := _panel(hud, Vector2(0.25, 0.925), Vector2(0.50, 0.06), Vector2.ZERO, Vector2.ZERO)
	var xp_inner := Control.new()
	xp_panel.add_child(xp_inner)
	xp_bar = _bar(xp_inner, Color("#8dd6b5"))
	xp_bar.anchor_left = 0.02
	xp_bar.anchor_right = 0.98
	xp_bar.anchor_top = 0.53
	xp_bar.anchor_bottom = 0.9
	xp_text_label = _label(xp_inner, "LEVEL 1 · EXPERIENCE", 9, Color("#d4e2db"))
	xp_text_label.anchor_left = 0.02
	xp_text_label.anchor_right = 0.98
	xp_text_label.anchor_top = 0.0
	xp_text_label.anchor_bottom = 0.48
	xp_text_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	xp_text_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	var bottom := _panel(hud, Vector2(0.78, 0.90), Vector2(0.20, 0.06), Vector2.ZERO, Vector2.ZERO)
	var bottom_text := _label(bottom, "NORMAL · LOOT ×1.00", 10, Color("#e6d9bd"))
	bottom_text.name = "BottomLabel"
	bottom_text.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bottom_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bottom_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER


func _build_menu_overlay() -> void:
	menu_overlay = ColorRect.new()
	menu_overlay.color = Color(0.025, 0.04, 0.045, 0.66)
	menu_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_layer.add_child(menu_overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_overlay.add_child(center)
	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(540, 590)
	center.add_child(card)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 13)
	content.add_theme_constant_override("margin_left", 26)
	content.add_theme_constant_override("margin_right", 26)
	content.add_theme_constant_override("margin_top", 25)
	content.add_theme_constant_override("margin_bottom", 25)
	card.add_child(content)
	_label(content, "WAYFARER'S CAMP", 12, Color("#82d6b2"))
	_label(content, "Rest. Refit. Descend.", 28, Color("#f3f0e6"))
	_label(content, "Choose a mission at the expedition table. Explore its broad maze, then cross the great hall entrance to face its boss.", 13, Color("#afbab7"))
	_label(content, "MISSION", 10, Color("#aab7b2"))
	mission_picker = OptionButton.new()
	for i in range(MISSION_NAMES.size()):
		mission_picker.add_item("%s  —  %s" % [MISSION_NAMES[i], MISSION_SUBTITLES[i]], i)
	mission_picker.item_selected.connect(func(index: int) -> void:
		selected_mission = index
	)
	content.add_child(mission_picker)
	_label(content, "THREAT TIER", 10, Color("#aab7b2"))
	tier_picker = OptionButton.new()
	for i in range(28):
		tier_picker.add_item(_tier_name(i), i)
		if i > unlocked_tier:
			tier_picker.set_item_disabled(i, true)
	tier_picker.select(mini(selected_tier, unlocked_tier))
	tier_picker.item_selected.connect(func(index: int): selected_tier = index)
	content.add_child(tier_picker)
	_label(content, "ADVENTURE · deal 150%, take 65%   |   NORMAL · 100% / 100%   |   APOCALYPSE · deal 75%, take 150%", 10, Color("#d3c5a3"))
	summary_label = _label(content, "Adventure, Normal, and Apocalypse are open. Clear all seven Apocalypse bosses to unlock Apocalypse +1.", 12, Color("#c3ccc5"))
	var button_row := HBoxContainer.new()
	button_row.add_theme_constant_override("separation", 9)
	content.add_child(button_row)
	var enter := _button("ENTER DUNGEON", Color("#d5aa62"))
	enter.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	enter.pressed.connect(_start_run)
	button_row.add_child(enter)
	var inventory_open := _button("INVENTORY", Color("#657967"))
	inventory_open.pressed.connect(_toggle_inventory)
	button_row.add_child(inventory_open)
	var blacksmith := _button("CRAFT RARE · 35 SHARDS", Color("#806c48"))
	blacksmith.pressed.connect(_buy_camp_gear)
	button_row.add_child(blacksmith)
	var settings := _button("SETTINGS · KEYBINDS", Color("#536e83"))
	settings.pressed.connect(_open_settings)
	content.add_child(settings)
	var close_board := _button("CLOSE TABLE  [ESC]", Color("#46524f"))
	close_board.pressed.connect(func() -> void:
		menu_overlay.visible = false
		paused = false
	)
	content.add_child(close_board)


func _build_pause_overlay() -> void:
	pause_overlay = ColorRect.new()
	pause_overlay.color = Color(0.02, 0.03, 0.035, 0.78)
	pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_overlay.visible = false
	ui_layer.add_child(pause_overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_overlay.add_child(center)
	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(420, 300)
	center.add_child(card)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 12)
	card.add_child(content)
	_label(content, "PAUSED", 15, Color("#f0d89e"))
	_label(content, "Take a breath. Your adventure can wait.", 16, Color("#eef2e9"))
	var resume := _button("RESUME", Color("#d5aa62"))
	resume.pressed.connect(_toggle_pause)
	content.add_child(resume)
	return_camp_button = _button("RETURN TO CAMP", Color("#46524f"))
	return_camp_button.visible = not in_camp
	return_camp_button.pressed.connect(func() -> void:
		game_active = false
		paused = true
		pause_overlay.visible = false
		_show_menu()
	)
	content.add_child(return_camp_button)
	var settings := _button("SETTINGS", Color("#536e83"))
	settings.pressed.connect(_open_settings)
	content.add_child(settings)


func _build_settings_overlay() -> void:
	settings_overlay = ColorRect.new()
	settings_overlay.color = Color(0.015, 0.025, 0.03, 0.94)
	settings_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	settings_overlay.visible = false
	settings_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	ui_layer.add_child(settings_overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	settings_overlay.add_child(center)
	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(700.0, 850.0)
	center.add_child(card)
	var frame := VBoxContainer.new()
	frame.add_theme_constant_override("separation", 10)
	frame.add_theme_constant_override("margin_left", 20)
	frame.add_theme_constant_override("margin_right", 20)
	frame.add_theme_constant_override("margin_top", 16)
	frame.add_theme_constant_override("margin_bottom", 16)
	card.add_child(frame)
	_label(frame, "SETTINGS", 21, Color("#f0d89e"))
	_label(frame, "Audio, display, graphics, gameplay, and controls", 11, Color("#bdc9c4"))
	settings_scroll = ScrollContainer.new()
	settings_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	settings_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	frame.add_child(settings_scroll)
	settings_content = VBoxContainer.new()
	settings_content.add_theme_constant_override("separation", 6)
	settings_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings_scroll.add_child(settings_content)
	_settings_section("AUDIO")
	_settings_slider_row("Master volume", 0.0, 1.0, master_volume, "", func(value: float): master_volume = value; _apply_audio_settings())
	_settings_slider_row("Camp music", 0.0, 1.0, music_volume, "", func(value: float): music_volume = value; _apply_audio_settings())
	_settings_slider_row("Sound effects", 0.0, 1.0, sfx_volume, "", func(value: float): sfx_volume = value; _apply_audio_settings())
	_settings_section("DISPLAY")
	var display_row := HBoxContainer.new()
	settings_content.add_child(display_row)
	var display_label := _label(display_row, "Window mode", 11, Color("#e8e4d9"))
	display_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var display_mode := OptionButton.new()
	display_mode.add_item("Windowed")
	display_mode.add_item("Fullscreen")
	display_mode.select(1 if fullscreen_mode else 0)
	display_mode.item_selected.connect(_apply_display_mode)
	display_row.add_child(display_mode)
	var resolution_row := HBoxContainer.new()
	settings_content.add_child(resolution_row)
	var resolution_label := _label(resolution_row, "Window resolution", 11, Color("#e8e4d9"))
	resolution_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var resolution := OptionButton.new()
	for size in [Vector2i(1280, 720), Vector2i(1600, 900), Vector2i(1920, 1080)]:
		resolution.add_item("%d × %d" % [size.x, size.y])
	resolution.select(window_resolution_index)
	resolution.item_selected.connect(_apply_resolution)
	resolution_row.add_child(resolution)
	var vsync := CheckButton.new()
	vsync.text = "Vertical sync"
	vsync.button_pressed = vsync_enabled
	vsync.toggled.connect(func(enabled: bool) -> void:
		vsync_enabled = enabled
		DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED if enabled else DisplayServer.VSYNC_DISABLED)
		_save_progress()
	)
	settings_content.add_child(vsync)
	_settings_section("GRAPHICS")
	_settings_slider_row("Camera zoom", 17.0, 30.0, camera_zoom, "", func(value: float) -> void:
		camera_zoom = value
		if is_instance_valid(camera): camera.size = value
		_save_progress()
	)
	var shadows := CheckButton.new()
	shadows.text = "High quality shadows"
	shadows.button_pressed = high_quality_shadows
	shadows.toggled.connect(_set_shadow_quality)
	settings_content.add_child(shadows)
	_settings_section("GAMEPLAY & ACCESSIBILITY")
	var damage_numbers := CheckButton.new()
	damage_numbers.text = "Show floating damage numbers"
	damage_numbers.button_pressed = show_damage_numbers
	damage_numbers.toggled.connect(func(enabled: bool) -> void:
		show_damage_numbers = enabled
		_save_progress()
	)
	settings_content.add_child(damage_numbers)
	_settings_section("CONTROLS · CLICK A KEY TO REBIND")
	settings_buttons.clear()
	for action in ["move_up", "move_down", "move_left", "move_right", "attack", "ranged", "dodge", "interact", "potion", "inventory", "artifact1", "artifact2", "artifact3"]:
		var row := HBoxContainer.new()
		settings_content.add_child(row)
		var name_label := _label(row, action.replace("_", " ").capitalize(), 11, Color("#e8e4d9"))
		name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var bind_button := _button("", Color("#536e83"))
		bind_button.custom_minimum_size = Vector2(180.0, 31.0)
		bind_button.pressed.connect(_begin_rebind.bind(action))
		row.add_child(bind_button)
		settings_buttons[action] = bind_button
	var controls_row := HBoxContainer.new()
	frame.add_child(controls_row)
	var reset := _button("RESET TO DEFAULTS", Color("#765c42"))
	reset.pressed.connect(_reset_settings)
	controls_row.add_child(reset)
	var close := _button("BACK", Color("#657967"))
	close.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	close.pressed.connect(func() -> void:
		listening_action = ""
		settings_overlay.visible = false
		_save_progress()
	)
	controls_row.add_child(close)
	_refresh_settings_buttons()
	_apply_audio_settings()
	_apply_window_preferences()
	if is_instance_valid(camera): camera.size = camera_zoom


func _settings_section(title: String) -> void:
	var label := _label(settings_content, title, 11, Color("#eacb82"))
	label.custom_minimum_size.y = 22.0


func _settings_slider_row(title: String, minimum: float, maximum: float, initial: float, suffix: String, changed: Callable) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	settings_content.add_child(row)
	var title_label := _label(row, title, 11, Color("#e8e4d9"))
	title_label.custom_minimum_size.x = 170.0
	var slider := HSlider.new()
	slider.min_value = minimum
	slider.max_value = maximum
	slider.step = 0.01
	slider.value = initial
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(slider)
	var value_label := _label(row, "", 10, Color("#bdc9c4"))
	value_label.custom_minimum_size.x = 55.0
	var update_value := func(value: float) -> void:
		value_label.text = ("%.0f" % (value * 100.0) if maximum <= 1.0 else "%.1f" % value) + suffix
		changed.call(value)
	slider.value_changed.connect(update_value)
	update_value.call(initial)


func _apply_display_mode(index: int) -> void:
	fullscreen_mode = index == 1
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if fullscreen_mode else DisplayServer.WINDOW_MODE_WINDOWED)
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED if vsync_enabled else DisplayServer.VSYNC_DISABLED)
	_save_progress()


func _apply_resolution(index: int) -> void:
	var sizes: Array[Vector2i] = [Vector2i(1280, 720), Vector2i(1600, 900), Vector2i(1920, 1080)]
	window_resolution_index = clampi(index, 0, sizes.size() - 1)
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	fullscreen_mode = false
	DisplayServer.window_set_size(sizes[window_resolution_index])
	_save_progress()


func _apply_window_preferences() -> void:
	var sizes: Array[Vector2i] = [Vector2i(1280, 720), Vector2i(1600, 900), Vector2i(1920, 1080)]
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if fullscreen_mode else DisplayServer.WINDOW_MODE_WINDOWED)
	if not fullscreen_mode:
		DisplayServer.window_set_size(sizes[clampi(window_resolution_index, 0, sizes.size() - 1)])


func _set_shadow_quality(enabled: bool) -> void:
	high_quality_shadows = enabled
	var sun := get_node_or_null("DungeonSun") as DirectionalLight3D
	if is_instance_valid(sun): sun.shadow_enabled = enabled
	_save_progress()


func _reset_settings() -> void:
	keybinds = {"move_up": KEY_W, "move_down": KEY_S, "move_left": KEY_A, "move_right": KEY_D, "attack": KEY_SPACE, "ranged": KEY_F, "dodge": KEY_R, "interact": KEY_E, "potion": KEY_Q, "inventory": KEY_I, "artifact1": KEY_1, "artifact2": KEY_2, "artifact3": KEY_3}
	master_volume = 1.0
	music_volume = 0.55
	sfx_volume = 0.8
	camera_zoom = 23.0
	high_quality_shadows = true
	show_damage_numbers = true
	fullscreen_mode = false
	window_resolution_index = 1
	vsync_enabled = true
	_apply_audio_settings()
	if is_instance_valid(camera): camera.size = camera_zoom
	_set_shadow_quality(high_quality_shadows)
	_save_progress()
	settings_overlay.queue_free()
	_build_settings_overlay()
	settings_overlay.visible = true


func _open_settings() -> void:
	listening_action = ""
	_refresh_settings_buttons()
	settings_overlay.visible = true


func _begin_rebind(action: String) -> void:
	listening_action = action
	_refresh_settings_buttons()


func _refresh_settings_buttons() -> void:
	for action in settings_buttons:
		var button: Button = settings_buttons[action]
		button.text = "PRESS A KEY…" if listening_action == action else _key_name(int(keybinds[action]))


func _key_name(keycode: int) -> String:
	return OS.get_keycode_string(keycode).to_upper()


func _build_inventory_overlay() -> void:
	inventory_overlay = ColorRect.new()
	inventory_overlay.color = Color(0.015, 0.025, 0.03, 0.88)
	inventory_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	inventory_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	inventory_overlay.visible = false
	ui_layer.add_child(inventory_overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	inventory_overlay.add_child(center)
	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(1190.0, 740.0)
	center.add_child(card)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 12)
	content.add_theme_constant_override("margin_left", 22)
	content.add_theme_constant_override("margin_right", 22)
	content.add_theme_constant_override("margin_top", 18)
	content.add_theme_constant_override("margin_bottom", 18)
	card.add_child(content)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 20)
	content.add_child(header)
	var title_column := VBoxContainer.new()
	title_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title_column)
	_label(title_column, "WAYFARER'S PACK   /   INVENTORY", 23, Color("#f0d89e"))
	inventory_equipped_label = _label(title_column, "LEVEL 1 · POWER 1", 12, Color("#8ed3e5"))
	_label(title_column, "Drag gear onto a matching equipment slot · Favorite ★ locks it from salvaging", 10, Color("#b9c6c2"))
	inventory_resource_box = HBoxContainer.new()
	inventory_resource_box.add_theme_constant_override("separation", 14)
	header.add_child(inventory_resource_box)
	var main_row := HBoxContainer.new()
	main_row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_row.add_theme_constant_override("separation", 16)
	content.add_child(main_row)
	var hero_panel := PanelContainer.new()
	hero_panel.custom_minimum_size = Vector2(205.0, 0.0)
	hero_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_row.add_child(hero_panel)
	var hero_column := VBoxContainer.new()
	hero_column.add_theme_constant_override("separation", 8)
	hero_panel.add_child(hero_column)
	_label(hero_column, "WAYFINDER", 12, Color("#8ed8e8"))
	var preview_container := SubViewportContainer.new()
	preview_container.custom_minimum_size = Vector2(190.0, 385.0)
	preview_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	preview_container.stretch = true
	hero_column.add_child(preview_container)
	var preview_viewport := SubViewport.new()
	preview_viewport.size = Vector2i(320, 560)
	preview_viewport.own_world_3d = true
	preview_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	preview_viewport.transparent_bg = false
	preview_container.add_child(preview_viewport)
	var preview_stage := Node3D.new()
	preview_viewport.add_child(preview_stage)
	var preview_floor := MeshInstance3D.new()
	var preview_floor_mesh := BoxMesh.new()
	preview_floor_mesh.size = Vector3(4.0, 0.16, 4.0)
	preview_floor.mesh = preview_floor_mesh
	preview_floor.position.y = -0.1
	preview_floor.material_override = _material(Color("#384d48"), 0.95)
	preview_stage.add_child(preview_floor)
	inventory_preview = player.duplicate() as CharacterBody3D
	inventory_preview.name = "InventoryWayfinder"
	inventory_preview.set_meta("inventory_preview", true)
	inventory_preview.position = Vector3.ZERO
	inventory_preview.rotation.y = 0.0
	inventory_preview.collision_layer = 0
	inventory_preview.collision_mask = 0
	var preview_collision: CollisionShape3D = inventory_preview.get_node_or_null("CollisionShape3D")
	if is_instance_valid(preview_collision):
		preview_collision.disabled = true
	preview_stage.add_child(inventory_preview)
	var preview_light := DirectionalLight3D.new()
	preview_light.rotation_degrees = Vector3(-42.0, -25.0, 0.0)
	preview_light.light_energy = 1.4
	preview_stage.add_child(preview_light)
	var preview_camera := Camera3D.new()
	preview_camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	preview_camera.size = 3.8
	preview_camera.look_at_from_position(Vector3(3.0, 2.8, -5.0), Vector3(0.0, 0.85, 0.0), Vector3.UP)
	preview_camera.current = true
	preview_stage.add_child(preview_camera)
	_label(hero_column, "LEVEL %d" % level, 14, Color("#c78aff"))
	_label(hero_column, "GEAR POWER  %d" % _power_level(), 12, Color("#8ed8e8"))
	var list_panel := PanelContainer.new()
	list_panel.custom_minimum_size.x = 455.0
	list_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_row.add_child(list_panel)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_install_inventory_drag(scroll, "backpack", -1)
	list_panel.add_child(scroll)
	inventory_list = VBoxContainer.new()
	inventory_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inventory_list.add_theme_constant_override("separation", 8)
	_install_inventory_drag(inventory_list, "backpack", -1)
	scroll.add_child(inventory_list)
	var detail_panel := PanelContainer.new()
	detail_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	detail_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_row.add_child(detail_panel)
	inventory_detail_box = VBoxContainer.new()
	inventory_detail_box.add_theme_constant_override("separation", 10)
	inventory_detail_box.add_theme_constant_override("margin_left", 14)
	inventory_detail_box.add_theme_constant_override("margin_right", 14)
	inventory_detail_box.add_theme_constant_override("margin_top", 14)
	inventory_detail_box.add_theme_constant_override("margin_bottom", 14)
	detail_panel.add_child(inventory_detail_box)
	var close := _button("BACK  [I / ESC]", Color("#657967"))
	close.pressed.connect(_toggle_inventory)
	content.add_child(close)


func _toggle_inventory() -> void:
	if not is_instance_valid(inventory_overlay):
		return
	inventory_overlay.visible = not inventory_overlay.visible
	if inventory_overlay.visible:
		_rebuild_inventory()
	if game_active:
		paused = inventory_overlay.visible
		pause_overlay.visible = false
	elif in_camp:
		paused = inventory_overlay.visible or menu_overlay.visible
		pause_overlay.visible = false


func _build_target_ring() -> void:
	hit_ring = MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.33
	torus.outer_radius = 0.42
	hit_ring.mesh = torus
	hit_ring.rotation_degrees.x = 90.0
	hit_ring.material_override = _material(Color("#e8c16b"), 0.35, 0.45)
	hit_ring.visible = false
	arena_root.add_child(hit_ring)


func _panel(parent: Control, anchor: Vector2, size: Vector2, offset: Vector2, _unused: Vector2) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.anchor_left = anchor.x
	panel.anchor_top = anchor.y
	panel.anchor_right = anchor.x + size.x
	panel.anchor_bottom = anchor.y + size.y
	panel.offset_left = offset.x
	panel.offset_top = offset.y
	panel.offset_right = 0.0
	panel.offset_bottom = 0.0
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.075, 0.095, 0.10, 0.92)
	style.border_color = Color("#53605b")
	style.set_border_width_all(1)
	style.set_corner_radius_all(7)
	style.content_margin_left = 8
	style.content_margin_right = 8
	style.content_margin_top = 6
	style.content_margin_bottom = 6
	panel.add_theme_stylebox_override("panel", style)
	parent.add_child(panel)
	return panel


func _label(parent: Node, text: String, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	parent.add_child(label)
	return label


func _bar(parent: Node, color: Color) -> ProgressBar:
	var bar := ProgressBar.new()
	bar.show_percentage = false
	bar.custom_minimum_size.y = 13
	bar.max_value = 100.0
	bar.add_theme_stylebox_override("background", _bar_style(Color("#303b3b")))
	bar.add_theme_stylebox_override("fill", _bar_style(color))
	parent.add_child(bar)
	return bar


func _bar_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(4)
	return style


func _button(text: String, color: Color) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size.y = 39
	button.add_theme_color_override("font_color", Color("#f2f0e8"))
	var style := StyleBoxFlat.new()
	style.bg_color = color.darkened(0.48)
	style.border_color = color
	style.set_border_width_all(1)
	style.set_corner_radius_all(5)
	button.add_theme_stylebox_override("normal", style)
	var hover := style.duplicate()
	hover.bg_color = color.darkened(0.28)
	button.add_theme_stylebox_override("hover", hover)
	button.pressed.connect(_play_sfx.bind("click"))
	button.mouse_entered.connect(_play_sfx.bind("hover"))
	return button


func _refresh_hud() -> void:
	if not is_instance_valid(health_bar):
		return
	health_bar.max_value = max_health
	health_bar.value = health
	xp_bar.max_value = xp_next
	xp_bar.value = xp
	if is_instance_valid(xp_text_label):
		xp_text_label.text = "LEVEL %d · EXPERIENCE  %d / %d" % [level, xp, xp_next]
	stability_bar.value = stability
	var boss_panel := hud.get_node_or_null("BossHudPanel")
	var boss_visible := game_active and boss_spawned and is_instance_valid(boss_actor)
	if boss_panel is Control: boss_panel.visible = boss_visible
	if boss_visible:
		boss_name_label.text = BOSS_NAMES[selected_mission].to_upper()
		boss_health_bar.max_value = maxf(1.0, float(boss_actor.get_meta("max_health", 1.0)))
		boss_health_bar.value = maxf(0.0, float(boss_actor.get_meta("health", 0.0)))
	level_label.text = "LEVEL %d  ·  POWER %d" % [level, _power_level()]
	if is_instance_valid(arrows_label):
		arrows_label.text = "ARROWS  ·  %d / %d" % [arrows, max_arrows]
	if is_instance_valid(souls_label): souls_label.text = "SOULS  ·  %d / %d" % [souls, MAX_SOULS]
	if is_instance_valid(artifact_effect_label):
		var effect_lines: Array[String] = []
		for effect_name in active_artifact_effects.keys():
			effect_lines.append("%s · %.0fs" % [effect_name, float(active_artifact_effects[effect_name])])
		artifact_effect_label.text = "ACTIVE ARTIFACT EFFECTS · " + "  |  ".join(effect_lines) if not effect_lines.is_empty() else ""
	if is_instance_valid(potion_button):
		var potion_key := _key_name(int(keybinds.potion))
		if potion_cooldown <= 0.0:
			potion_button.text = "HEALING POTION · +70%% · %s" % potion_key
		else:
			potion_button.text = "POTION · %.0fs · %s" % [potion_cooldown, potion_key]
		potion_button.disabled = potion_cooldown > 0.0 or health >= max_health or not game_active
	for artifact_index in range(artifact_hud_buttons.size()):
		var artifact_button: Button = artifact_hud_buttons[artifact_index]
		var artifact_item: Dictionary = gear[ARTIFACT_SLOTS[artifact_index]]
		var artifact_key := _key_name(int(keybinds["artifact%d" % (artifact_index + 1)]))
		if artifact_item.is_empty():
			artifact_button.text = "%s\nEMPTY" % artifact_key
			artifact_button.icon = null
			artifact_button.disabled = true
		else:
			artifact_button.icon = load(_item_icon_path(artifact_item))
			var cooldown := artifact_cooldowns[artifact_index]
			artifact_button.text = "%s\n%s" % [artifact_key, "READY" if cooldown <= 0.0 else "%.0fs" % cooldown]
			artifact_button.disabled = cooldown > 0.0 or not (game_active or in_camp)
	var stability_text := "STABLE"
	if stability > 72.0:
		stability_text = "CRITICAL · fractures can hurt you"
	elif stability > 40.0:
		stability_text = "UNSTEADY · enemies are faster"
	if is_instance_valid(boss_actor):
		stability_text = "WARDEN %d%% HP  ·  STABILITY %d%%" % [int(float(boss_actor.get_meta("health")) / float(boss_actor.get_meta("max_health")) * 100.0), int(stability)]
	status_label.text = status_message if status_timer > 0.0 else "%s  ·  %d%%" % [stability_text, int(stability)]
	if is_instance_valid(run_timer_label):
		if not game_active:
			run_timer_label.text = "WAYFARER'S CAMP · READY FOR A DESCENT"
		elif boss_spawned:
			run_timer_label.text = "BOSS FIGHT · %s" % BOSS_NAMES[selected_mission].to_upper()
		else:
			run_timer_label.text = "EXPLORE THE RUINS · FIND THE NORTHERN GATE"
	if is_instance_valid(objective_label):
		if in_camp:
			objective_label.text = "Mission board open · choose a dungeon" if menu_overlay.visible else "Walk to the expedition table · Press %s" % _key_name(int(keybinds.interact))
		elif not game_active:
			objective_label.text = "Return to camp"
		elif boss_spawned:
			objective_label.text = "Defeat %s · caches %d/3" % [BOSS_NAMES[selected_mission], caches_opened]
		else:
			objective_label.text = "Explore · caches %d/3 · shrines %d/2 · E to interact" % [caches_opened, shrines_used]
	var tier := _tier_name(selected_tier)
	if is_instance_valid(return_camp_button): return_camp_button.disabled = boss_visible
	status_label.visible = not boss_visible
	var bottom := hud.get_node_or_null("BottomLabel")
	if bottom is Label:
		bottom.text = "%s  ·  %s  ·  LOOT ×%.2f" % [tier.to_upper(), MISSION_NAMES[selected_mission].to_upper(), loot_luck]


func _rebuild_gear_list() -> void:
	if not is_instance_valid(gear_box):
		return
	for child in gear_box.get_children():
		child.queue_free()
	for slot in EQUIPMENT_SLOTS:
		var item: Dictionary = gear[slot]
		if not item.is_empty():
			_label(gear_box, "%s · PWR %d" % [String(item.name), int(item.rank)], 9, Color("#e9e3d4"))


func _rebuild_inventory() -> void:
	if is_instance_valid(inventory_equipped_label):
		inventory_equipped_label.text = "LEVEL %d  ·  GEAR POWER %d  ·  %d / 8 BACKPACK" % [level, _power_level(), inventory.size()]
	if is_instance_valid(inventory_resource_box):
		for child in inventory_resource_box.get_children():
			child.queue_free()
		_add_resource_chip(inventory_resource_box, "res://assets/coin.svg", str(coins), Color("#f5cf57"))
		_add_resource_chip(inventory_resource_box, "res://assets/shard.svg", str(shards), Color("#8bd7ff"))
		_add_resource_chip(inventory_resource_box, "res://assets/enchant_point.svg", str(enchant_points), Color("#c98bff"))
		_add_resource_chip(inventory_resource_box, "res://assets/soul.svg", "%d/%d" % [souls, MAX_SOULS], Color("#9b85ff"))
	if is_instance_valid(pack_box):
		_populate_inventory_list(pack_box, false)
	if is_instance_valid(inventory_list):
		_populate_inventory_list(inventory_list, true)
		_populate_item_details()


func _add_resource_chip(parent: Control, icon_path: String, amount: String, color: Color) -> void:
	var chip := HBoxContainer.new()
	chip.add_theme_constant_override("separation", 4)
	parent.add_child(chip)
	var icon := TextureRect.new()
	icon.texture = load(icon_path)
	icon.custom_minimum_size = Vector2(25.0, 25.0)
	icon.expand_mode = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	chip.add_child(icon)
	_label(chip, amount, 13, color)


func _item_icon_path(item: Dictionary) -> String:
	if String(item.get("type", "")) == "artifact":
		return "res://assets/artifacts/%s.svg" % _artifact_slug(String(item.get("name", "artifact")))
	if String(item.get("type", "")) == "armor":
		return "res://assets/item_%s.svg" % String(item.get("slot", "armor"))
	var kind := String(item.get("type", ""))
	return "res://assets/item_%s.svg" % ("artifact" if kind == "artifact" else "talisman" if kind == "talisman" else "weapon")


func _is_item_equipped(item_id: int) -> bool:
	for slot in EQUIPMENT_SLOTS:
		if int(gear[slot].get("id", -1)) == item_id:
			return true
	return false


func _populate_inventory_list(container: VBoxContainer, include_equipped: bool) -> void:
	for child in container.get_children():
		child.queue_free()
	if include_equipped:
		_label(container, "WEAPON", 11, Color("#85d7e8"))
		_add_equipped_slot_row(container, "weapon")
		_label(container, "ARMOR", 11, Color("#85d7e8"))
		for slot in ARMOR_SLOTS:
			_add_equipped_slot_row(container, slot)
		_label(container, "ARTIFACTS · HOTKEYS 1 / 2 / 3", 11, Color("#85d7e8"))
		for slot in ARTIFACT_SLOTS:
			_add_equipped_slot_row(container, slot)
		_label(container, "TALISMAN · PASSIVE", 11, Color("#85d7e8"))
		_add_equipped_slot_row(container, "talisman")
		_label(container, "BACKPACK · %d / 8" % inventory.size(), 12, Color("#f0d89e"))
	if inventory.is_empty():
		_label(container, "Your drops appear here.", 11, Color("#98aaa4"))
		return
	for item in inventory:
		_render_inventory_row(container, item, false)


func _add_equipped_slot_row(container: VBoxContainer, slot: String) -> void:
	var item: Dictionary = gear[slot]
	if item.is_empty():
		var drop_zone := PanelContainer.new()
		drop_zone.custom_minimum_size.y = 46.0
		_install_inventory_drag(drop_zone, slot, -1)
		container.add_child(drop_zone)
		var hint := _label(drop_zone, "%s · drop gear here" % _slot_display_name(slot), 10, Color("#778783"))
		hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		hint.mouse_filter = Control.MOUSE_FILTER_PASS
	else:
		_render_inventory_row(container, item, true)


func _render_inventory_row(container: VBoxContainer, item: Dictionary, equipped: bool) -> void:
	var card := PanelContainer.new()
	_install_inventory_drag(card, String(item.get("slot", "backpack")) if equipped else "backpack", int(item.get("id", -1)))
	container.add_child(card)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 9)
	row.mouse_filter = Control.MOUSE_FILTER_PASS
	card.add_child(row)
	var icon := TextureRect.new()
	icon.mouse_filter = Control.MOUSE_FILTER_PASS
	icon.custom_minimum_size = Vector2(48.0, 48.0)
	icon.expand_mode = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.texture = load(_item_icon_path(item))
	row.add_child(icon)
	var text_stack := VBoxContainer.new()
	text_stack.mouse_filter = Control.MOUSE_FILTER_PASS
	text_stack.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(text_stack)
	var favorite_mark := "★  " if bool(item.get("favorite", false)) else ""
	_label(text_stack, "%s%s · %s" % [favorite_mark, item.rarity, item.name], 11, _rarity_color(String(item.rarity)))
	_label(text_stack, "PWR %d · %s · T%d" % [item.rank, _slot_display_name(String(item.get("slot", item.type))), item.get("enchant_rank", 1)], 9, Color("#bdc9c4"))
	for text_child in text_stack.get_children():
		if text_child is Control: text_child.mouse_filter = Control.MOUSE_FILTER_PASS
	var more := _button("MORE", Color("#536e83"))
	more.custom_minimum_size = Vector2(68.0, 30.0)
	more.pressed.connect(_select_inventory_item.bind(int(item.get("id", -1))))
	row.add_child(more)
	if not equipped:
		var equip_button := _button("EQUIP", Color("#657967"))
		equip_button.custom_minimum_size = Vector2(78.0, 30.0)
		equip_button.pressed.connect(_equip.bind(item))
		row.add_child(equip_button)


func _install_inventory_drag(control: Control, target_slot: String, item_id: int) -> void:
	control.set_script(load("res://scripts/inventory_drag.gd"))
	control.set("drag_owner", self)
	control.set("drop_slot", target_slot)
	control.set("drag_item_id", item_id)


func _handle_inventory_drag(item_id: int, target_slot: String) -> void:
	var item: Dictionary = {}
	var source_slot := ""
	var source_index := -1
	for slot in EQUIPMENT_SLOTS:
		if int(gear[slot].get("id", -2)) == item_id:
			item = gear[slot].duplicate(true)
			source_slot = slot
			break
	for index in range(inventory.size()):
		if int(inventory[index].get("id", -2)) == item_id:
			item = inventory[index].duplicate(true)
			source_index = index
			break
	if item.is_empty(): return
	if target_slot == "backpack":
		if source_slot.is_empty(): return
		gear[source_slot] = {}
		inventory.append(item)
	else:
		if not gear.has(target_slot) or target_slot == source_slot: return
		var item_type := String(item.get("type", ""))
		var valid_target := false
		if target_slot in ARTIFACT_SLOTS: valid_target = item_type == "artifact"
		elif target_slot == "talisman": valid_target = item_type == "talisman"
		elif target_slot in ARMOR_SLOTS: valid_target = item_type == "armor"
		elif target_slot == "weapon": valid_target = item_type == "weapon"
		if not valid_target:
			_show_message("That item does not fit the %s slot." % _slot_display_name(target_slot))
			return
		if not source_slot.is_empty(): gear[source_slot] = {}
		elif source_index >= 0: inventory.remove_at(source_index)
		if not gear[target_slot].is_empty(): inventory.append(gear[target_slot])
		item.slot = target_slot
		gear[target_slot] = item
	_refresh_player_gear_visuals()
	_recalculate_player_stats()
	loot_luck = _calculate_loot_luck()
	_save_progress()
	_refresh_hud()
	_rebuild_gear_list()
	_rebuild_inventory()
	_show_message("Gear moved to %s" % _slot_display_name(target_slot))


func _toggle_item_favorite(item_id: int) -> void:
	for slot in EQUIPMENT_SLOTS:
		if int(gear[slot].get("id", -2)) == item_id:
			gear[slot]["favorite"] = not bool(gear[slot].get("favorite", false))
	for index in range(inventory.size()):
		if int(inventory[index].get("id", -2)) == item_id:
			inventory[index]["favorite"] = not bool(inventory[index].get("favorite", false))
	_save_progress()
	_rebuild_inventory()
	_show_message("Favorite lock updated")


func _select_inventory_item(item_id: int) -> void:
	selected_item_id = item_id
	if not inventory_overlay.visible:
		_toggle_inventory()
	_populate_item_details()


func _populate_item_details() -> void:
	if not is_instance_valid(inventory_detail_box):
		return
	for child in inventory_detail_box.get_children():
		child.queue_free()
	var selected: Dictionary = {}
	var in_bag := false
	var equipped_slot := ""
	for slot in EQUIPMENT_SLOTS:
		if int(gear[slot].get("id", -1)) == selected_item_id:
			selected = gear[slot]
			equipped_slot = slot
	for item in inventory:
		if int(item.get("id", -1)) == selected_item_id:
			selected = item
			in_bag = true
	if selected.is_empty():
		_label(inventory_detail_box, "ITEM DETAILS", 18, Color("#f0d89e"))
		_label(inventory_detail_box, "Choose a piece of equipped gear or press MORE on a backpack item to inspect its exact stats, ability, and enchantment.", 12, Color("#b9c6c2"))
		return
	var icon := TextureRect.new()
	icon.custom_minimum_size = Vector2(110.0, 110.0)
	icon.expand_mode = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.texture = load(_item_icon_path(selected))
	inventory_detail_box.add_child(icon)
	_label(inventory_detail_box, "%s · %s" % [selected.rarity, selected.name], 20, _rarity_color(String(selected.rarity)))
	_label(inventory_detail_box, "%s  ·  POWER %d" % [_slot_display_name(String(selected.get("slot", selected.type))), selected.rank], 12, Color("#88d5e8"))
	var enchant_name := String(selected.get("enchant", ""))
	var enchant_rank := int(selected.get("enchant_rank", 1))
	var enchant_slots: Array = []
	if String(selected.get("type", "")) in ["weapon", "armor"]:
		enchant_slots = _ensure_item_enchantments(selected)
		selected_enchant_index = clampi(selected_enchant_index, 0, maxi(0, enchant_slots.size() - 1))
		if not enchant_slots.is_empty():
			var chosen_enchant: Dictionary = enchant_slots[selected_enchant_index]
			enchant_name = String(chosen_enchant.get("name", ""))
			enchant_rank = int(chosen_enchant.get("rank", 1))
	var effect_heading := "ENCHANTMENT · %s · TIER %d" % [enchant_name, enchant_rank]
	if not enchant_slots.is_empty(): effect_heading += " · SLOT %d/%d" % [selected_enchant_index + 1, enchant_slots.size()]
	if selected.type == "artifact":
		effect_heading = "ARTIFACT ABILITY · %s" % selected.name
	elif selected.type == "talisman":
		effect_heading = "PASSIVE TALISMAN · %s" % selected.name
	_label(inventory_detail_box, effect_heading, 13, Color("#e2ce9c"))
	var desc := _label(inventory_detail_box, String(ENCHANT_DESCRIPTIONS.get(enchant_name, "A special gear effect.")), 12, Color("#c0cbc7"))
	if String(selected.get("type", "")) == "artifact":
		var artifact_data: Array = ARTIFACT_DATA.get(String(selected.name), [25, 12, "A magical artifact effect.", MISSION_NAMES])
		desc.text = String(artifact_data[2])
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	if not enchant_slots.is_empty():
		_build_enchantment_upgrade_ui(inventory_detail_box, selected, enchant_slots)
	var stats := _label(inventory_detail_box, "ITEM STATS\n" + "\n".join(_item_exact_stats(selected)), 12, Color("#f0e6cd"))
	stats.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stats.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var actions := HBoxContainer.new()
	inventory_detail_box.add_child(actions)
	var favorite_button := _button("UNFAVORITE" if bool(selected.get("favorite", false)) else "FAVORITE ★", Color("#856c39"))
	favorite_button.pressed.connect(_toggle_item_favorite.bind(selected_item_id))
	actions.add_child(favorite_button)
	if in_bag:
		var equip_button := _button("EQUIP", Color("#657967"))
		equip_button.pressed.connect(_equip.bind(selected))
		actions.add_child(equip_button)
	if in_bag or not equipped_slot.is_empty():
		var salvage := _button("SALVAGE", Color("#654c45"))
		if bool(selected.get("favorite", false)):
			salvage.text = "FAVORITED · LOCKED"
			salvage.disabled = true
		else:
			salvage.pressed.connect(_request_salvage.bind(selected))
		actions.add_child(salvage)


func _build_enchantment_upgrade_ui(parent: VBoxContainer, item: Dictionary, slots: Array) -> void:
	_label(parent, "ENCHANTMENT SLOTS · %d" % slots.size(), 12, Color("#e9d49c"))
	var slot_grid := GridContainer.new()
	slot_grid.columns = slots.size()
	slot_grid.add_theme_constant_override("h_separation", 5)
	parent.add_child(slot_grid)
	for index in range(slots.size()):
		var enchant_slot: Dictionary = slots[index]
		var selected := index == selected_enchant_index
		var slot_button := _button("SLOT %d\n%s\nTIER %d" % [index + 1, String(enchant_slot.get("name", "")), int(enchant_slot.get("rank", 1))], Color("#806a42") if selected else Color("#39464b"))
		slot_button.custom_minimum_size = Vector2(82.0, 62.0)
		slot_button.pressed.connect(_select_enchant_slot.bind(index))
		slot_grid.add_child(slot_button)
	var active_slot: Dictionary = slots[selected_enchant_index]
	var current_rank := int(active_slot.get("rank", 1))
	var tier_names: Array[String] = ["I", "II", "III"]
	var tier_row := HBoxContainer.new()
	tier_row.add_theme_constant_override("separation", 5)
	parent.add_child(tier_row)
	for tier in range(1, 4):
		var tier_button: Button
		if tier <= current_rank:
			tier_button = _button("TIER %s\nUNLOCKED" % tier_names[tier - 1], Color("#806a42"))
			tier_button.disabled = true
		else:
			var cost := _enchant_upgrade_cost(item, String(active_slot.get("name", "")), tier - 1)
			tier_button = _button("TIER %s\nCOST · %d EP" % [tier_names[tier - 1], cost], Color("#60533b"))
			tier_button.disabled = tier != current_rank + 1 or enchant_points < cost
			if not tier_button.disabled:
				tier_button.pressed.connect(_upgrade_enchant.bind(item, selected_enchant_index))
		tier_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tier_row.add_child(tier_button)
	var invested := _enchant_slot_points_spent(item, active_slot)
	_label(parent, "POINTS INVESTED · %d     AVAILABLE · %d" % [invested, enchant_points], 10, Color("#bcb4d9"))


func _select_enchant_slot(index: int) -> void:
	selected_enchant_index = index
	_populate_item_details()


func _item_exact_stats(item: Dictionary) -> Array[String]:
	var values: Array[String] = []
	var rank := int(item.get("enchant_rank", 1))
	var slot := String(item.get("slot", item.get("type", "")))
	var enchant := String(item.get("enchant", ""))
	if item.type == "weapon":
		var weapon_enchant_slots: Array = _ensure_item_enchantments(item)
		var weapon_enchant_summary: Array[String] = []
		for enchant_slot in weapon_enchant_slots: weapon_enchant_summary.append("%s %d" % [String(enchant_slot.get("name", "")), int(enchant_slot.get("rank", 1))])
		values.append("Enchantments: %s" % " · ".join(weapon_enchant_summary))
		var weapon_name := String(item.get("name", "Wayfinder Blade"))
		var weapon_class := String(WEAPON_CLASSES.get(weapon_name, "Medium"))
		var profile: Array = WEAPON_COMBAT[weapon_class]
		var base_hit := float(profile[3]) + float(item.get("rank", 1)) * float(profile[4])
		values.append("Style: %s · %d-hit combo · %.2fs between swings" % [weapon_class, int(profile[0]), float(profile[1])])
		values.append("Damage per hit: %.1f · finisher: %.1f (×1.5)" % [base_hit * _player_damage_multiplier(), base_hit * 1.5 * _player_damage_multiplier()])
		values.append("Finisher recovery: %.2fs" % float(profile[2]))
	elif item.type == "armor":
		var armor_enchant_slots: Array = _ensure_item_enchantments(item)
		var armor_enchant_summary: Array[String] = []
		for enchant_slot in armor_enchant_slots: armor_enchant_summary.append("%s %d" % [String(enchant_slot.get("name", "")), int(enchant_slot.get("rank", 1))])
		values.append("Enchantments: %s" % " · ".join(armor_enchant_summary))
		values.append("Armor rating: %d · damage reduced by %.1f" % [item.rank, float(item.rank) * 0.5])
		values.append("Maximum health: +%.1f" % (float(item.rank) * 1.5))
	elif item.type == "artifact":
		var data: Array = ARTIFACT_DATA.get(String(item.name), [25, 12, "A magical artifact effect.", MISSION_NAMES])
		var artifact_rarity := String(item.get("rarity", "Common"))
		var artifact_scale: String = String({"Common": "1.0×", "Rare": "1.25×", "Special": "1.5×"}.get(artifact_rarity, "1.0×"))
		values.append("Artifact rarity: %s · effect strength: %s" % [artifact_rarity, artifact_scale])
		values.append("Soul cost: %d · cooldown: %d seconds · key %d" % [int(data[0]), int(data[1]), ARTIFACT_SLOTS.find(slot) + 1])
		values.append("Ability: %s" % String(data[2]))
		values.append("Found in: %s" % ", ".join(PackedStringArray(data[3])))
	elif item.type == "talisman":
		values.append("Passive effect: %s" % _exact_passive_talisman(String(item.name)))
	var percent: int = int([10, 21, 33][rank - 1])
	match enchant:
		"Critical Hit": values.append("Critical chance: %d%% · critical damage: ×3" % [10, 15, 20][rank - 1])
		"Committed": values.append("Low-health bonus: +%d%% damage" % [50, 75, 100][rank - 1])
		"Exploding": values.append("Explosion: 18 damage · 3.0m radius")
		"Fire Aspect": values.append("Burn: 5 damage/second · 3 seconds")
		"Freezing": values.append("Slow: 35% · 2 seconds")
		"Gravity": values.append("Pulls enemies within 4.5m by 0.75m")
		"Leeching": values.append("On kill: heal %d%% of enemy max health" % [5, 7, 9][rank - 1])
		"Prospector": values.append("On kill: %d%% chance for +2 shards" % (25 * rank))
		"Radiance": values.append("20%% chance to heal %d%% of max health" % (20 * rank))
		"Sharpness": values.append("Weapon damage: +%d%%" % percent)
		"Shockwave": values.append("Every third hit: %d%% weapon damage" % 45)
		"Swirling": values.append("Every third hit: 35% weapon damage")
		"Chilling": values.append("Nearby slow: 35% · up to 6m · every 2s")
		"Deflect": values.append("Deflect chance: %d%%" % [25, 35, 45][rank - 1])
		"Protection": values.append("Damage reduction: %d%%" % [6, 11, 15][rank - 1])
		"Snowball": values.append("Stun: 1.15s · every 4s")
		"Thorns": values.append("Reflect: %d%% of incoming damage" % [100, 150, 200][rank - 1])
	if slot in ["artifact1", "artifact2", "artifact3"]:
		values.append("Ability cooldown remaining: %.1fs" % artifact_cooldowns[ARTIFACT_SLOTS.find(slot)])
	return values


func _slot_display_name(slot: String) -> String:
	match slot:
		"weapon": return "WEAPON"
		"helmet": return "HELMET"
		"armor": return "CHESTPLATE"
		"leggings": return "LEGGINGS"
		"boots": return "BOOTS"
		"artifact1": return "ARTIFACT 1"
		"artifact2": return "ARTIFACT 2"
		"artifact3": return "ARTIFACT 3"
		"talisman": return "PASSIVE TALISMAN"
	return slot.to_upper()


func _buy_camp_gear() -> void:
	if game_active or menu_overlay == null or not menu_overlay.visible:
		return
	if shards < 35:
		_panel_message("The blacksmith needs 35 shards for a Rare item.")
		return
	if inventory.size() >= 8:
		_panel_message("Your pack is full. Salvage an item before buying gear.")
		return
	shards -= 35
	inventory.append(_make_gear_item("Rare"))
	_save_progress()
	_refresh_hud()
	_rebuild_inventory()
	_panel_message("Blacksmith crafted a Rare item. Check your inventory.")


func _build_merchant_overlay() -> void:
	merchant_overlay = ColorRect.new()
	merchant_overlay.name = "EnchantmentMerchant"
	merchant_overlay.color = Color(0.01, 0.015, 0.02, 0.88)
	merchant_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	merchant_overlay.visible = false
	merchant_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	ui_layer.add_child(merchant_overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	merchant_overlay.add_child(center)
	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(610.0, 580.0)
	center.add_child(card)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 10)
	card.add_child(content)
	var header := HBoxContainer.new()
	content.add_child(header)
	var title := _label(header, "THE ENCHANTER", 20, Color("#e8ce91"))
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var close := _button("CLOSE · ESC", Color("#536e83"))
	close.pressed.connect(_close_merchant)
	header.add_child(close)
	_label(content, "Reroll every enchant slot on a weapon or armor piece. Spent enchantment points are returned.", 12, Color("#c3ccc5"))
	var wallet := _label(content, "COINS · 0", 14, Color("#f2d66d"))
	wallet.name = "MerchantWallet"
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(scroll)
	merchant_item_list = VBoxContainer.new()
	merchant_item_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	merchant_item_list.add_theme_constant_override("separation", 6)
	scroll.add_child(merchant_item_list)


func _show_merchant() -> void:
	if not is_instance_valid(merchant_overlay):
		return
	_refresh_merchant_items()
	merchant_overlay.visible = true
	paused = true
	_play_sfx("click")


func _close_merchant() -> void:
	if is_instance_valid(merchant_overlay):
		merchant_overlay.visible = false
	paused = false
	_play_sfx("click")


func _refresh_merchant_items() -> void:
	if not is_instance_valid(merchant_item_list):
		return
	var wallet := merchant_overlay.find_child("MerchantWallet", true, false) as Label
	if is_instance_valid(wallet):
		wallet.text = "COINS · %d" % coins
	for child in merchant_item_list.get_children(): child.queue_free()
	var found := false
	for slot in ["weapon", "helmet", "armor", "leggings", "boots"]:
		var equipped: Dictionary = gear[slot]
		if not equipped.is_empty():
			_add_merchant_offer(equipped, true)
			found = true
	for item in inventory:
		if String(item.get("type", "")) in ["weapon", "armor"]:
			_add_merchant_offer(item, false)
			found = true
	if not found:
		_label(merchant_item_list, "Bring a weapon or armor piece here to reroll its enchantments.", 13, Color("#c3ccc5"))


func _add_merchant_offer(item: Dictionary, equipped: bool) -> void:
	var row := HBoxContainer.new()
	merchant_item_list.add_child(row)
	var slots := _ensure_item_enchantments(item)
	var names: Array[String] = []
	for enchant_slot in slots:
		names.append("%s T%d" % [String(enchant_slot.get("name", "")), int(enchant_slot.get("rank", 1))])
	var name_label := _label(row, "%s · %s\n%s" % ["EQUIPPED" if equipped else "PACK", String(item.get("name", "Gear")), "  /  ".join(names)], 11, _rarity_color(String(item.get("rarity", "Common"))))
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var cost := _merchant_reroll_cost(item)
	var reroll := _button("REROLL · %d COINS" % cost, Color("#75623c"))
	reroll.pressed.connect(_merchant_reroll.bind(int(item.get("id", -1))))
	row.add_child(reroll)


func _merchant_reroll_cost(item: Dictionary) -> int:
	var base_cost := {"Common": 80, "Rare": 140, "Epic": 260, "Gilded": 420}
	return int(base_cost.get(String(item.get("rarity", "Common")), 80)) + int(item.get("rank", 1)) * 2


func _merchant_reroll(item_id: int) -> void:
	var item: Dictionary = {}
	for slot in EQUIPMENT_SLOTS:
		if int(gear[slot].get("id", -2)) == item_id:
			item = gear[slot]
			break
	if item.is_empty():
		for backpack_item in inventory:
			if int(backpack_item.get("id", -2)) == item_id:
				item = backpack_item
				break
	if item.is_empty() or String(item.get("type", "")) not in ["weapon", "armor"]:
		return
	var cost := _merchant_reroll_cost(item)
	if coins < cost:
		_show_message("The enchanter needs %d coins for that reroll." % cost)
		return
	var old_slots := _ensure_item_enchantments(item)
	var points_returned := 0
	for enchant_slot in old_slots:
		var refund := _enchant_slot_points_spent(item, enchant_slot)
		points_returned += refund
		enchant_points += refund
	var pool: Array = WEAPON_ENCHANTS if item.type == "weapon" else ARMOR_ENCHANTS
	var new_slots: Array[Dictionary] = []
	var capacity := _enchant_slot_count(String(item.get("rarity", "Common")))
	var available: Array = pool.duplicate()
	for index in range(capacity):
		if available.is_empty(): break
		var name := String(available.pick_random())
		available.erase(name)
		new_slots.append({"name": name, "rank": 1, "points_spent": 0})
	item["enchantments"] = new_slots
	item["enchant_points_spent"] = 0
	selected_enchant_index = 0
	coins -= cost
	_sync_primary_enchantment(item)
	_save_progress()
	_rebuild_inventory()
	_refresh_merchant_items()
	_play_sfx("magic")
	_show_message("Enchants rerolled · %d points returned" % points_returned)
	_refresh_hud()


func _build_salvage_confirmation() -> void:
	salvage_confirmation_overlay = ColorRect.new()
	salvage_confirmation_overlay.name = "SalvageConfirmation"
	salvage_confirmation_overlay.color = Color(0.01, 0.015, 0.02, 0.88)
	salvage_confirmation_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	salvage_confirmation_overlay.visible = false
	salvage_confirmation_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	ui_layer.add_child(salvage_confirmation_overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	salvage_confirmation_overlay.add_child(center)
	var card := PanelContainer.new()
	card.custom_minimum_size = Vector2(440.0, 220.0)
	center.add_child(card)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 14)
	card.add_child(content)
	_label(content, "SALVAGE ITEM?", 19, Color("#f0d89e"))
	salvage_confirmation_label = _label(content, "Salvage this item?", 14, Color("#e8e4d9"))
	salvage_confirmation_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var buttons := HBoxContainer.new()
	buttons.add_theme_constant_override("separation", 12)
	content.add_child(buttons)
	var cancel := _button("CANCEL", Color("#536e83"))
	cancel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cancel.pressed.connect(_cancel_salvage)
	buttons.add_child(cancel)
	var confirm := _button("CONFIRM SALVAGE", Color("#8e4d42"))
	confirm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	confirm.pressed.connect(_confirm_salvage)
	buttons.add_child(confirm)


func _request_salvage(item: Dictionary) -> void:
	if bool(item.get("favorite", false)):
		_show_message("Favorite gear is locked and cannot be salvaged.")
		return
	pending_salvage_item = item.duplicate(true)
	var value := _salvage_coin_value(item)
	var points := _points_invested(item)
	var points_note := ""
	if points > 0:
		points_note = "\nYou will also get %d enchantment points back." % points
	salvage_confirmation_label.text = "Salvage %s %s for %d coins?%s" % [String(item.get("rarity", "Common")), String(item.get("name", "gear")), value, points_note]
	salvage_confirmation_overlay.visible = true
	_play_sfx("click")


func _cancel_salvage() -> void:
	salvage_confirmation_overlay.visible = false
	pending_salvage_item.clear()
	_play_sfx("click")


func _confirm_salvage() -> void:
	if pending_salvage_item.is_empty():
		_cancel_salvage()
		return
	var item := pending_salvage_item.duplicate(true)
	salvage_confirmation_overlay.visible = false
	pending_salvage_item.clear()
	_salvage_item(item)


func _salvage_coin_value(item: Dictionary) -> int:
	var rarity_value := {"Common": 12, "Rare": 24, "Epic": 42, "Gilded": 65}
	return int(rarity_value.get(String(item.get("rarity", "Common")), 12)) + int(item.get("rank", 1)) * 2


func _salvage_item(item: Dictionary) -> void:
	if bool(item.get("favorite", false)):
		_show_message("Favorite gear is locked and cannot be salvaged.")
		return
	var item_id := int(item.get("id", -1))
	var removed_equipped := false
	for slot in EQUIPMENT_SLOTS:
		if int(gear[slot].get("id", -2)) == item_id:
			gear[slot] = {}
			removed_equipped = true
	for index in range(inventory.size()):
		if int(inventory[index].get("id", -2)) == item_id:
			inventory.remove_at(index)
			break
	var coin_reward := _salvage_coin_value(item)
	coins += coin_reward
	var returned_points := _points_invested(item)
	enchant_points += returned_points
	if removed_equipped:
		_refresh_player_gear_visuals()
		_recalculate_player_stats()
		health = minf(health, max_health)
		loot_luck = _calculate_loot_luck()
	selected_item_id = -1
	_play_sfx("break")
	_save_progress()
	_refresh_hud()
	_rebuild_inventory()
	_show_message("Gear salvaged · +%d coins · +%d enchantment points" % [coin_reward, returned_points])


func _points_invested(item: Dictionary) -> int:
	var raw_slots: Variant = item.get("enchantments", [])
	if raw_slots is Array and not raw_slots.is_empty():
		var total_slots := 0
		for enchant_slot in raw_slots:
			if enchant_slot is Dictionary:
				total_slots += _enchant_slot_points_spent(item, enchant_slot)
		return total_slots
	if item.has("enchant_points_spent"):
		return maxi(0, int(item.get("enchant_points_spent", 0)))
	var rank := clampi(int(item.get("enchant_rank", 1)), 1, 3)
	var costs: Array = ENCHANT_COST.get(String(item.get("enchant", "")), [1, 2])
	var total := 0
	for tier_index in range(rank - 1):
		if tier_index < costs.size():
			total += int(costs[tier_index]) + (1 if String(item.get("rarity", "")) == "Gilded" else 0)
	return total


func _refresh_boss_bar(foe: CharacterBody3D) -> void:
	if not is_instance_valid(foe):
		return
	status_label.text = "%s  ·  %d%% HP  ·  STABILITY %d%%" % [BOSS_NAMES[selected_mission].to_upper(), int(float(foe.get_meta("health")) / float(foe.get_meta("max_health")) * 100.0), int(stability)]


func _power_level() -> int:
	return _average_equipped_power()


func _average_equipped_power() -> int:
	var total := 0
	var pieces := 0
	for slot in EQUIPMENT_SLOTS:
		var item: Dictionary = gear[slot]
		if not item.is_empty():
			total += int(item.get("rank", 1))
			pieces += 1
	if pieces == 0:
		return 1
	return maxi(1, int(round(float(total) / float(pieces))))


func _player_damage_multiplier() -> float:
	if selected_tier == 1:
		return 1.5
	if selected_tier == 2:
		return 0.75
	if selected_tier > 2:
		return maxf(0.35, 0.75 - float(selected_tier - 2) * 0.015)
	return 1.0


func _incoming_damage_multiplier() -> float:
	if selected_tier == 1:
		return 0.65
	if selected_tier == 2:
		return 1.5
	if selected_tier > 2:
		return 1.5 + float(selected_tier - 2) * 0.06
	return 1.0


func _cleared_boss_count(tier: int) -> int:
	var count := 0
	for mission in range(MISSION_NAMES.size()):
		if bool(cleared_bosses.get("%d:%d" % [tier, mission], false)):
			count += 1
	return count


func _all_bosses_cleared(tier: int) -> bool:
	return _cleared_boss_count(tier) >= MISSION_NAMES.size()


func _tier_name(tier: int) -> String:
	if tier == 0:
		return "Normal"
	if tier == 1:
		return "Adventure"
	if tier == 2:
		return "Apocalypse"
	return "Apocalypse +%d" % (tier - 2)


func _rarity_color(rarity: String) -> Color:
	match rarity:
		"Special": return Color("#e77bec")
		"Gilded": return Color("#f0c36a")
		"Epic": return Color("#c08bea")
		"Rare": return Color("#72bce1")
		_: return Color("#d0d4cb")


func _shards_for_rarity(rarity: String) -> int:
	match rarity:
		"Special": return 6
		"Gilded": return 8
		"Epic": return 5
		"Rare": return 3
		_: return 1


func _normalize_artifact_rarity(item: Dictionary) -> void:
	var rarity := String(item.get("rarity", "Common"))
	if rarity == "Gilded" or rarity == "Special":
		item["rarity"] = "Special"
	elif rarity == "Epic" or rarity == "Rare":
		item["rarity"] = "Rare"
	else:
		item["rarity"] = "Common"


func _panel_message(text: String) -> void:
	if is_instance_valid(summary_label):
		summary_label.text = text


func _show_message(text: String) -> void:
	status_message = text
	status_timer = 2.4
	status_label.text = text


func _show_menu(message: String = "") -> void:
	_enemies_cleanup()
	for drop in loot_nodes:
		if is_instance_valid(drop):
			drop.queue_free()
	loot_nodes.clear()
	for projectile in enemy_projectiles:
		if is_instance_valid(projectile):
			projectile.queue_free()
	enemy_projectiles.clear()
	for projectile in player_projectiles:
		if is_instance_valid(projectile):
			projectile.queue_free()
	player_projectiles.clear()
	boss_actor = null
	dungeon_interactables.clear()
	_build_camp_scene()
	in_camp = true
	menu_overlay.visible = false
	pause_overlay.visible = false
	inventory_overlay.visible = false
	settings_overlay.visible = false
	paused = false
	game_active = false
	_set_camp_music_active(true)
	if not message.is_empty():
		_panel_message(message)
		_show_message(message)
		status_timer = 12.0
	if is_instance_valid(tier_picker):
		for i in range(28):
			tier_picker.set_item_disabled(i, i > unlocked_tier)
		tier_picker.select(mini(selected_tier, unlocked_tier))
		selected_tier = mini(selected_tier, unlocked_tier)
	_refresh_hud()
	_rebuild_inventory()


func _start_run() -> void:
	rng.randomize()
	selected_mission = mission_picker.selected
	selected_tier = tier_picker.selected
	_set_camp_music_active(false)
	_enemies_cleanup()
	for drop in loot_nodes:
		if is_instance_valid(drop):
			drop.queue_free()
	loot_nodes.clear()
	_rebuild_environment()
	player.global_position = Vector3.ZERO
	player.velocity = Vector3.ZERO
	target_actor = null
	has_move_goal = false
	boss_actor = null
	stability = 0.0
	kills = 0
	caches_opened = 0
	shrines_used = 0
	player_slow_timer = 0.0
	health = max_health
	spawn_timer = 2.0
	boss_spawned = false
	pressure_timer = 0.0
	artifact_cooldowns = [0.0, 0.0, 0.0]
	potion_cooldown = 0.0
	arrows = max_arrows
	arrow_regen_timer = 0.0
	in_camp = false
	game_active = true
	paused = false
	menu_overlay.visible = false
	pause_overlay.visible = false
	inventory_overlay.visible = false
	for i in range(5 + int(selected_tier * 0.35)):
		_spawn_enemy(false)
	loot_luck = _calculate_loot_luck()
	_refresh_hud()
	

func _enemies_cleanup() -> void:
	for foe in enemies:
		if is_instance_valid(foe):
			foe.queue_free()
	enemies.clear()
	target_actor = null
	

func _rebuild_environment() -> void:
	if not is_instance_valid(arena_root):
		return
	for child in arena_root.get_children():
		if child == hit_ring or child == player:
			continue
		child.queue_free()
	coin_nodes.clear()
	_create_arena_contents()


func _create_arena_contents() -> void:
	var colors: Array = MISSION_COLORS[selected_mission]
	_add_static_box(arena_root, Vector3(MAP_W * TILE + 2.0, 0.4, MAP_D * TILE + 2.0), Vector3(0.0, -0.22, 0.0), _make_textured_material(colors[1], Vector3(34.0, 32.0, 1.0), 1), "StoneFloor")
	for x in range(MAP_W):
		_add_wall(Vector3((x - MAP_W / 2.0 + 0.5) * TILE, 1.0, -MAP_D * TILE / 2.0), colors[0])
		_add_wall(Vector3((x - MAP_W / 2.0 + 0.5) * TILE, 1.0, MAP_D * TILE / 2.0), colors[0])
	for z in range(MAP_D):
		_add_wall(Vector3(-MAP_W * TILE / 2.0, 1.0, (z - MAP_D / 2.0 + 0.5) * TILE), colors[0])
		_add_wall(Vector3(MAP_W * TILE / 2.0, 1.0, (z - MAP_D / 2.0 + 0.5) * TILE), colors[0])
	dungeon_open_cells.clear()
	# Winding, hand-built maze: several branches feed into one broad northern boss hall.
	for x in range(-2, 3):
		for z in range(-1, 2): dungeon_open_cells[Vector2i(x, z)] = true
	for x in range(-1, 4): dungeon_open_cells[Vector2i(x, -2)] = true
	for z in range(-5, -1): dungeon_open_cells[Vector2i(2, z)] = true
	# One large, almost-square boss chamber (22 × 22 metres).
	for x in range(-5, 6):
		for z in range(-14, -3): dungeon_open_cells[Vector2i(x, z)] = true
	for z in range(-2, 2): dungeon_open_cells[Vector2i(-3, z)] = true
	for x in range(-6, -2):
		for z in range(-1, 3): dungeon_open_cells[Vector2i(x, z)] = true
	for z in range(-2, 2): dungeon_open_cells[Vector2i(4, z)] = true
	for x in range(4, 7):
		for z in range(-1, 3): dungeon_open_cells[Vector2i(x, z)] = true
	for z in range(2, 5): dungeon_open_cells[Vector2i(-4, z)] = true
	for x in range(-6, -3):
		for z in range(4, 6): dungeon_open_cells[Vector2i(x, z)] = true
	for z in range(2, 5): dungeon_open_cells[Vector2i(5, z)] = true
	for x in range(5, 7):
		for z in range(4, 6): dungeon_open_cells[Vector2i(x, z)] = true
	# Far exploration wings extend the route well beyond the starting chamber.
	for z in range(-1, 4): dungeon_open_cells[Vector2i(-7, z)] = true
	for x in range(-10, -7):
		for z in range(-1, 4): dungeon_open_cells[Vector2i(x, z)] = true
	for z in range(-1, 4): dungeon_open_cells[Vector2i(7, z)] = true
	for x in range(8, 11):
		for z in range(-1, 4): dungeon_open_cells[Vector2i(x, z)] = true
	for z in range(2, 5): dungeon_open_cells[Vector2i(-2, z)] = true
	for x in range(-5, 6):
		for z in range(5, 11): dungeon_open_cells[Vector2i(x, z)] = true
	# Small side chambers vary each run without disrupting the path to the boss.
	for branch in range(3):
		var side := -1 if rng.randf() < 0.5 else 1
		var bx := side * 6
		var bz := rng.randi_range(-2, 4)
		for dx in range(2):
			for dz in range(2): dungeon_open_cells[Vector2i(bx + side * dx, bz + dz)] = true
	for x in range(-12, 13):
		for z in range(-15, 12):
			if not dungeon_open_cells.has(Vector2i(x, z)):
				_add_wall(Vector3(x * TILE, 1.0, z * TILE), colors[0], Vector3(2.0, 2.0, 2.0))
	for pillar_at in [Vector3(-12.0, 1.5, -7.0), Vector3(12.0, 1.5, -7.0), Vector3(-12.0, 1.5, 7.0), Vector3(12.0, 1.5, 7.0)]:
		_add_wall(pillar_at, colors[0].lightened(0.12), Vector3(1.4, 3.0, 1.4))
	for detail_index in range(14):
		var detail_x := rng.randf_range(-12.0, 12.0)
		var detail_z := rng.randf_range(-8.0, 8.0)
		if absf(detail_x) < 3.5 or Vector2(detail_x, detail_z).length() < 5.0:
			continue
		var rubble := MeshInstance3D.new()
		var rubble_mesh := BoxMesh.new()
		rubble_mesh.size = Vector3(rng.randf_range(0.35, 1.0), rng.randf_range(0.2, 0.65), rng.randf_range(0.35, 1.0))
		rubble.mesh = rubble_mesh
		rubble.position = Vector3(detail_x, rubble_mesh.size.y * 0.5 - 0.08, detail_z)
		rubble.rotation.y = rng.randf_range(0.0, TAU)
		rubble.material_override = _material(colors[0].lerp(Color.WHITE, rng.randf_range(0.0, 0.15)))
		arena_root.add_child(rubble)
	_add_floor_details(colors)
	_add_mission_set_dressing(colors)
	_create_exploration_objects()
	_add_boss_chamber_landmarks(colors)


func _add_mission_set_dressing(colors: Array) -> void:
	# Mission-specific landmarks make each run readable at a glance while leaving
	# the generated corridors open for movement and combat.
	var accent: Color = colors[2]
	var base: Color = colors[0]
	for side in [-1.0, 1.0]:
		for row in range(3):
			var x: float = float(side) * (19.0 + float((row % 2) * 2))
			var z := -8.0 + float(row) * 10.0
			var landmark := Node3D.new()
			landmark.name = "MissionLandmark_%d" % selected_mission
			landmark.position = Vector3(x, 0.0, z)
			arena_root.add_child(landmark)
			match selected_mission:
				0: # Rainy Plains: mossy standing stones and luminous rain beacons.
					_add_prop_box(landmark, Vector3(0.7, 2.5, 0.7), Vector3.ZERO, base.lightened(0.18))
					_add_prop_box(landmark, Vector3(1.3, 0.18, 0.85), Vector3(0.0, 1.25, 0.0), accent, 0.7)
					_add_prop_orb(landmark, Vector3(0.0, 1.7, 0.0), accent, 0.26)
				1: # Singer's Meadow: carved song posts with a leaf canopy.
					_add_prop_box(landmark, Vector3(0.42, 2.3, 0.42), Vector3.ZERO, base.lightened(0.16))
					_add_prop_box(landmark, Vector3(1.45, 0.22, 0.65), Vector3(0.0, 1.18, 0.0), accent)
					_add_prop_orb(landmark, Vector3(0.0, 1.55, 0.0), accent.lightened(0.2), 0.17)
				2: # Huskland: bone-and-cloth markers.
					_add_prop_box(landmark, Vector3(0.36, 2.0, 0.36), Vector3.ZERO, Color("#d7c6a1"))
					_add_prop_box(landmark, Vector3(0.95, 0.75, 0.12), Vector3(0.48, 0.8, 0.0), accent, 0.15)
					_add_prop_box(landmark, Vector3(0.8, 0.12, 0.12), Vector3(0.48, 1.22, 0.0), Color("#e8d8b9"), 0.2)
				3: # Honeycomb Fields: amber hexagonal hive stones.
					_add_prop_hex(landmark, Vector3(0.0, 0.45, 0.0), accent, 1.1)
					_add_prop_hex(landmark, Vector3(0.0, 1.05, 0.0), Color("#f9df75"), 0.62)
					_add_prop_orb(landmark, Vector3(0.0, 1.55, 0.0), Color("#ffe88a"), 0.16)
				4: # Lullaby Hills: violet lanterns hovering in broken arches.
					_add_prop_box(landmark, Vector3(0.34, 1.7, 0.34), Vector3(-0.6, 0.0, 0.0), base.lightened(0.16))
					_add_prop_box(landmark, Vector3(0.34, 1.7, 0.34), Vector3(0.6, 0.0, 0.0), base.lightened(0.16))
					_add_prop_box(landmark, Vector3(1.5, 0.25, 0.38), Vector3(0.0, 1.45, 0.0), base.lightened(0.2))
					_add_prop_orb(landmark, Vector3(0.0, 1.0, 0.0), accent, 0.25)
				5: # Frozen Highlands: faceted ice clusters.
					_add_prop_crystal(landmark, Vector3(-0.45, 0.0, 0.0), accent, 1.75)
					_add_prop_crystal(landmark, Vector3(0.4, 0.0, -0.15), Color("#e0fbff"), 1.1)
				6: # Howling Woods: blocky pine trees with visible trunks.
					_add_prop_box(landmark, Vector3(0.32, 1.0, 0.32), Vector3(0.0, 0.5, 0.0), Color("#765039"))
					_add_prop_cone(landmark, Vector3(0.0, 1.45, 0.0), base.lightened(0.2), 1.7)
					_add_prop_cone(landmark, Vector3(0.0, 2.0, 0.0), accent, 1.2)


func _add_boss_chamber_landmarks(colors: Array) -> void:
	# Four color-coded braziers frame the sealed boss hall without blocking it.
	var accent: Color = colors[2]
	for at in [Vector3(-8.0, 0.0, -26.0), Vector3(8.0, 0.0, -26.0), Vector3(-8.0, 0.0, -10.0), Vector3(8.0, 0.0, -10.0)]:
		var shrine := Node3D.new()
		shrine.name = "BossHallBeacon"
		shrine.position = at
		arena_root.add_child(shrine)
		_add_prop_box(shrine, Vector3(0.72, 0.9, 0.72), Vector3(0.0, 0.45, 0.0), colors[0].lightened(0.2))
		_add_prop_orb(shrine, Vector3(0.0, 1.15, 0.0), accent.lightened(0.18), 0.28)
		var lamp := OmniLight3D.new()
		lamp.position = Vector3(0.0, 1.4, 0.0)
		lamp.light_color = accent
		lamp.light_energy = 0.7
		lamp.omni_range = 4.5
		arena_root.add_child(lamp)


func _add_prop_box(parent: Node3D, size: Vector3, at: Vector3, color: Color, roughness: float = 0.82) -> void:
	var prop := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	prop.mesh = mesh
	prop.position = at
	prop.material_override = _material(color, roughness, 0.0)
	parent.add_child(prop)


func _add_prop_orb(parent: Node3D, at: Vector3, color: Color, radius: float) -> void:
	var prop := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 8
	mesh.rings = 4
	prop.mesh = mesh
	prop.position = at
	prop.material_override = _material(color, 0.28, 0.9)
	parent.add_child(prop)


func _add_prop_crystal(parent: Node3D, at: Vector3, color: Color, height: float) -> void:
	var prop := MeshInstance3D.new()
	var mesh := PrismMesh.new()
	mesh.size = Vector3(0.65, height, 0.65)
	prop.mesh = mesh
	prop.position = at + Vector3.UP * (height * 0.5)
	prop.rotation_degrees.y = 18.0
	prop.material_override = _material(color, 0.2, 0.85)
	parent.add_child(prop)


func _add_prop_cone(parent: Node3D, at: Vector3, color: Color, height: float) -> void:
	var prop := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.04
	mesh.bottom_radius = height * 0.34
	mesh.height = height
	mesh.radial_segments = 7
	prop.mesh = mesh
	prop.position = at + Vector3.UP * (height * 0.5)
	prop.material_override = _material(color, 0.95)
	parent.add_child(prop)


func _add_prop_hex(parent: Node3D, at: Vector3, color: Color, width: float) -> void:
	var prop := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = width * 0.5
	mesh.bottom_radius = width * 0.5
	mesh.height = width * 0.55
	mesh.radial_segments = 6
	prop.mesh = mesh
	prop.position = at
	prop.material_override = _material(color, 0.35, 0.25)
	parent.add_child(prop)


func _create_exploration_objects() -> void:
	dungeon_interactables.clear()
	var gate := Node3D.new()
	gate.name = "BossHallEntrance"
	gate.position = Vector3(4.0, 0.0, -7.0)
	for gate_x in [-1.25, 1.25]:
		var post := MeshInstance3D.new()
		var post_mesh := BoxMesh.new()
		post_mesh.size = Vector3(0.65, 3.2, 0.7)
		post.mesh = post_mesh
		post.position = Vector3(gate_x, 1.6, 0.0)
		post.material_override = _material(Color("#78c9d3"), 0.28, 1.1)
		gate.add_child(post)
	var lintel := MeshInstance3D.new()
	var lintel_mesh := BoxMesh.new()
	lintel_mesh.size = Vector3(3.5, 0.55, 0.8)
	lintel.mesh = lintel_mesh
	lintel.position = Vector3(0.0, 3.15, 0.0)
	lintel.material_override = _material(Color("#e3c16e"), 0.24, 0.8)
	gate.add_child(lintel)
	var gate_label := Label3D.new()
	gate_label.text = "BOSS HALL"
	gate_label.font_size = 36
	gate_label.outline_size = 8
	gate_label.position = Vector3(0.0, 4.0, 0.0)
	gate_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	gate_label.no_depth_test = true
	gate.add_child(gate_label)
	arena_root.add_child(gate)
	var cache_spots: Array[Vector3] = [Vector3(-12.0, 0.0, 2.0), Vector3(12.0, 0.0, 2.0), Vector3(-10.0, 0.0, 9.0), Vector3(10.0, 0.0, 9.0), Vector3(-12.0, 0.0, -3.0), Vector3(12.0, 0.0, -3.0)]
	cache_spots.shuffle()
	for cache_index in range(3):
		var at: Vector3 = cache_spots[cache_index]
		var cache := Node3D.new()
		cache.name = "BuriedSupplyCache"
		cache.position = at
		cache.set_meta("kind", "cache")
		cache.set_meta("used", false)
		var chest_body := MeshInstance3D.new()
		var chest_mesh := BoxMesh.new()
		chest_mesh.size = Vector3(1.0, 0.65, 0.75)
		chest_body.mesh = chest_mesh
		chest_body.position.y = 0.38
		chest_body.material_override = _material(Color("#8b5d36"), 0.65)
		cache.add_child(chest_body)
		var latch := MeshInstance3D.new()
		var latch_mesh := BoxMesh.new()
		latch_mesh.size = Vector3(0.18, 0.38, 0.82)
		latch.mesh = latch_mesh
		latch.position = Vector3(0.0, 0.4, 0.0)
		latch.material_override = _material(Color("#edca75"), 0.25, 0.5)
		cache.add_child(latch)
		_add_interaction_prompt(cache, 1.8)
		arena_root.add_child(cache)
		dungeon_interactables.append(cache)
	var shrine_spots: Array[Vector3] = [Vector3(-18.0, 0.0, 2.0), Vector3(18.0, 0.0, 2.0), Vector3(-18.0, 0.0, 8.0), Vector3(18.0, 0.0, 8.0), Vector3(0.0, 0.0, 18.0)]
	shrine_spots.shuffle()
	for shrine_index in range(2):
		var at: Vector3 = shrine_spots[shrine_index]
		var shrine := Node3D.new()
		shrine.name = "StabilityShrine"
		shrine.position = at
		shrine.set_meta("kind", "shrine")
		shrine.set_meta("used", false)
		var crystal := MeshInstance3D.new()
		var crystal_mesh := PrismMesh.new()
		crystal_mesh.size = Vector3(0.9, 1.7, 0.9)
		crystal.mesh = crystal_mesh
		crystal.position.y = 0.9
		crystal.material_override = _material(Color("#79cce0"), 0.22, 1.1)
		shrine.add_child(crystal)
		_add_interaction_prompt(shrine, 2.3)
		arena_root.add_child(shrine)
		dungeon_interactables.append(shrine)


func _add_interaction_prompt(object: Node3D, height: float) -> void:
	var prompt := Label3D.new()
	prompt.text = "E"
	prompt.font_size = 58
	prompt.outline_size = 12
	prompt.outline_modulate = Color("#ffffff")
	prompt.modulate = Color("#26322d")
	prompt.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	prompt.no_depth_test = true
	prompt.position.y = height
	prompt.visible = false
	object.add_child(prompt)
	object.set_meta("prompt_label", prompt)


func _interact_with_nearby() -> void:
	if in_camp:
		if is_instance_valid(camp_merchant) and _flat_distance(player.global_position, camp_merchant.global_position) <= 3.4:
			_show_merchant()
		elif is_instance_valid(camp_table) and _flat_distance(player.global_position, camp_table.global_position) <= 3.2:
			mission_picker.select(selected_mission)
			menu_overlay.visible = true
			paused = true
			_play_sfx("click")
			_refresh_hud()
		else:
			_show_message("Walk up to the expedition table to choose a dungeon")
		return
	var nearest_drop: Node3D
	var drop_distance := 2.3
	for drop in loot_nodes:
		if is_instance_valid(drop):
			var dist := _flat_distance(player.global_position, drop.global_position)
			if dist < drop_distance:
				nearest_drop = drop
				drop_distance = dist
	if is_instance_valid(nearest_drop):
		var loot_item: Dictionary = nearest_drop.get_meta("item")
		if inventory.size() >= 8: inventory.pop_front()
		inventory.append(loot_item)
		shards += _shards_for_rarity(String(loot_item.rarity))
		loot_nodes.erase(nearest_drop)
		nearest_drop.queue_free()
		_play_sfx("loot")
		_show_message("Picked up %s %s" % [loot_item.rarity, loot_item.name])
		_refresh_hud()
		_rebuild_inventory()
		_save_progress()
		return
	var closest: Node3D
	var closest_distance := 2.4
	for object in dungeon_interactables:
		if is_instance_valid(object) and not bool(object.get_meta("used", false)):
			var distance := _flat_distance(player.global_position, object.global_position)
			if distance < closest_distance:
				closest_distance = distance
				closest = object
	if not is_instance_valid(closest):
		_show_message("Move close to a chest or stability shrine to interact.")
		return
	closest.set_meta("used", true)
	_set_node_outline(closest, false)
	if String(closest.get_meta("kind", "")) == "cache":
		caches_opened += 1
		shards += 4 + selected_tier
		_drop_loot(closest.global_position)
		_play_sfx("loot")
		_show_message("SUPPLY CACHE OPEN · gear and %d shards" % (4 + selected_tier))
	else:
		shrines_used += 1
		stability = maxf(0.0, stability - 38.0)
		shards += 2
		_spawn_ring_fx(closest.global_position + Vector3(0.0, 0.08, 0.0), Color("#78e2e5"), 4.0)
		_play_sfx("magic")
		_show_message("STABILITY RESTORED · -38 instability")
	dungeon_interactables.erase(closest)
	closest.queue_free()
	_save_progress()
	_refresh_hud()
	_rebuild_inventory()


func _toggle_pause() -> void:
	if not game_active and not in_camp:
		return
	paused = not paused
	if paused and in_camp:
		menu_overlay.visible = false
	if is_instance_valid(return_camp_button):
		return_camp_button.visible = not in_camp
	pause_overlay.visible = paused


func _build_target_ring_unused() -> void:
	pass


func _update_sword_cursor(_position: Vector2) -> void:
	if not is_instance_valid(player) or camera == null:
		return
	var from := camera.project_ray_origin(_position)
	var dir := camera.project_ray_normal(_position)
	var query := PhysicsRayQueryParameters3D.create(from, from + dir * RAY_LENGTH)
	query.collision_mask = 2
	var target := get_world_3d().direct_space_state.intersect_ray(query)
	if not target.is_empty() and target.collider is CharacterBody3D and target.collider.is_in_group("enemies"):
		hover_actor = target.collider
		Input.set_custom_mouse_cursor(red_sword_cursor, Input.CURSOR_ARROW, Vector2(5.0, 5.0))
	else:
		hover_actor = null
		Input.set_custom_mouse_cursor(null, Input.CURSOR_ARROW)
	if absf(dir.y) < 0.001:
		return
	var t := -from.y / dir.y
	if t > 0.0:
		var point := from + dir * t
		if is_instance_valid(hit_ring) and has_move_goal:
			hit_ring.global_position = point + Vector3(0.0, 0.045, 0.0)


func _play_sfx(kind: String) -> void:
	var audio := AudioStreamWAV.new()
	const RATE := 22050
	var count := int(RATE * 0.16)
	var data := PackedByteArray()
	data.resize(count * 2)
	var start_frequency := 300.0
	var end_frequency := 150.0
	match kind:
		"hit": start_frequency = 190.0; end_frequency = 85.0
		"loot": start_frequency = 650.0; end_frequency = 980.0
		"hurt": start_frequency = 135.0; end_frequency = 65.0
		"magic": start_frequency = 430.0; end_frequency = 790.0
		"boss": start_frequency = 105.0; end_frequency = 55.0
		"click": start_frequency = 380.0; end_frequency = 280.0
		"hover": start_frequency = 520.0; end_frequency = 620.0
		"ranged": start_frequency = 760.0; end_frequency = 390.0
		"player_attack": start_frequency = 340.0; end_frequency = 115.0
		"mob_attack": start_frequency = 170.0; end_frequency = 55.0
		"potion": start_frequency = 510.0; end_frequency = 1040.0
		"break": start_frequency = 920.0; end_frequency = 125.0
	for i in range(count):
		var p := float(i) / float(count)
		var frequency := lerpf(start_frequency, end_frequency, p)
		var envelope := (1.0 - p) * (1.0 - p)
		var grit := rng.randf_range(-0.35, 0.35) if kind == "break" else 0.0
		var sample := int((sin(TAU * frequency * float(i) / RATE) + grit) * envelope * (6500.0 if kind == "break" else 5000.0))
		data.encode_s16(i * 2, sample)
	audio.format = AudioStreamWAV.FORMAT_16_BITS
	audio.mix_rate = RATE
	audio.stereo = false
	audio.data = data
	var source := AudioStreamPlayer.new()
	source.stream = audio
	source.volume_db = linear_to_db(maxf(0.001, sfx_volume)) - 7.0
	add_child(source)
	source.finished.connect(source.queue_free)
	source.play()


func _load_progress() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	var loaded_keybinds: Variant = cfg.get_value("controls", "bindings", {})
	if loaded_keybinds is Dictionary:
		for action in keybinds.keys():
			if loaded_keybinds.has(action):
				keybinds[action] = int(loaded_keybinds[action])
	master_volume = clampf(float(cfg.get_value("settings", "master_volume", master_volume)), 0.0, 1.0)
	music_volume = clampf(float(cfg.get_value("settings", "music_volume", music_volume)), 0.0, 1.0)
	sfx_volume = clampf(float(cfg.get_value("settings", "sfx_volume", sfx_volume)), 0.0, 1.0)
	camera_zoom = clampf(float(cfg.get_value("settings", "camera_zoom", camera_zoom)), 17.0, 30.0)
	high_quality_shadows = bool(cfg.get_value("settings", "high_quality_shadows", high_quality_shadows))
	show_damage_numbers = bool(cfg.get_value("settings", "show_damage_numbers", show_damage_numbers))
	fullscreen_mode = bool(cfg.get_value("settings", "fullscreen_mode", fullscreen_mode))
	window_resolution_index = clampi(int(cfg.get_value("settings", "window_resolution_index", window_resolution_index)), 0, 2)
	vsync_enabled = bool(cfg.get_value("settings", "vsync_enabled", vsync_enabled))
	level = int(cfg.get_value("progress", "level", 1))
	xp = int(cfg.get_value("progress", "xp", 0))
	xp_next = int(cfg.get_value("progress", "xp_next", 100))
	shards = int(cfg.get_value("progress", "shards", 0))
	coins = int(cfg.get_value("progress", "coins", 0))
	souls = clampi(int(cfg.get_value("progress", "souls", 0)), 0, MAX_SOULS)
	unlocked_tier = maxi(2, int(cfg.get_value("progress", "unlocked_tier", 0)))
	enchant_points = int(cfg.get_value("progress", "enchant_points", 0))
	var loaded_bosses: Variant = cfg.get_value("progress", "cleared_bosses", {})
	if loaded_bosses is Dictionary:
		cleared_bosses = loaded_bosses
	var loaded_gear: Variant = cfg.get_value("gear", "slots", {})
	var merged_gear := {"weapon": {}, "helmet": {}, "armor": {}, "leggings": {}, "boots": {}, "artifact1": {}, "artifact2": {}, "artifact3": {}, "talisman": {}}
	if loaded_gear is Dictionary:
		for slot in loaded_gear:
			if merged_gear.has(slot):
				merged_gear[slot] = loaded_gear[slot]
	gear = merged_gear
	var loaded_inventory = cfg.get_value("gear", "inventory", [])
	inventory.clear()
	for item in loaded_inventory:
		if item is Dictionary:
			if String(item.get("type", "")) == "talisman" and String(item.get("name", "")) in ARTIFACT_NAMES:
				item.type = "artifact"
				item.slot = ARTIFACT_SLOTS[mini(ARTIFACT_SLOTS.size() - 1, inventory.size() % ARTIFACT_SLOTS.size())]
				item.enchant = String(item.name)
			inventory.append(item)
	_recalculate_player_stats()
	health = max_health
	coins = maxi(0, coins)


func _ensure_starter_gear() -> void:
	if gear.weapon.is_empty():
		gear.weapon = {"id": rng.randi(), "type": "weapon", "slot": "weapon", "name": "Wayfinder Blade", "weapon_class": "Medium", "rarity": "Common", "rank": 1, "enchant": "Sharpness", "enchant_rank": 1, "enchant_points_spent": 0, "luck": 0.0}
	var old_talisman: Dictionary = gear.talisman
	if not old_talisman.is_empty() and String(old_talisman.get("name", "")) in ARTIFACT_NAMES and gear.artifact1.is_empty():
		old_talisman.type = "artifact"
		old_talisman.slot = "artifact1"
		old_talisman.enchant = String(old_talisman.name)
		gear.artifact1 = old_talisman
		gear.talisman = {}
	if gear.talisman.is_empty():
		gear.talisman = {"id": rng.randi(), "type": "talisman", "slot": "talisman", "name": "Moonwell Charm", "rarity": "Common", "rank": 1, "enchant": "Moonwell Charm", "enchant_rank": 1, "luck": 0.0}
	if gear.artifact1.is_empty() and gear.artifact2.is_empty() and gear.artifact3.is_empty():
		gear.artifact1 = {"id": rng.randi(), "type": "artifact", "slot": "artifact1", "name": "Spark Totem", "rarity": "Common", "rank": 1, "enchant": "Spark Totem", "enchant_rank": 1, "luck": 0.0}
	for slot in EQUIPMENT_SLOTS:
		var equipped: Dictionary = gear[slot]
		if String(equipped.get("type", "")) in ["weapon", "armor"]:
			_ensure_item_enchantments(equipped)
		elif String(equipped.get("type", "")) == "artifact":
			_normalize_artifact_rarity(equipped)
	for item in inventory:
		if String(item.get("type", "")) in ["weapon", "armor"]:
			_ensure_item_enchantments(item)
		elif String(item.get("type", "")) == "artifact":
			_normalize_artifact_rarity(item)
	_recalculate_player_stats()
	health = max_health
	loot_luck = _calculate_loot_luck()
	_save_progress()


func _save_progress() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("progress", "level", level)
	cfg.set_value("progress", "xp", xp)
	cfg.set_value("progress", "xp_next", xp_next)
	cfg.set_value("progress", "shards", shards)
	cfg.set_value("progress", "coins", coins)
	cfg.set_value("progress", "souls", souls)
	cfg.set_value("progress", "unlocked_tier", unlocked_tier)
	cfg.set_value("progress", "enchant_points", enchant_points)
	cfg.set_value("progress", "cleared_bosses", cleared_bosses)
	cfg.set_value("gear", "slots", gear)
	cfg.set_value("gear", "inventory", inventory)
	cfg.set_value("controls", "bindings", keybinds)
	cfg.set_value("settings", "master_volume", master_volume)
	cfg.set_value("settings", "music_volume", music_volume)
	cfg.set_value("settings", "sfx_volume", sfx_volume)
	cfg.set_value("settings", "camera_zoom", camera_zoom)
	cfg.set_value("settings", "high_quality_shadows", high_quality_shadows)
	cfg.set_value("settings", "show_damage_numbers", show_damage_numbers)
	cfg.set_value("settings", "fullscreen_mode", fullscreen_mode)
	cfg.set_value("settings", "window_resolution_index", window_resolution_index)
	cfg.set_value("settings", "vsync_enabled", vsync_enabled)
	cfg.save(SAVE_PATH)
