extends Control

var drag_owner: Node
var drag_item_id := -1
var drop_slot := ""


func _get_drag_data(_at_position: Vector2) -> Variant:
	if drag_item_id < 0:
		return null
	var preview := Label.new()
	preview.text = "↕  MOVE GEAR"
	preview.add_theme_font_size_override("font_size", 18)
	preview.add_theme_color_override("font_color", Color("#f1d79e"))
	set_drag_preview(preview)
	return {"item_id": drag_item_id}


func _can_drop_data(_at_position: Vector2, data: Variant) -> bool:
	return not drop_slot.is_empty() and data is Dictionary and data.has("item_id")


func _drop_data(_at_position: Vector2, data: Variant) -> void:
	if is_instance_valid(drag_owner) and data is Dictionary:
		drag_owner.call("_handle_inventory_drag", int(data.item_id), drop_slot)
